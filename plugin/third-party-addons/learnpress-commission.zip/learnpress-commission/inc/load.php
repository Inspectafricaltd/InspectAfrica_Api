<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Commission/Classes
 * @version  3.0.0
 */

// Prevent loading this file directly
use LearnPress\Models\CourseModel;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Commission' ) ) {
	/**
	 * Class LP_Addon_Commission
	 */
	class LP_Addon_Commission extends LP_Addon {
		public $version         = LP_ADDON_COMMISSION_VER;
		public $require_version = LP_ADDON_COMMISSION_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_COMMISSION_FILE;
		public $text_domain     = 'learnpress-commission';
		public static $instance;

		/**
		 * Get instance of this class.
		 *
		 * @return LP_Addon_Commission
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new LP_Addon_Commission();
			}

			return self::$instance;
		}

		/**
		 * LP_Addon_Commission constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define Learnpress Co-Instructor constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_COMMISSION_INC', $this->plugin_folder_path . '/inc/' );
			define( 'LP_ADDON_COMMISSION_TEMPLATE', $this->plugin_folder_path . '/templates/' );
			define( 'LP_WITHDRAW_CPT', 'lp_withdraw' );
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 *
		 * @since 3.0.0
		 */
		protected function _includes() {
			include_once LP_ADDON_COMMISSION_INC . 'functions.php';
			include_once LP_ADDON_COMMISSION_INC . 'class-lp-commission.php';
			include_once LP_ADDON_COMMISSION_INC . 'class-lp-withdrawal.php';
			include_once LP_ADDON_COMMISSION_INC . 'class-lp-withdraw-post-type.php';
			include_once LP_ADDON_COMMISSION_INC . 'class-lp-request-withdrawal.php';
			include_once LP_ADDON_COMMISSION_INC . 'admin/class-commission-list-table.php';
			include_once LP_ADDON_COMMISSION_INC . 'admin/class-lp-commission-withdrawal-method-paypal.php';
		}

		/**
		 * Hook into actions and filters.
		 */
		protected function hooks() {

			// admin settings page
			add_filter( 'learn-press/admin/settings-tabs-array', array( $this, 'admin_settings' ) );

			// add_action( 'learn_press_order_status_completed', array( $this, 'calculate_commission' ), 10, 1 );
			add_action( 'learn-press/order/status-completed', array( $this, 'calculate_commission' ), 10, 1 );

			// update setting
			add_action( 'learn-press/update-settings/updated', array( $this, 'update_settings' ) );

			// add fields in admin user profile page
			add_action( 'show_user_profile', array( $this, 'admin_user_profile' ) );
			add_action( 'edit_user_profile', array( $this, 'admin_user_profile' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		}

		/**
		 * Enqueue frontend assets.
		 *
		 * @return void
		 * @since 4.0.4
		 */
		public function frontend_assets() {
			$min = '.min';
			$rtl = '';
			$ver = LP_ADDON_COMMISSION_VER;
			if ( LP_Debug::is_debug() ) {
				$ver = uniqid();
				$rtl = is_rtl() ? '-rtl' : '';
				$min = '';
			}

			wp_register_style(
				'lp_commission_frontend',
				$this->get_plugin_url( "assets/dist/css/profile{$rtl}{$min}.css" ),
				[],
				$ver
			);

			wp_register_script(
				'lp_withdrawals',
				$this->get_plugin_url( "assets/dist/js/withdrawals{$min}.js" ),
				[ 'jquery' ],
				[ 'strategy' => 'defer' ]
			);

			if ( LP_Page_Controller::is_page_profile() ) {
				//wp_enqueue_style( 'lp_commission_frontend' );
				wp_enqueue_script( 'lp_withdrawals' );
			}
		}

		/**
		 * Enqueue admin assets.
		 *
		 * @return void
		 * @since 4.0.4
		 */
		public function admin_assets() {
			$ver = LP_ADDON_COMMISSION_VER;
			$min = '.min';
			if ( LP_Debug::is_debug() ) {
				$min = '';
				$ver = uniqid();
			}

			if ( get_post_type() === LP_WITHDRAW_CPT ) {
				wp_enqueue_style(
					'lp_commission_manage',
					$this->get_plugin_url( 'assets/dist/css/admin.css' ),
					array(),
					$ver
				);
				wp_enqueue_script(
					'lp_withdrawal',
					$this->get_plugin_url( "assets/dist/js/admin{$min}.js" ),
					array( 'jquery' ),
					$ver
				);
			}
		}

		/**
		 * Register new settings tab in LP admin settings.
		 *
		 * @param array $tabs
		 *
		 * @return mixed
		 */
		public function admin_settings( $tabs ) {
			$tabs['commission'] = include_once LP_ADDON_COMMISSION_INC . 'class-lp-commission-settings.php';

			return $tabs;
		}

		/**
		 * Calculate commission.
		 *
		 * @param $order_id
		 */
		public function calculate_commission( $order_id ) {
			$order = learn_press_get_order( $order_id );
			$items = $order->get_all_items();
			if ( count( $items ) ) {
				foreach ( $items as $item ) {
					$order_item_id = $item['order_item_id'] ?? 0;
					$item_id       = $item['item_id'] ?? 0;
					$item_type     = $item['item_type'] ?? '';
					if ( $item_type !== LP_COURSE_CPT ) {
						continue;
					}

					$course_id   = $item_id;
					$courseModel = CourseModel::find( $course_id, true );
					if ( ! $courseModel ) {
						continue;
					}

					$quantity           = intval( learn_press_get_order_item_meta( $order_item_id, '_quantity' ) );
					$total_one_course   = floatval( learn_press_get_order_item_meta( $order_item_id, '_total' ) );
					$total              = $quantity * $total_one_course;
					$percent_commission = LPC()->get_commission_main_instructor( $course_id );

					$commission_value = $total * $percent_commission / 100;
					$commission_value = apply_filters( 'lp/commission/calculate/value', $commission_value, $order_id, $item, $course_id, $percent_commission );

					$instructor        = $courseModel->get_author_model();
					$commission_status = learn_press_get_order_item_meta( $order_item_id, 'lp_commission_status' );
					if ( $instructor && $commission_status !== 'processed' ) {
						lp_commission_add_commission( $instructor->get_id(), $commission_value, $order_id, $item );
					}
				}
			}
		}

		/**
		 * Update settings for manage tab.
		 */
		public function update_settings() {
			$section = isset( $_GET['section'] ) ? $_GET['section'] : false;
			if ( $section === 'manage' ) {
				$this->_update_manage_commission();
			}
		}

		/**
		 * Add fields in admin user profile page.
		 *
		 * @param $user
		 */
		public function admin_user_profile( $user ) {
			$user_data = $user->data;
			$user_id   = $user_data->ID;
			?>
			<h3><?php esc_html_e( 'Course Commission', 'learnpress-commission' ); ?></h3>
			<table class="form-table lp_commission">
				<tbody>
				<tr>
					<th><?php _e( 'Your Commission', 'learnpress-commission' ); ?></th>
					<td>
						<span
							class="count"><?php echo esc_html( lp_commission_get_total_commission( $user_id ) ); ?></span>
						<span class="unit"><?php echo learn_press_get_currency_symbol(); ?></span>
					</td>
				</tr>
				</tbody>
			</table>
			<?php
		}

		/**
		 * Update commission value of commission.
		 */
		private function _update_manage_commission() {
			$post_data = $this->_serialize_post_data();

			foreach ( $post_data as $key => $value ) {
				// Update value commission
				$key_main_instructor = LPC()->key_main_instructor;
				if ( $key === $key_main_instructor ) {
					$array_main_commission = (array) $value;
					foreach ( $array_main_commission as $course_id => $v ) {
						update_post_meta( $course_id, $key_main_instructor, $v );
					}

					continue;
				}

				//Update active
				$key_active = LPC()->key_active;
				if ( $key === $key_active ) {
					$array_active = (array) $value;

					foreach ( $array_active as $course_id => $v ) {
						if ( $v === 'yes' ) {
							update_post_meta( $course_id, $key_active, 1 );
						} else {
							update_post_meta( $course_id, $key_active, 0 );
						}
					}

					continue;
				}
			}
		}

		/**
		 * Serialize post data commission
		 *
		 * @return mixed
		 */
		private function _serialize_post_data() {
			$post_data = $_POST;
			foreach ( $post_data as $key => $value ) {
				$key_prefix = LPC()->prefix;
				if ( strpos( $key, $key_prefix ) === false ) {
					unset( $post_data[ $key ] );
				}
			}

			return $post_data;
		}
	}
}
