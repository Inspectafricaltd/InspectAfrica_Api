=== LearnPress - Frontend Editor Plugin ===
Contributors: thimpress, nhamdv
Donate link:
Tags: education, backend manager courses.
Tested up to: 6.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

== Changelog ==

= 4.1.0 (2025-11-21) =
~ Fixed: error enable Offline course not hide tab Curriculum.
~ Fixed: display struct parent/child Category.

= 4.0.9 (2025-11-12) =
~ Added: support item LP H5P.
~ Added: option show/hide WP bar, permission access WP Admin.
~ Fixed: translate text.

= 4.0.8 (2025-10-06) =
~ Fixed: style for mobile.
~ Added: option update logo for FE page.

= 4.0.7 (2025-05-12) =
~ Added: feature Material File.

= 4.0.6 (2024-08-28) =
~ Fixed: save price course.
~ Use CourseModel instead of learn_press_get_course.
~ Check addon Co-Instructor activated.

= 4.0.5 (2024-07-25) =
~ Tweak: rewrite rules.
~ Tweak: field select author, get from API (make edit load screen edit courses faster).

= 4.0.4 =
~ Add: Add new filter `learnpress_frontend_editor_localize_script` to allow edit localizations ( override logo url... ).
~ Fix: translate text.
~ Fix: some css.

= 4.0.3 (2022-09-29) =
~ Fix: error save meta field.

= 4.0.2 (2022-09-22) =
- Use tech React JS for create, edit, update faster.

