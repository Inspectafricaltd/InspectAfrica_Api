<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Razorpay/Classes
 * @version  4.0.2
 */

use LearnPress\Razorpay\RazorpayGateway;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Razorpay_Payment' ) ) {
	/**
	 * Class LP_Addon_Razorpay_Payment
	 */
	class LP_Addon_Razorpay_Payment extends LP_Addon {
		public static $instance;
		public $text_domain     = 'learnpress-razorpay-payment';
		public $version         = LP_ADDON_RAZORPAY_PAYMENT_VER;
		public $require_version = LP_ADDON_RAZORPAY_PAYMENT_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_RAZORPAY_PAYMENT_FILE;

		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * LP_Addon_Razorpay_Payment constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define Razorpay payment constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_RAZORPAY_PAYMENT_PATH', dirname( LP_ADDON_RAZORPAY_PAYMENT_FILE ) );
			define( 'LP_ADDON_RAZORPAY_PAYMENT_INC', LP_ADDON_RAZORPAY_PAYMENT_PATH . '/inc/' );
			define( 'LP_ADDON_RAZORPAY_PAYMENT_URL', plugin_dir_url( LP_ADDON_RAZORPAY_PAYMENT_FILE ) );
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 *
		 * @since 3.0.0
		 */
		protected function _includes() {
			//include_once LP_ADDON_RAZORPAY_PAYMENT_INC . 'class-lp-gateway-razorpay.php';
		}

			/**
		 * Init hooks.
		 */
		protected function hooks() {
			//add payment gateway class
			add_filter( 'learn-press/payment-methods', array( $this, 'add_payment' ) );
			if ( ! is_admin() ) {
				$this->listen_callback();
			}

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}

		/**
		 * Enqueue scripts.
		 *
		 * @since 4.0.3
		 * @version 1.0.0
		 */
		public function enqueue_scripts() {
			$min    = '.min';
			$ver    = LP_ADDON_RAZORPAY_PAYMENT_VER;
			$is_rtl = is_rtl() ? '-rtl' : '';
			if ( LP_Debug::is_debug() ) {
				$min = '';
				$ver = uniqid();
			}

			wp_register_script(
				'razorpay',
				'https://checkout.razorpay.com/v1/checkout.js',
				[],
				'1.0',
				[ 'strategy' => 'defer' ]
			);
			wp_register_script(
				'lp-razorpay',
				$this->get_plugin_url( "assets/dist/js/razorpay{$min}.js" ),
				array( 'razorpay' ),
				$ver,
				[ 'strategy' => 'defer' ]
			);

			if ( LP_Page_Controller::is_page_checkout() ) {
				wp_enqueue_script( 'lp-razorpay' );
			}
		}

		/**
		 * Add Razorpay to payment system.
		 *
		 * @param $methods
		 *
		 * @return mixed
		 */
		public function add_payment( $methods ) {
			$methods['razorpay'] = RazorpayGateway::instance();

			return $methods;
		}

		/**
		 * Listen to callback from Razorpay payment.
		 *
		 * @return void
		 */
		public function listen_callback() {
			try {
				$order_id_razorpay = LP_Request::get_param( 'order_id_razorpay' );
				RazorpayGateway::instance()->check_callback_from_razorpay( $order_id_razorpay );
			} catch ( Throwable $e ) {
				error_log( __METHOD__ . ' - ' . $e->getMessage() );
			}
		}
	}
}
