<?php
return apply_filters(
	'learn-press/gateway-payment/razorpay/settings',
	array(
		array(
			'type' => 'title',
		),
		array(
			'title'   => esc_html__( 'Enable', 'learnpress-razorpay-payment' ),
			'id'      => '[enable]',
			'default' => 'no',
			'type'    => 'yes-no',
		),
		array(
			'title'      => esc_html__( 'Key ID', 'learnpress-razorpay-payment' ),
			'id'         => '[key_id]',
			'type'       => 'text',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type'       => 'text',
			'title'      => esc_html__( 'Key Secret', 'learnpress-razorpay-payment' ),
			'default'    => '',
			'id'         => '[key_secret]',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type' => 'sectionend',
		),
	)
);
