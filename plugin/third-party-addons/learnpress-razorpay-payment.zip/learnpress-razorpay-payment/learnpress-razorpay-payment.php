<?php
/**
 * Plugin Name: LearnPress - Razorpay Payment
 * Plugin URI: http://thimpress.com/learnpress
 * Description: Razorpay payment gateway for LearnPress.
 * Author: ThimPress
 * Version: 4.0.3
 * Author URI: http://thimpress.com
 * Tags: learnpress, lms, add-on, razorpay
 * Text Domain: learnpress-razorpay-payment
 * Domain Path: /languages/
 * Require_LP_Version: 4.2.8
 * Requires at least: 6.0.0
 * Requires PHP: 7.4
 *
 * @package learnpress-razorpay-payment
 */

defined( 'ABSPATH' ) || exit;

const LP_ADDON_RAZORPAY_PAYMENT_FILE = __FILE__;

/**
 * Class LP_Addon_Razorpay_Payment_Preload
 */
class LP_Addon_Razorpay_Payment_Preload {
	public static $instance;
	/**
	 * @var array
	 */
	public static $addon_info = array();

	/**
	 * Singleton.
	 *
	 * @return LP_Addon_Razorpay_Payment_Preload
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * LP_Addon_Razorpay_Payment_Preload constructor.
	 */
	protected function __construct() {
		$can_load = true;
		// Set Base name plugin.
		define( 'LP_ADDON_RAZORPAY_BASENAME', plugin_basename( LP_ADDON_RAZORPAY_PAYMENT_FILE ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_RAZORPAY_PAYMENT_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_RAZORPAY_PAYMENT_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_RAZORPAY_PAYMENT_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			$can_load = false;
		} elseif ( version_compare( LP_ADDON_RAZORPAY_PAYMENT_REQUIRE_VER, get_option( 'learnpress_version', '3.0.0' ), '>' ) ) {
			$can_load = false;
		}

		if ( ! $can_load ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );
			deactivate_plugins( LP_ADDON_RAZORPAY_BASENAME );

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			return;
		}

		// Sure LP loaded.
		add_action( 'learn-press/ready', array( $this, 'load' ) );
	}
	/**
	 * Load addon
	 */
	public function load() {
		include_once 'vendor/autoload.php';
		include_once 'inc/load.php';
		LP_Addon_Razorpay_Payment::instance();
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p>
				<?php
				printf(
					/* translators: 1: addon name, 2: LP version */
					esc_html__( '%1$s requires %2$s or later to be installed and activated.', 'learnpress-razorpay-payment' ),
					self::$addon_info['Name'],
					self::$addon_info['Require_LP_Version']
				)
				?>
			</p>
		</div>
		<?php
	}
}

LP_Addon_Razorpay_Payment_Preload::instance();
