=== LearnPress - Razorpay Payment ===
Contributors: thimpress
Donate link:
Tags: lms, elearning, e-learning, learning management system, education, course, payment, razorpay.
Tested up to: 6.8
Stable tag: 4.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Razorpay payment gateway for LearnPress.

== Changelog ==

= 4.0.3 (2025-06-09) =
~ Check load razorpay.js on page checkout.

= 4.0.2 (2025-03-17) =
~ Update library.

= 4.0.1 (2024-06-15) =
~ Fixed: error cannot declare class WpOrg\Requests\Requests, because the name is already, via Composer, so use direct sdk.

= 4.0.0 (2023-04-19) =
~ First release.
