<?php

namespace LearnPress\SortingChoice\Models;

use LearnPress\Models\Question\QuestionPostModel;

/**
 * Class QuestionSortingChoiceModel
 *
 * Compatible with LearnPress 4.2.9+
 *
 * @version 1.0.0
 * @since 4.0.2
 */
class QuestionSortingChoiceModel extends QuestionPostModel {
	public $question_type = 'sorting_choice';

	/**
	 * Get true or false default answers.
	 *
	 * @return array
	 */
	public function get_default_answers(): array {
		return [
			[
				'is_true' => 'yes',
				'value'   => $this->random_value(),
				'title'   => esc_html__( 'First option', 'learnpress' ),
			],
			[
				'is_true' => 'yes',
				'value'   => $this->random_value(),
				'title'   => esc_html__( 'Second option', 'learnpress' ),
			],
			[
				'is_true' => 'yes',
				'value'   => $this->random_value(),
				'title'   => esc_html__( 'Third option', 'learnpress' ),
			],
		];
	}
}
