<?php
namespace LearnPress\SortingChoice;

use LearnPress\Helpers\Singleton;
use LearnPress\SortingChoice\Models\QuestionSortingChoiceModel;
use LearnPress\SortingChoice\TemplateHooks\AdminEditQuestionSortingChoiceTemplate;

/**
 * Class Hooks
 *
 * @since 4.0.2
 * @version 1.0.0
 */
class Hooks {
	use Singleton;

	public function init() {
		// Declare question type.
		add_filter(
			'learn-press/question-types',
			function ( $types ) {
				$types['sorting_choice'] = esc_html__( 'Sorting Choice', 'learnpress-sorting-choice' );

				return $types;
			}
		);
		// Declare question object type.
		add_filter(
			'learn-press/question-object-by-type',
			function ( $obj, $type ) {
				if ( 'sorting_choice' === $type ) {
					$obj = QuestionSortingChoiceModel::class;
				}

				return $obj;
			},
			10,
			2
		);
		// Declare question edit html type.
		add_filter(
			'learn-press/edit-question/type/html',
			function ( $html, $type, $questionPostModel ) {
				if ( 'sorting_choice' === $type ) {
					$html = AdminEditQuestionSortingChoiceTemplate::instance()->html_answer_type_sorting_choice( $questionPostModel );
				}

				return $html;
			},
			10,
			3
		);
	}
}
