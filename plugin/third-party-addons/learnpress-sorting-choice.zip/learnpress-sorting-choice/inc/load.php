<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Sorting-Choice/Classes
 * @version  3.0.1
 */

use LearnPress\SortingChoice\Hooks;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Sorting_Choice' ) ) {

	/**
	 * Class LP_Addon_Sorting_Choice
	 */
	class LP_Addon_Sorting_Choice extends LP_Addon {
		public $version         = LP_ADDON_SORTING_CHOICE_VER;
		public $require_version = LP_ADDON_SORTING_CHOICE_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_SORTING_CHOICE_FILE;
		public $text_domain     = 'learnpress-sorting-choice';

		public static function instance() {
			static $instance;
			if ( is_null( $instance ) ) {
				$instance = new self();
			}

			return $instance;
		}

		/**
		 * LP_Addon_Sorting_Choice constructor.
		 */
		public function __construct() {
			parent::__construct();

			$this->_includes();
			$this->hooks();
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 */
		protected function _includes() {
			include_once $this->plugin_folder_path . '/inc/class-lp-question-sorting-choice.php';
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since 3.0.0
		 */
		protected function hooks() {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

			Hooks::instance();
		}

		/**
		 * Enqueue scripts.
		 */
		public function enqueue_assets() {
			$min    = '.min';
			$ver    = LP_ADDON_SORTING_CHOICE_VER;
			$is_rtl = is_rtl() ? '-rtl' : '';
			if ( LP_Debug::is_debug() ) {
				$min = '';
				$ver = uniqid();
			}

			wp_register_script(
				'lp-sorting-choice',
				$this->get_plugin_url( "assets/dist/js/sorting-choice{$min}.js" ),
				array(
					'wp-i18n',
					'wp-element',
					'lp-question-types',
				),
				$ver,
				[ 'strategy' => 'defer' ]
			);

			if ( LP_Global::course_item_quiz() ) {
				wp_enqueue_script( 'lp-sorting-choice' );
			}
		}
	}
}
