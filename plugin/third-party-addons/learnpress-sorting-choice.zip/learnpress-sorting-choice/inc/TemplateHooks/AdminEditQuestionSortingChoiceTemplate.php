<?php

namespace LearnPress\SortingChoice\TemplateHooks;

use Exception;
use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LearnPress\Models\Question\QuestionAnswerModel;
use LearnPress\Models\Question\QuestionPostFIBModel;
use LearnPress\Models\Question\QuestionPostModel;
use LearnPress\TemplateHooks\Admin\AdminTemplate;
use LearnPress\TemplateHooks\TemplateAJAX;
use stdClass;

/**
 * Template Admin Edit Quiz.
 *
 * @since 4.2.9
 * @version 1.0.0
 */
class AdminEditQuestionSortingChoiceTemplate {
	use Singleton;

	public function init() {
	}


	/**
	 * Get html edit question type multiple choice.
	 *
	 * @param QuestionPostModel $questionPostModel
	 *
	 * @return string
	 */
	public function html_answer_type_sorting_choice( QuestionPostModel $questionPostModel ): string {
		$answers   = $questionPostModel->get_answer_option();
		$answers[] = null;

		$html_answers = '';
		foreach ( $answers as $answer ) {
			$is_clone           = true;
			$title              = '';
			$question_answer_id = 0;

			if ( ! is_null( $answer ) ) {
				$is_clone            = false;
				$questionAnswerModel = new QuestionAnswerModel( $answer );
				$title               = $questionAnswerModel->title;
				$question_answer_id  = $questionAnswerModel->question_answer_id;
			}

			$html_answers .= sprintf(
				'<div class="lp-question-answer-item %s" data-answer-id="%d">
					<span class="drag lp-icon-drag" title="Drag to reorder section"></span>
					<span class="lp-icon-spinner"></span>
					<input type="text" class="%s" name="%s" value="%s" />
					<span class="lp-icon-trash-o lp-btn-delete-question-answer"></span>
				</div>',
				$is_clone ? 'clone lp-hidden' : '',
				esc_attr( $question_answer_id ),
				'lp-question-answer-title-input lp-auto-save-question-answer',
				'lp-question-answer-title-input',
				esc_attr( $title )
			);
		}

		$html_answers .= sprintf(
			'<div class="lp-question-answer-item-add-new">
				<span class="lp-icon-plus" title="Add answer option"></span>
				<input type="text" class="%1$s" name="%1$s" value="" data-mess-empty-title="%2$s" />
				<button type="button" class="button lp-btn-add-question-answer lp-btn-edit-primary">%3$s</button>
			</div>',
			'lp-question-answer-title-new-input',
			esc_attr__( 'Answer title is required', 'learnpress' ),
			__( 'Add Option', 'learnpress' )
		);

		$section = [
			'header'  => sprintf(
				'<div class="lp-question-choice-header">
				<span>%s</span><span>%s</span>
			</div>',
				__( 'Answers', 'learnpress' ),
				__( 'Corrects', 'learnpress' )
			),
			'answers' => $html_answers,
		];

		return Template::combine_components( $section );
	}
}
