=== LearnPress - Sorting Choice ===
Contributors: Thimpress
Donate link:
Tags: learnpress, lms, assignment
Tested up to: 6.9
Stable tag: 4.0.3

== Changelog ==

= 4.0.3 (2025-12-30) =
~ Fixed: minor bugs.

= 4.0.2 (2025-09-05) =
~ Fixed: compatible with LP v4.2.9

= 4.0.1 =
~ Move js in learnpress to sorting choice.

= 4.0.0 =
~ Compatible with LP4 and use with React.

= 3.0.2 =
~ Check question result always return true.

= 3.0.1 =
~ Fixed: load js dependencies wrong priority
~ Fixed: check question is itself before change css class
