<?php
/**
 * Template for displaying PayU payment form.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/addons/payu-payment/form.php.
 *
 * @author   ThimPress
 * @package  LearnPress/Payu/Templates
 * @version  4.0.0
 */

defined( 'ABSPATH' ) || exit();
?>

<?php $settings = LearnPress::instance()->settings(); ?>

<p><?php echo $settings->get( 'payu.description' ); ?></p>

<div id="learn-press-payu-form">
	<div class="container">
		<div class="card-container">
			<aside><?php echo __( 'Card Number', 'learnpress-payu' ); ?></aside>
			<div class="payu-card-form" id="payu-card-number"></div>

			<div class="card-details clearfix">
				<div class="expiration">
					<aside><?php echo __( 'Valid Thru', 'learnpress-payu' ); ?></aside>
					<div class="payu-card-form" id="payu-card-date"></div>
				</div>

				<div class="cvv">
					<aside><?php echo __( 'CVV', 'learnpress-payu' ); ?></aside>
					<div class="payu-card-form" id="payu-card-cvv"></div>
				</div>
			</div>
		</div>
	</div>
	<div id="respon-payu"></div>
</div>

<?php if ( $settings->get( 'payu.test_mode' ) == 'yes' ) { ?>
	<?php learn_press_display_message( esc_html__( 'Test mode is enabled. You can use the card number 4444333322221111 with any CVC and a valid expiration date for testing purpose.', 'learnpress-payu' ), 'error' ); ?>
<?php } ?>
