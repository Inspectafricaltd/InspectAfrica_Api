=== LearnPress - PayU ===
Contributors: thimpress.
Donate link:
Tags: payU, elearning, education, course, lms, learning management system
Tested up to: 6.7
Requires PHP: 7.0
Stable tag: 4.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Change log ==

= 4.0.0 (2025-02-18) =
~ Integrate PayU payment Gateway.
