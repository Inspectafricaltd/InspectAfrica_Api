<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/PayU/Classes
 * @version  4.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_PayU_Payment' ) ) {
	/**
	 * Class LP_Addon_PayU_Payment
	 */
	class LP_Addon_PayU_Payment extends LP_Addon {
		private static $_instance = false;

		public static function instance() {
			if ( ! self::$_instance ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * LP_Addon_PayU_Payment constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define Learnpress PayU payment constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_PAYU_PAYMENT_PATH', dirname( LP_ADDON_PAYU_PAYMENT_FILE ) );
			define( 'LP_ADDON_PAYU_PAYMENT_INC', LP_ADDON_PAYU_PAYMENT_PATH . '/inc/' );
			define( 'LP_ADDON_PAYU_PAYMENT_URL', plugin_dir_url( LP_ADDON_PAYU_PAYMENT_FILE ) );
			define( 'LP_ADDON_PAYU_PAYMENT_TEMPLATE', LP_ADDON_PAYU_PAYMENT_PATH . '/templates/' );
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 *
		 * @since 3.0.0
		 */
		protected function _includes() {
			require LP_ADDON_PAYU_PAYMENT_PATH . '/vendor/autoload.php';
			include_once LP_ADDON_PAYU_PAYMENT_INC . 'class-lp-gateway-payu.php';
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			add_filter( 'learn-press/payment-methods', array( $this, 'add_payment' ) );
			if ( ! is_admin() ) {
				$this->listen_transaction();
			}
		}

		/**
		 * Add Instamojo to payment system.
		 *
		 * @param $methods
		 *
		 * @return mixed
		 */
		public function add_payment( $methods ) {
			$methods['payu'] = 'LP_Gateway_PayU';

			return $methods;
		}

		/**
		 * Listen callback to check payu order
		 *
		 * @return void
		 */
		private function listen_transaction() {
			try {
				$is_lp_payu_webhook = LP_Request::get_param( 'lp-payu-webhook-notifications' );
				$is_lp_payu_payment = LP_Request::get_param( 'lp-payu-payment' );
				if ( ! empty( $is_lp_payu_webhook ) || ! empty( $is_lp_payu_payment ) ) {
					$lp_order_id = LP_Request::get_param( 'lp-order-id', 0 );
					if ( empty( $lp_order_id ) ) {
						return;
					}

					LP_Gateway_PayU::instance()->verify_payment( $lp_order_id );
				}
			} catch ( Throwable $e ) {
				error_log( __METHOD__ . ': ' . $e->getMessage() );
			}
		}
	}
}
