<?php
/**
 * PayU payment gateway class.
 *
 * @author   ThimPress
 * @package  LearnPress/PayU/Classes
 * @version  4.0.0
 */
defined( 'ABSPATH' ) || exit;
use LearnPress\Helpers\Singleton;
if ( ! class_exists( 'LP_Gateway_PayU' ) ) {
	/**
	 * Class LP_Gateway_PayU
	 */
	final class LP_Gateway_PayU extends LP_Gateway_Abstract {
		use Singleton;

		/**
		 * @var null
		 */
		protected $key_second = null;

		/**
		 * @var null
		 */
		protected $key_secret = null;

		/**
		 * @var null
		 */
		protected $pos_id = null;

		/**
		 * @var null
		 */
		public $test_mode = null;
		/**
		 * @var null
		 */
		public $env = null;

		/**
		 * @var bool
		 */
		protected $enable = true;

		/**
		 * @var string
		 */
		protected $shop_name = '';

		/**
		 * @var string
		 */
		public $id = 'payu';

		public function init() {
			// do something
		}

		public function __construct() {
			parent::__construct();

			$this->method_title       = 'PayU';
			$this->method_description = esc_html__( 'Make a payment with PayU.', 'learnpress-payu-payment' );
			$this->icon               = LP_ADDON_PAYU_PAYMENT_URL . 'assets/images/payu-logo.svg';
			$this->title              = $this->method_title;
			$this->description        = $this->settings->get( 'description', $this->method_description );
			if ( $this->is_enabled() ) {
				$this->key_second = $this->settings->get( 'key_second' );
				$this->key_secret = $this->settings->get( 'key_secret' );
				$this->pos_id     = $this->settings->get( 'pos_id' );
				$this->test_mode  = $this->settings->get( 'test_mode' );
				$this->env        = $this->settings->get( 'test_mode' ) === 'yes' ? 'sandbox' : 'secure';
				$this->shop_name  = $this->settings->get( 'shop_name' );
			}
		}

		/**
		 * Admin payment settings.
		 *
		 * @return array
		 */
		public function get_settings() {
			return include_once LP_ADDON_PAYU_PAYMENT_PATH . '/config/settings.php';
		}

		/**
		 * PayU payment process.
		 *
		 * @param int $order_id
		 *
		 * @return array
		 * @throws Exception
		 */
		public function process_payment( $order_id ) {
			$result = array(
				'result'   => 'fail',
				'message'  => '',
				'redirect' => '',
			);

			$lp_order = learn_press_get_order( $order_id );
			if ( ! $lp_order ) {
				throw new Exception( __( 'Order not found!', 'learnpress-payu-payment' ) );
			}
			$currency = learn_press_get_currency();
			if ( ! $this->is_supported_currency( $currency ) ) {
				throw new Exception( $currency . __( ' currency is not supported!', 'learnpress-payu-payment' ) );
			}
			$redirect_url = $this->get_payment_url( $lp_order );
			$result       = array_merge(
				$result,
				array(
					'result'   => 'success',
					'message'  => esc_html__( 'Redirecting', 'learnpress-payu-payment' ),
					'redirect' => $redirect_url,
				)
			);

			return $result;
		}

		/**
		 * set PayU Configuration
		 *
		 * @throws OpenPayU_Exception_Configuration
		 */
		public function set_environment() {
			OpenPayU_Configuration::setEnvironment( $this->env );
			OpenPayU_Configuration::setMerchantPosId( $this->pos_id );
			OpenPayU_Configuration::setSignatureKey( $this->key_second );
			OpenPayU_Configuration::setOauthClientId( $this->pos_id );
			OpenPayU_Configuration::setOauthClientSecret( $this->key_secret );
		}

		/**
		 * get payu payment url
		 * @param  LP_Order $lp_order
		 * @throws Exception
		 * @return string payment url
		 */
		public function get_payment_url( LP_Order $lp_order ): string {
			$this->set_environment();
			$order_id    = $lp_order->get_id();
			$order_items = $lp_order->get_item_ids();
			$extOrderId  = uniqid( 'lporder' . $order_id . '-' );
			if ( empty( $order_items ) ) {
				throw new Exception( __( 'Order is empty', 'learnpress-payu-payment' ) );
			}

			$course_id    = $order_items[0];
			$course       = learn_press_get_course( $course_id );
			$course_title = $course->get_title();

			$description        = '';
			$total              = $lp_order->get_total() * 100;
			$order_descriptions = __( 'Order ', 'learnpress-payu-payment' );
			$continueUrl        = add_query_arg(
				array(
					'lp-payu-payment' => 1,
					'lp-order-id'     => $order_id,
				),
				$this->get_return_url( $lp_order )
			);
			$notifyUrl          = add_query_arg(
				array(
					'lp-payu-webhook-notifications' => 1,
					'lp-order-id'                   => $order_id,
				),
				get_site_url()
			);
			$orderData          = array(
				'continueUrl'   => $continueUrl,
				'notifyUrl'     => $notifyUrl,
				'customerIp'    => $_SERVER['REMOTE_ADDR'],
				'merchantPosId' => $this->pos_id,
				'description'   => $order_descriptions . $order_id,
				'currencyCode'  => learn_press_get_currency(),
				'totalAmount'   => $total,
				'extOrderId'    => $extOrderId,
				'products'      => array(
					array(
						'name'      => $course_title,
						'unitPrice' => $total,
						'quantity'  => 1,
						'virtual'   => true,
					),
				),
				'buyer'         => array(
					'email' => $lp_order->get_checkout_email(),
				),
			);
			$payu_order_data    = OpenPayU_Order::create( $orderData );
			if ( empty( $payu_order_data->getResponse()->orderId ) ) {
				throw new Exception( __( 'PayU Order ID is empty', 'learnpress-payu-payment' ) );
			}
			// update post meta order id payu when update status LP order
			update_post_meta( $order_id, '_payu_order_id', $payu_order_data->getResponse()->orderId );
			$redirect_url = $payu_order_data->getResponse()->redirectUri;
			// return $payu_order_data;
			return $redirect_url;
		}

		/**
		 * Check supported currencies
		 *
		 * @param  string $currency LP currency code
		 * @return boolean
		 */
		public function is_supported_currency( string $currency = 'PLN' ): bool {
			$supported_currency = apply_filters(
				'learn-press/payu-payment/supported-currencies',
				[ 'CHF', 'CZK', 'DKK', 'EUR', 'GBP', 'HRK', 'HUF', 'NOK', 'PLN', 'RON', 'SEK', 'USD' ]
			);

			return in_array( $currency, $supported_currency );
		}

		/**
		 * verify payu payment
		 * @param  integer $order_id LP_Order id
		 * @throws Exception
		 */
		public function verify_payment( $order_id ) {
			if ( empty( $order_id ) ) {
				return;
			}

			$lp_order = learn_press_get_order( $order_id );
			if ( empty( $lp_order ) ) {
				return;
			}

			if ( $lp_order->is_completed() ) {
				return;
			}

			if ( $this->id !== $lp_order->get_data( 'payment_method' ) ) {
				return;
			}

			$payu_order_id = get_post_meta( $order_id, '_payu_order_id', true );
			if ( empty( $payu_order_id ) ) {
				return;
			}

			$this->set_environment();
			$payu_order_data = OpenPayU_Order::retrieve( $payu_order_id );
			if ( empty( $payu_order_data ) ) {
				throw new Exception( __( 'Cannot retrieve PayU order data', 'learnpress-payu-payment' ) );
			}

			$order_data = $payu_order_data->getResponse()->orders[0];
			if ( $order_data->status === 'COMPLETED' ) {
				$lp_order->update_status( LP_ORDER_COMPLETED );
			}
		}
	}
}
