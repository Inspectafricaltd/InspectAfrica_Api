<?php
return apply_filters(
	'learn-press/gateway-payment/payu/settings',
	array(
		array(
			'type' => 'title',
		),
		array(
			'title'   => esc_html__( 'Enable', 'learnpress-payu-payment' ),
			'id'      => '[enable]',
			'default' => 'no',
			'type'    => 'yes-no',
		),
		array(
			'type'       => 'textarea',
			'title'      => esc_html__( 'Description', 'learnpress-payu-payment' ),
			'default'    => esc_html__( 'Make a payment with PayU', 'learnpress-payu-payment' ),
			'id'         => '[description]',
			'editor'     => array(
				'textarea_rows' => 5,
			),
			'css'        => 'height: 100px;',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => esc_html__( 'Shop Name', 'learnpress-payu-payment' ),
			'id'         => '[shop_name]',
			'type'       => 'text',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => esc_html__( 'POS ID', 'learnpress-payu-payment' ),
			'id'         => '[pos_id]',
			'type'       => 'text',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => esc_html__( 'Second Key', 'learnpress-payu-payment' ),
			'id'         => '[key_second]',
			'type'       => 'text',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type'       => 'text',
			'title'      => esc_html__( 'Client Secret', 'learnpress-payu-payment' ),
			'default'    => '',
			'id'         => '[key_secret]',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'   => esc_html__( 'Test Mode', 'learnpress-payu-payment' ),
			'id'      => '[test_mode]',
			'default' => 'no',
			'type'    => 'yes-no',
		),
		// array(
		// 'title'   => esc_html__( 'Use SDK or Page checkout', 'learnpress-payu-payment' ),
		// 'desc'    => esc_html__( 'if selected, will use PayU payment page and vice versa will use the popup at Learnpress payment page.', 'learnpress-payu-payment' ),
		// 'id'      => '[page_checkout_payu]',
		// 'default' => 'yes',
		// 'type'    => 'yes-no',
		// ),
		array(
			'type' => 'sectionend',
		),
	)
);
