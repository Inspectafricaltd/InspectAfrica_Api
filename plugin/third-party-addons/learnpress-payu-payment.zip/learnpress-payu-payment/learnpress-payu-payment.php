<?php
/**
 * Plugin Name: LearnPress - PayU Payment
 * Plugin URI: http://thimpress.com/learnpress
 * Description: PayU payment gateway for LearnPress.
 * Author: ThimPress
 * Version: 4.0.0
 * Author URI: http://thimpress.com
 * Tags: learnpress
 * Text Domain: learnpress-payu-payment
 * Domain Path: /languages/
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Require_LP_Version: 4.2.7.7
 *
 * @package LearnPress-PayU-Payment
 */

defined( 'ABSPATH' ) || exit;

const LP_ADDON_PAYU_PAYMENT_FILE = __FILE__;


/**
 * Class LP_Addon_PayU_Payment_Preload
 */
class LP_Addon_PayU_Payment_Preload {
	/**
	 * @var array
	 */
	public static $addon_info = array();
	/**
	 * @var LP_Addon_PayU_Payment $addon
	 */
	public static $addon;

	/**
	 * Singleton.
	 *
	 * @return LP_Addon_PayU_Payment_Preload|mixed
	 */
	public static function instance() {
		static $instance;
		if ( is_null( $instance ) ) {
			$instance = new self();
		}

		return $instance;
	}

	/**
	 * LP_Addon_PayU_Payment_Preload constructor.
	 */
	protected function __construct() {
		// Set Base name plugin.
		define( 'LP_ADDON_PAYU_PAYMENT_BASENAME', plugin_basename( LP_ADDON_PAYU_PAYMENT_FILE ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_PAYU_PAYMENT_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_PAYU_PAYMENT_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_PAYU_PAYMENT_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );

			deactivate_plugins( LP_ADDON_PAYU_PAYMENT_BASENAME );

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			return;
		}

		// Sure LP loaded.
		add_action( 'learn-press/ready', array( $this, 'load' ) );
	}

	/**
	 * Load addon
	 */
	public function load() {
		include_once 'inc/load.php';
		LP_Addon_PayU_Payment::instance();
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p><?php echo( 'Please active <strong>LP version ' . LP_ADDON_PAYU_PAYMENT_REQUIRE_VER . ' or later</strong> before active <strong>' . self::$addon_info['Name'] . '</strong>' ); ?></p>
		</div>
		<?php
	}
}

LP_Addon_PayU_Payment_Preload::instance();
