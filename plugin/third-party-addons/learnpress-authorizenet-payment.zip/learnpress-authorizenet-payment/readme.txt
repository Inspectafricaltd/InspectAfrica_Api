=== LearnPress - Authorize.Net Payment ===
Contributors: thimpress, tunnhn, leehld, phonglq
Donate link:
Tags: authorize, payment, lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Tested up to: 6.7
Stable tag: 4.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Integration authorize.net to LearnPress.

== Description ==
Integration authorize.net to LearnPress.

== Installation ==

**From your WordPress dashboard**
1. Visit 'Plugin > Add new'.
2. Search for 'LearnPress Authorize.net Payment'.
3. Activate LearnPress from your Plugins page.

== Frequently Asked Questions ==

Check out [LearnPress](http://docs.thimpress.com/learnpress) sites

== Screenshots ==

== Changelog ==

= 4.0.2 (2025-03-05) =
~ Fixed: minor bugs.

= 4.0.1 (2024-02-31) =
+ Optimize code.

= 4.0.0 =
+ Fix compatible LP4

= 3.0.1 =
+ Update cert.pem file
+ Update some deprecated function

= 3.0.0 =
+ Updated to be compatible with LearnPress 3.0.0

== Other note ==
<a href="http://docs.thimpress.com/learnpress" target="_blank">Documentation</a> is available in ThimPress site.
<a href="https://github.com/LearnPress/LearnPress/" target="_blank">LearnPress github repo.</a>
