<?php
return apply_filters(
	'learn-press/gateway-payment/instamojo/settings',
	array(
		array(
			'type' => 'title',
		),
		array(
			'title'   => esc_html__( 'Enable', 'learnpress-instamojo-payment' ),
			'id'      => '[enable]',
			'default' => 'no',
			'type'    => 'yes-no',
		),
		/*array(
			'type'       => 'text',
			'title'      => esc_html__( 'Title', 'learnpress-instamojo-payment' ),
			'default'    => esc_html__( 'Instamojo', 'learnpress-instamojo-payment' ),
			'id'         => '[title]',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type'       => 'textarea',
			'title'      => esc_html__( 'Description', 'learnpress-instamojo-payment' ),
			'default'    => esc_html__( 'Make a payment with Instamojo', 'learnpress-instamojo-payment' ),
			'id'         => '[description]',
			'editor'     => array(
				'textarea_rows' => 5,
			),
			'css'        => 'height: 100px;',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),*/
		array(
			'title'      => esc_html__( 'Client ID', 'learnpress-instamojo-payment' ),
			'id'         => '[client_id]',
			'type'       => 'text',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type'       => 'text',
			'title'      => esc_html__( 'Client Secret', 'learnpress-instamojo-payment' ),
			'default'    => '',
			'id'         => '[client_secret]',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => esc_html__( 'Enable test mode', 'learnpress-instamojo-payment' ),
			'id'         => '[test_mode]',
			'default'    => 'no',
			'type'       => 'yes-no',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => esc_html__( 'Enable Floating Checkout', 'learnpress-instamojo-payment' ),
			'id'         => '[floating_checkout]',
			'default'    => 'no',
			'type'       => 'yes-no',
			'desc'       => esc_html__( 'Enable payment on the current site, if disabled will redirect to the Instamojo website.', 'learnpress-instamojo-payment' ),
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type' => 'sectionend',
		),
	)
);
