=== LearnPress - Instamojo Payment ===
Contributors: thimpress
Donate link:
Tags: learnpress, instamojo, payment
Tested up to: 6.7
Stable tag: 4.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

LearnPress Instamojo Payment is an extension plugin to integrate Instamojo gateway to LearnPress.

== Description ==

== Changelog ==

= 4.0.1 (2025-03-18) =
~ Clean code.

= 4.0.0 (2023-01-18) =
~ First release.
