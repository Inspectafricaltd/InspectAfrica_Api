<?php
/**
 * Plugin Name: LearnPress - Instamojo Payment
 * Plugin URI: http://thimpress.com/learnpress
 * Description: Instamojo payment gateway for LearnPress.
 * Author: ThimPress
 * Version: 4.0.1
 * Author URI: http://thimpress.com
 * Tags: learnpress, lms, add-on, instamojo
 * Text Domain: learnpress-instamojo-payment
 * Domain Path: /languages/
 * Require_LP_Version: 4.2.8
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package learnpress-instamojo-payment
 */

defined( 'ABSPATH' ) || exit;

const LP_ADDON_INSTAMOJO_PAYMENT_FILE = __FILE__;

/**
 * Class LP_Addon_Instamojo_Payment_Preload
 */
class LP_Addon_Instamojo_Payment_Preload {

	public static $addon;
	/**
	 * @var array
	 */
	public static $addon_info = array();

	/**
	 * LP_Addon_Instamojo_Payment_Preload constructor.
	 */
	public function __construct() {
		$can_load = true;
		// Set Base name plugin.
		define( 'LP_ADDON_INSTAMOJO_BASENAME', plugin_basename( LP_ADDON_INSTAMOJO_PAYMENT_FILE ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_INSTAMOJO_PAYMENT_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_INSTAMOJO_PAYMENT_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_INSTAMOJO_PAYMENT_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			$can_load = false;
		} elseif ( version_compare( LP_ADDON_INSTAMOJO_PAYMENT_REQUIRE_VER, get_option( 'learnpress_version', '3.0.0' ), '>' ) ) {
			$can_load = false;
		}

		if ( ! $can_load ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );
			deactivate_plugins( LP_ADDON_INSTAMOJO_BASENAME );

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			return;
		}

		// Sure LP loaded.
		add_action( 'learn-press/ready', array( $this, 'load' ) );
	}
	/**
	 * Load addon
	 */
	public function load() {
		include_once 'vendor/autoload.php';
		include_once 'inc/load.php';
		LP_Addon_Instamojo_Payment::instance();
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p>
				<?php
				printf(
				/* translators: 1: addon name, 2: LP version */
					esc_html__( '%1$s requires %2$s or later to be installed and activated.', 'learnpress-instamojo-payment' ),
					self::$addon_info['Name'],
					self::$addon_info['Require_LP_Version']
				)
				?>
			</p>
		</div>
		<?php
	}
}

new LP_Addon_Instamojo_Payment_Preload();
