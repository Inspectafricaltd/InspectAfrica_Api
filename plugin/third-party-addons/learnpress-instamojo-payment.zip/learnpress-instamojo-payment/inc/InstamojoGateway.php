<?php

namespace LearnPress\Instamojo;

use Exception;
use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LP_Debug;
use LP_Gateway_Abstract;
use LP_Helper;

defined( 'ABSPATH' ) || exit;

/**
 * Instamojo payment gateway class.
 *
 * @author   ThimPress
 * @package  LearnPress/Instamojo/Classes
 * @version  4.0.1
 */
class InstamojoGateway extends LP_Gateway_Abstract {
	use Singleton;

	public $id = 'instamojo';
	/**
	 * @var null
	 */
	protected $client_id = null;

	/**
	 * @var null
	 */
	protected $client_secret = null;

	/**
	 * @var bool
	 */
	protected $test_mode = null;

	/**
	 * @var bool
	 */
	protected $enable = null;

	/**
	 * @var null
	 */
	protected $test_base_url = null;

	/**
	 * @var null
	 */
	protected $production_base_url = null;

	/**
	 * @var null
	 */
	protected $base_url = null;

	/**
	 * @var bool
	 */
	protected $floating_checkout = null;

	public function init() {
	}

	public function __construct() {
		$this->method_title       = 'Instamojo';
		$this->method_description = esc_html__( 'Make a payment with Instamojo.', 'learnpress-instamojo-payment' );
		$this->icon               = LP_ADDON_INSTAMOJO_PAYMENT_URL . 'assets/images/instamojo.png';
		parent::__construct();

		// Get settings.
		$this->title       = $this->settings->get( 'title' ) ?? $this->method_title;
		$this->description = $this->settings->get( 'description' );

		// enable settings if supports Rupee currency.
		if ( learn_press_get_currency() !== 'INR' ) {
			$this->enable = false;
		}

		if ( $this->is_enabled() ) {
			$this->test_base_url       = 'https://test.instamojo.com';
			$this->production_base_url = 'https://api.instamojo.com';
			$this->test_mode           = $this->settings->get( 'test_mode' ) === 'yes';
			$this->client_id           = $this->settings->get( 'client_id', '' );
			$this->client_secret       = $this->settings->get( 'client_secret', '' );
			$this->floating_checkout   = $this->settings->get( 'floating_checkout' ) === 'yes';
			$this->base_url            = $this->test_mode ? $this->test_base_url : $this->production_base_url;
			if ( $this->floating_checkout ) {
				$min = '.min';
				$ver = LP_ADDON_INSTAMOJO_PAYMENT_VER;
				if ( LP_Debug::is_debug() ) {
					$min = '';
					$ver = uniqid();
				}

				wp_enqueue_script(
					'instamojo',
					'https://js.instamojo.com/v1/checkout.js',
					'',
					'3.0',
					[ 'strategy' => 'defer' ]
				);
				wp_enqueue_script(
					'learn-press-instamojo',
					LP_ADDON_INSTAMOJO_PAYMENT_URL . 'assets/dist/js/instamojo' . $min . '.js',
					array( 'instamojo', 'lp-checkout' ),
					$ver,
					array( 'strategy' => 'defer' )
				);
			}
		}
	}

	/**
	 * Payment form.
	 */
	public function get_payment_form() {
		return __( 'Make a payment with Instamojo.', 'learnpress-instamojo-payment' );
	}

	/**
	 * Admin payment settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		if ( learn_press_get_currency() !== 'INR' ) {
			$url_settings_payment = admin_url( 'admin.php?page=learn-press-settings&tab=general' );
			$mess_error           = sprintf(
				'<p style="color:red;font-size: 14px;font-weight:600;">%s<span>%s<a href="%s">here</a></span></p>',
				__( 'The site\'s currency is not supported by Instamojo and the system only supports Rupee currency. ', 'learnpress-instamojo-payment' ),
				__( 'Please change the currency ', 'learnpress-instamojo-payment' ),
				$url_settings_payment
			);

			Template::print_message( $mess_error, 'error' );
		}

		return include_once LP_ADDON_INSTAMOJO_PAYMENT_PATH . '/config/settings.php';
	}

	/**
	 * Instamojo payment process.
	 *
	 * @param int $order_id
	 *
	 * @return array
	 * @throws string
	 */
	public function process_payment( $order_id ) {
		$result = array(
			'result'   => 'error',
			'redirect' => '',
		);
		$order  = learn_press_get_order( $order_id );

		if ( ! $order ) {
			throw new Exception( __( 'Invalid order', 'learnpress-instamojo-payment' ) );
		}

		$payment_request = $this->create_payment_request( $order );

		$result['result']   = $this->floating_checkout ? 'processing' : 'success';
		$result['redirect'] = $payment_request->longurl;

		return $result;
	}

	/**
	 * Update LP order
	 *
	 * @param string $mojo_id Instamojo payment ID (MOJOxxxxxxxxxxxx)
	 * @param int $lp_order_id LP order id
	 *
	 * @throws Exception
	 */
	public function update_order( string $mojo_id = '', int $lp_order_id = 0 ) {

		$lp_order = learn_press_get_order( $lp_order_id );

		if ( ! $lp_order ) {
			throw new Exception( __( 'Invalid LP Order.', 'learnpress-instamojo-payment' ) );
		}

		if ( $lp_order->is_completed() ) {
			return;
		}

		$payment_data = $this->get_payment_detail( $mojo_id );
		update_post_meta( $lp_order_id, '_lp_instamojo_payment_id', $mojo_id );
		if ( isset( $payment_data->status ) ) {
			if ( $payment_data->status === true ) {
				$lp_order->payment_complete();
			} else {
				if ( isset( $payment_data->failure ) && ! empty( $payment_data->failure ) ) {
					update_post_meta( $lp_order_id, '_mojo_failure_reason', $payment_data->failure );
				}
				$lp_order->update_status( LP_ORDER_FAILED );
			}
		}
	}

	/**
	 * Get Instamojo access token
	 *
	 * @return object token object
	 * @throws Exception
	 */
	public function get_access_token() {
		$response = wp_remote_post(
			$this->base_url . '/oauth2/token/',
			array(
				'body'    => array(
					'grant_type'    => 'client_credentials',
					'client_id'     => $this->client_id,
					'client_secret' => $this->client_secret,
				),
				'timeout' => 60,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new Exception( $response->get_error_message() );
		}

		$token_str = wp_remote_retrieve_body( $response );
		$token     = LP_Helper::json_decode( $token_str );
		if ( isset( $token->error ) ) {
			throw new Exception( __METHOD__ . ' - ' . $token->error );
		}

		if ( ! isset( $token->access_token ) || ! isset( $token->token_type ) ) {
			throw new Exception( __( 'Invalid access token', 'learnpress-instamojo-payment' ) );
		}

		return $token;
	}

	/**
	 * Create a payment request
	 *
	 * @param object $order LP Order
	 *
	 * @return object payment request details
	 * @throws Exception
	 */
	public function create_payment_request( $order ) {
		$token = $this->get_access_token();

		$payment_title = __( 'Order ', 'learnpress-instamojo-payment' ) . get_post_field( 'post_title', $order->get_id(), 'display' );
		$params        = array(
			'purpose'      => $payment_title,
			'amount'       => $order->get_total(),
			'send_email'   => true,
			'email'        => $order->get_checkout_email(),
			'redirect_url' => add_query_arg( 'lp_order_id_mojo_payment', $order->get_id(), $this->get_return_url( $order ) ),
		);

		$response = wp_remote_post(
			$this->base_url . '/v2/payment_requests/',
			array(
				'body'    => $params,
				'headers' => array(
					'Authorization' => $token->token_type . ' ' . $token->access_token,
				),
				'timeout' => 60,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new Exception( $response->get_error_message() );
		}

		$payment_data = LP_Helper::json_decode( wp_remote_retrieve_body( $response ) );
		if ( ! isset( $payment_data->id ) && ! isset( $payment_data->longurl ) ) {
			throw new Exception( __( 'Payment request is invalid.', 'learnpress-instamojo-payment' ) );
		}

		return $payment_data;
	}

	/**
	 * Get payment details
	 *
	 * @param string $mojo_id Instamojo payment ID
	 *
	 * @return object Instamojo payment response
	 * @throws Exception
	 */
	public function get_payment_detail( $mojo_id ) {
		$token = $this->get_access_token();
		if ( empty( $mojo_id ) ) {
			throw new Exception( __( 'MOJOID is invalid.', 'learnpress-instamojo-payment' ) );
		}
		$url      = sanitize_url( $this->base_url . '/v2/payments/' . $mojo_id );
		$response = wp_remote_get(
			$url,
			array(
				'headers' => array(
					'Authorization' => $token->token_type . ' ' . $token->access_token,
				),
				'timeout' => 60,
			)
		);
		$body     = LP_Helper::json_decode( wp_remote_retrieve_body( $response ) );
		if ( isset( $body->success ) && $body->success === false ) {
			throw new Exception( __( 'Failure to get Instamojo payment.', 'learnpress-instamojo-payment' ) );
		}

		return $body;
	}
}
