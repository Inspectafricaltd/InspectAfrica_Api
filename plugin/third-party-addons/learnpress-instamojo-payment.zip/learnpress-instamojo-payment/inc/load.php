<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Instamojo/Classes
 * @version  4.0.1
 */

use LearnPress\Instamojo\InstamojoGateway;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Instamojo_Payment' ) ) {
	/**
	 * Class LP_Addon_Instamojo_Payment
	 */
	final class LP_Addon_Instamojo_Payment extends LP_Addon {
		public static $instance;
		public $version         = LP_ADDON_INSTAMOJO_PAYMENT_VER;
		public $require_version = LP_ADDON_INSTAMOJO_PAYMENT_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_INSTAMOJO_PAYMENT_FILE;
		public $text_domain     = 'learnpress-instamojo-payment';

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * LP_Addon_Instamojo_Payment constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define LearnPress Instamojo payment constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_INSTAMOJO_PAYMENT_PATH', dirname( LP_ADDON_INSTAMOJO_PAYMENT_FILE ) );
			define( 'LP_ADDON_INSTAMOJO_PAYMENT_INC', LP_ADDON_INSTAMOJO_PAYMENT_PATH . '/inc/' );
			define( 'LP_ADDON_INSTAMOJO_PAYMENT_URL', plugin_dir_url( LP_ADDON_INSTAMOJO_PAYMENT_FILE ) );
			define( 'LP_ADDON_INSTAMOJO_PAYMENT_TEMPLATE', LP_ADDON_INSTAMOJO_PAYMENT_PATH . '/templates/' );
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			// add payment gateway class
			add_filter( 'learn-press/payment-methods', array( $this, 'add_payment' ) );
			if ( ! is_admin() ) {
				$this->listen_instamojo_callback();
			}
		}

		/**
		 * Add Instamojo to payment system.
		 *
		 * @param $methods
		 *
		 * @return mixed
		 */
		public function add_payment( $methods ) {
			$methods['instamojo'] = InstamojoGateway::instance();

			return $methods;
		}

		/**
		 * Plugin links.
		 *
		 * @return array
		 */
		public function plugin_links() {
			$links[] = sprintf(
				'<a href="%s" target="_blank">%s</a>',
				admin_url( 'admin.php?page=learn-press-settings&tab=payments&section=instamojo' ),
				esc_html__( 'Settings', 'learnpress-instamojo-payment' )
			);

			return $links;
		}

		/**
		 * Update LP order when redirect from Instamojo
		 */
		public function listen_instamojo_callback() {
			try {
				$mojo_id     = LP_Request::get_param( 'payment_id' );
				$lp_order_id = LP_Request::get_param( 'lp_order_id_mojo_payment' );
				if ( ! $lp_order_id ) {
					return;
				}
				if ( ! $mojo_id ) {
					return;
				}

				InstamojoGateway::instance()->update_order( $mojo_id, $lp_order_id );
			} catch ( Throwable $e ) {
				LP_Debug::var_dump( $e );
			}
		}
	}
}
