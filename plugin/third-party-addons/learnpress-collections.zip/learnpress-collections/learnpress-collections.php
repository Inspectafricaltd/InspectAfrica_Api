<?php
/**
 * Plugin Name: LearnPress - Collections
 * Plugin URI: https://thimpress.com/product/collections-add-on-for-learnpress/
 * Description: Collecting related courses into one collection by administrator.
 * Author: ThimPress
 * Version: 4.0.4
 * Author URI: http://thimpress.com
 * Tags: learnpress, collections
 * Text Domain: learnpress-collections
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Require_LP_Version: 4.2.9.3
 * Domain Path: /languages/
 * @package learnpress-collections
 */

use LearnPressCollection\Ajax\CollectionAjax;
use LearnPressCollection\Gutenberg\GutenbergHandleMain;
use LearnPressCollection\TemplateHooks\ListCollectionsTemplate;
use LearnPressCollection\TemplateHooks\SingleCollectionLearningTemplate;
use LearnPressCollection\TemplateHooks\SingleCollectionTemplate;

defined( 'ABSPATH' ) || exit;

const LP_ADDON_COLLECTIONS_FILE = __FILE__;
const LP_ADDON_COLLECTIONS_PATH = __DIR__;
const LP_PAGE_SINGLE_COLLECTION = 'lp_page_single_collection';
const LP_PAGE_COLLECTIONS       = 'lp_page_collections';

/**
 * Class LP_Addon_Collections_Preload
 */
class LP_Addon_Collections_Preload {
	/**
	 * @var array
	 */
	public static $addon_info = array();

	/**
	 * LP_Addon_Collections_Preload constructor.
	 */
	public function __construct() {
		$can_load = true;
		// Set Base name plugin.
		define( 'LP_ADDON_COLLECTIONS_BASENAME', plugin_basename( LP_ADDON_COLLECTIONS_FILE ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_COLLECTIONS_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_COLLECTIONS_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_COLLECTIONS_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );
		define( 'LP_ADDON_COLLECTIONS_URL', trailingslashit( plugins_url( '/', LP_ADDON_COLLECTIONS_FILE ) ) );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			$can_load = false;
		} elseif ( version_compare( LP_ADDON_COLLECTIONS_REQUIRE_VER, get_option( 'learnpress_version', '3.0.0' ), '>' ) ) {
			$can_load = false;
		}

		if ( ! $can_load ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );
			deactivate_plugins( LP_ADDON_COLLECTIONS_BASENAME );

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			return;
		}

		register_activation_hook( LP_ADDON_COLLECTIONS_FILE, array( $this, 'on_activate' ) );

		// Sure LP loaded.
		add_action( 'learn-press/ready', array( $this, 'load' ) );

		// Init ajax
		// Set priority after register_post_type to register capabilities for post type of LP.
		add_action( 'init', [ $this, 'load_ajax' ], 11 );
	}

	/**
	 * Load addon
	 */
	public function load() {
		include_once 'vendor/autoload.php';
		include_once 'inc/load.php';
		LP_Addon_Collections::instance();
		ListCollectionsTemplate::instance();
		SingleCollectionTemplate::instance();
		SingleCollectionLearningTemplate::instance();
		GutenbergHandleMain::instance();
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p><?php echo( 'Please active <strong>LearnPress version ' . LP_ADDON_COLLECTIONS_REQUIRE_VER . ' or later</strong> before active <strong>' . self::$addon_info['Name'] . '</strong>' ); ?>
			</p>
		</div>
		<?php
	}

	public function on_activate() {
		$this->create_page();
	}

	public function create_page() {
		$page_title = _x( 'Collections', 'static-page', 'learnpress-collections' );
		$page_slug  = 'collections';
		$page_id    = 'learn_press_collections_page_id';

		try {
			$collection_page = get_option( $page_id, false );
			if ( ! $collection_page || get_post_type( $collection_page ) !== 'page' && get_post_status( $collection_page ) !== 'publish' ) {
				$collection_page = LP_Helper::create_page(
					[
						'post_title' => $page_title,
						'post_name'  => $page_slug,
					],
					$page_id
				);

				$_REQUEST['settings']['pages']['collections'] = $collection_page;

			}
			flush_rewrite_rules();
		} catch ( Exception $e ) {
			error_log( $e->getMessage() );
		}
	}

	public function load_ajax() {
		CollectionAjax::catch_lp_ajax();
	}
}

new LP_Addon_Collections_Preload();
