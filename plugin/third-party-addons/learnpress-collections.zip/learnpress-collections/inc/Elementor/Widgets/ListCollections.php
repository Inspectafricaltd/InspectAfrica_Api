<?php
/**
 * Class ListPackage
 *
 * @sicne 4.0.4
 * @version 1.0.0
 */
namespace LearnPressCollection\Elementor\Widgets;

use Exception;
use LearnPress\Helpers\Template;
use LearnPress\ExternalPlugin\Elementor\LPElementorWidgetBase;
use LearnPress\ExternalPlugin\Elementor\Widgets\Course\SingleCourseBaseElementor;
use LearnPress\TemplateHooks\TemplateAJAX;
use LearnPressCollection\Filters\CollectionFilter;
use LearnPressCollection\Models\CollectionPostModel;
use LearnPressCollection\Models\CollectionPostsModel;
use LearnPressCollection\TemplateHooks\ListCollectionsTemplate;
use LP_Database;
use stdClass;
use Throwable;

class ListCollections extends LPElementorWidgetBase {
	use SingleCourseBaseElementor;

	public function __construct( $data = array(), $args = null ) {
		$this->title    = esc_html__( 'List Collections', 'learnpress-collections' );
		$this->name     = 'listcollections';
		$this->keywords = array( 'list collections' );
		$this->add_style_depends( 'learnpress-collection' );
		parent::__construct( $data, $args );
	}

	protected function register_controls() {
		$this->controls = require LP_COLLECTIONS_PATH . '/inc/Elementor/config/listcollections.php';
		parent::register_controls();
	}

	/**
	 * Show content of widget
	 *
	 * @return void
	 */
	protected function render() {
		try {
			$settings = $this->get_settings_for_display();

			$callback = [
				'class'  => get_class( $this ),
				'method' => 'render_collections',
			];

			$args           = lp_archive_skeleton_get_args();
			$args['id_url'] = 'list-collections';
			$args['limit']  = $settings['limit'] ?? 10;
			$args['column'] = $settings['column'] ?? 2;
			$id             = 0;

			if ( ! is_archive() && ! is_home() && ! is_search() ) {
				$id = get_the_ID();
			}

			$args['post_id']  = $id;
			$args['order_by'] = $settings['order_by'] ?? 'menu_order';
			$args['layout']   = $settings['layout'] ?? 'grid';

			$content_obj                     = self::render_collections( $args );
			$args['html_no_load_ajax_first'] = $content_obj->content;

			echo TemplateAJAX::load_content_via_ajax( $args, $callback );

		} catch ( Throwable $e ) {
			error_log( $e->getMessage() );
		}
	}

	/**
	 * Render collections
	 *
	 * @throws Exception
	 */
	public static function render_collections( array $data = [] ): stdClass {
		$content = new stdClass();
		$filter  = new CollectionFilter();
		CollectionPostsModel::handle_params_for_query_collections( $filter, $data );
		$filter->only_fields = [ 'ID' ];
		$filter->post_status = [ 'publish' ];
		$total_rows          = 0;

		// For case drug widget list collections to single collection page.
		$collectionModelCurrent = CollectionPostModel::find( $data['post_id'] ?? 0, true );
		if ( $collectionModelCurrent ) {
			$filter->where[] = LP_Database::getInstance()->wpdb->prepare( 'AND p.ID != %d', $data['post_id'] );
		}

		$collections = CollectionPostsModel::get_collections( $filter, $total_rows );

		$html_list = '';
		if ( ! $collections ) {
			$html_list = Template::print_message( __( 'No collections found', 'learnpress-collections' ), 'info', false );
		} else {
			foreach ( $collections as $collection ) {
				$collectionPostModel = CollectionPostModel::find( $collection->ID, true );
				if ( ! $collectionPostModel ) {
					continue;
				}

				$html_list .= ListCollectionsTemplate::render_collection( $collectionPostModel, $data );
			}
		}

		$section_collections = apply_filters(
			'learn-press/layout/list-collections/collections/section',
			[
				'wrap'        => sprintf( '<ul class="learn-press-collections" data-layout="%s" style="--columns: %s">', $data['layout'] ?? 'grid', $data['column'] ?? 2 ),
				'collections' => $html_list,
				'wrap_end'    => '</ul>',
			],
			$collections,
			$data
		);

		$content->content = Template::combine_components( $section_collections );

		return $content;
	}
}
