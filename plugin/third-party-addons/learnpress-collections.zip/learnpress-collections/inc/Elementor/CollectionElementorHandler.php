<?php
/**
 * Class PackageElementorHandler
 *
 * Hook to register widgets, dynamic tags, ... for LearnPress Elementor handler.
 *
 * @since 4.0.4
 * @version 1.0.0
 */
namespace LearnPressCollection\Elementor;

use LearnPress\Helpers\Singleton;
use LearnPressCollection\Elementor\Widgets\ListCollections;

class CollectionElementorHandler {
    use Singleton;

	/**
	 * Hooks to register widgets, dynamic tags, ...
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'lp/elementor/widgets', [ $this, 'register_widgets' ] );
	}

    /**
	 * @param $lp_widgets array
	 * @return mixed
	 */
	public function register_widgets( array $lp_widgets ): array {
		include_once LP_COLLECTIONS_PATH . '/inc/Elementor/Widgets/ListCollections.php';

		$lp_widgets['listcollections']   = ListCollections::class;

		return $lp_widgets;
	}
}