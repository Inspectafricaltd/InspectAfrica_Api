<?php

use Elementor\Controls_Manager;
use LearnPress\ExternalPlugin\Elementor\LPElementorControls;

$content_fields = LPElementorControls::add_fields_in_section(
	'content',
	esc_html__( 'Content', 'learnpress-upsell' ),
	Controls_Manager::TAB_CONTENT,
	[
		'layout'       => LPElementorControls::add_control_type_select(
			'layout',
			esc_html__( 'Layout', 'learnpress-collections' ),
			[
				'list' => esc_html__( 'List', 'learnpress-collections' ),
				'grid' => esc_html__( 'Grid', 'learnpress-collections' ),
			],
			'grid'
		),
        'order_by'      => LPElementorControls::add_control_type_select(
			'order_by',
			esc_html__( 'Order by', 'learnpress-collections' ),
			[
				'post_date'       => esc_html__( 'Default', 'learnpress-collections' ),
				'post_title'      => esc_html__( 'Title a-z', 'learnpress-collections' ),
				'post_title_desc' => esc_html__( 'Title z-a', 'learnpress-collections' ),
			],
			'post_date'
		),
		'limit'        => LPElementorControls::add_control_type(
			'limit',
			esc_html__( 'Limit', 'learnpress-collections' ),
			5,
			Controls_Manager::NUMBER,
			[
				'min' => -1,
				'max' => 100,
			]
		),
		'column'        => LPElementorControls::add_control_type(
			'column',
			esc_html__( 'Column', 'learnpress-collections' ),
			2,
			Controls_Manager::NUMBER,
			[
				'min' => -1,
				'max' => 100,
				'condition'    => [
					'layout' => 'grid',
				]
			]
		),
    ]
);

// Fields tab style
$style_fields = array_merge(
	LPElementorControls::add_fields_in_section(
		'title',
		esc_html__( 'Title Collection', 'learnpress-collections' ),
		Controls_Manager::TAB_STYLE,
		LPElementorControls::add_controls_style_text(
			'title',
			'.learn-press-collections .collection-title',
			[],
			[ 'text_display','text_background', 'text_background_hover' ]
		)
	),
	LPElementorControls::add_fields_in_section(
		'style_description',
		esc_html__( 'Description', 'learnpress-collections' ),
		Controls_Manager::TAB_STYLE,
		LPElementorControls::add_controls_style_text(
			'description',
			'.collection-short-description',
			[],
			[ 'text_display', 'text_color_hover', 'text_background', 'text_background_hover' ]
		)
	),
	LPElementorControls::add_fields_in_section(
		'btn_read_more',
		esc_html__( 'Button Read More', 'learnpress-collections' ),
		Controls_Manager::TAB_STYLE,
		LPElementorControls::add_controls_style_button(
			'button',
			'.collection-btn-read-more a'
		)
	)
);


return apply_filters(
	'learn-press/elementor/list-collections',
	array_merge(
		apply_filters(
			'learn-press/elementor/list-collections/tab-content',
			$content_fields
		),
		apply_filters(
			'learn-press/elementor/list-collections/tab-styles',
			$style_fields
		)
	)
);
