<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Collections/Classes
 * @version  3.0.1
 */

use LearnPress\Models\CourseModel;
use LearnPress\Helpers\Template;
use LearnPressCollection\Filters\CollectionFilter;
use LearnPressCollection\Gutenberg\Blocks\Legacy\ArchiveCollectionBlockLegacy;
use LearnPressCollection\Gutenberg\Blocks\Legacy\ListCollectionBlockLegacy;
use LearnPressCollection\Gutenberg\Blocks\Legacy\SingleCollectionBlockLegacy;
use LearnPressCollection\Gutenberg\Blocks\Legacy\SingleCollectionLearningBlockLegacy;
use LearnPressCollection\Gutenberg\Templates\ArchiveCollectionsBlockTemplate;
use LearnPressCollection\Gutenberg\Templates\SingleCollectionBlockTemplate;
use LearnPressCollection\Gutenberg\Templates\SingleCollectionLearningBlockTemplate;
use LearnPressCollection\Elementor\CollectionElementorHandler;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Collections' ) ) {
	/**
	 * Class LP_Addon_Collections
	 */
	class LP_Addon_Collections extends LP_Addon {
		public $version         = LP_ADDON_COLLECTIONS_VER;
		public $require_version = LP_ADDON_COLLECTIONS_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_COLLECTIONS_FILE;
		public $text_domain     = 'learnpress-collections';

		/**
		 * @var bool
		 */
		public static $in_loop = false;

		public static $instance = null;

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * LP_Addon_Collections constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
			add_action( 'widgets_init', array( $this, 'register_widget' ) );
		}

		/**
		 * Define Learnpress Collections constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_COLLECTIONS_PATH', dirname( LP_ADDON_COLLECTIONS_FILE ) );
			define( 'LP_COLLECTIONS_INC', LP_COLLECTIONS_PATH . '/inc/' );
			define( 'LP_COLLECTIONS_TEMPLATES', LP_COLLECTIONS_PATH . '/templates/' );
			define( 'LP_COLLECTION_CPT', 'lp_collection' );
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 *
		 * @since 3.0.0
		 */
		protected function _includes() {
			require_once LP_COLLECTIONS_INC . 'functions.php';
			require_once LP_COLLECTIONS_INC . 'lp-collections-metaboxes.php';
			require_once LP_COLLECTIONS_INC . 'class-lp-collection-post-type.php';
			require_once LP_COLLECTIONS_INC . 'widget.php';

			if ( is_plugin_active( 'elementor/elementor.php' ) ) {
				require_once LP_COLLECTIONS_PATH . '/inc/Elementor/CollectionElementorHandler.php';
				CollectionElementorHandler::instance();
			}
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			add_action( 'template_include', array( $this, 'template_loader' ), 10 );
			add_shortcode( 'learn_press_collection', array( $this, 'shortcode' ) );
			add_filter( 'learn-press/admin/settings-tabs-array', array( $this, 'admin_settings' ) );
			add_action( 'lp_course_data_setting_tab_content', array( $this, 'course_collections_meta_box' ) );
			add_filter( 'use_block_editor_for_post_type', array( $this, 'disable_gutenberg_for_post_types' ), 10, 2 );

			// Meta-box course tab.
			add_filter( 'learnpress/course/metabox/tabs', array( $this, 'add_metabox_collection' ), 10, 2 );
			add_action( 'learnpress_save_lp_course_metabox', array( $this, 'save_lp_course_metabox' ) );

			// Set posts per page for collection archive and taxonomy always = 1 to query self, page will not 404.
			add_action( 'pre_get_posts', array( $this, 'add_pre_get_posts' ), - 1 );

			add_filter( 'learn-press/config/block-templates', array( $this, 'add_block_templates' ), 20, 1 );
			add_filter( 'learn-press/config/block-elements', array( $this, 'add_block_elements' ), 10, 1 );
			add_filter( 'lp/settings/permalinks', array( $this, 'add_permalink_collection' ), 10, 2 );
			add_filter( 'learn-press/rewrite/rules', array( $this, 'add_rule_collection' ) );
			add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
			add_filter( 'learn-press/general-settings-fields', [ $this, 'general_settings_fields' ] );

			// Show page archive collections in admin bar.
			add_action( 'admin_bar_menu', array( $this, 'add_collection_admin_bar' ), 50 );

			add_filter( 'learn-press/admin-default-styles', array( $this, 'admin_enqueue_assets' ) );
			add_filter( 'learn-press/frontend-default-styles', [ $this, 'add_styles_frontend_default' ] );
			add_filter( 'learn-press/frontend-default-scripts', [ $this, 'add_scripts_frontend_default' ] );
			add_filter( 'learnpress/page/current', [ $this, 'add_page_collection' ], 10, 1 );
		}

		/**
		 * Collections meta box in admin course.
		 *
		 * @throws Exception
		 */
		public function course_collections_meta_box( $post ) {
			$options             = array();
			$course_id           = $post ? $post->ID : LP_Request::get_param( 'post', 0, 'int', 'post' );
			$filter              = new CollectionFilter();
			$filter->post_status = [ 'publish' ];
			$filter->limit       = -1;
			$filter->only_fields = [ 'ID', 'post_title' ];
			$filter->order_by    = 'p.ID';
			$filter->order       = 'DESC';
			$filter->query_count = false;

			$collections = LP_Post_DB::getInstance()->get_posts( $filter );
			foreach ( $collections as $collection ) {
				$options[ $collection->ID ] = $collection->post_title;
			}

			$collection = new LP_Meta_Box_Select_Field(
				esc_html__( 'Collections', 'learnpress-collections' ),
				esc_html__( 'Select collections that contains this course.', 'learnpress-collections' ),
				'',
				[
					'options'     => $options,
					'tom_select'  => true,
					'multiple'    => true,
					'multil_meta' => true,
				]
			);

			$collection->id = '_lp_course_collections';

			ob_start();
			$collection->output( $course_id );
			$html_output = ob_get_clean();

			$section = [
				'wrap'     => '<div id="lp_collections_course_data" class="lp-meta-box-course-panels">',
				'content'  => $html_output,
				'wrap_end' => '</div>',
			];

			echo Template::combine_components( $section );
		}

		/**
		 * @param $template
		 *
		 * @return string
		 */
		public function template_loader( $template ) {
			if ( wp_is_block_theme() ) {
				return $template;
			}

			if ( is_embed() ) {
				return $template;
			}

			global $post;
			$file = '';
			if ( LP_Page_Controller::page_current() === LP_PAGE_SINGLE_COLLECTION ) {
				// Check if the template is overridden by theme. Run code old.
				$is_override_coll_course    = Template::check_template_is_override( 'addons/collections/archive-collection-course.php' );
				$is_override_content_single = Template::check_template_is_override( 'addons/collections/content-single-collection.php' );
				$is_override_single         = Template::check_template_is_override( 'addons/collections/single-collection.php' );
				if ( $is_override_coll_course || $is_override_content_single || $is_override_single ) {
					$post->post_content .= '[learn_press_collection id="' . $post->ID . '" limit="10"]';
				}

				if ( self::is_page_collection_learning() ) {
					$file = 'single-collection/learning.php';
				} else {
					$file = 'single-collection.php';
				}
			} elseif ( LP_Page_Controller::page_current() === LP_PAGE_COLLECTIONS ) {
				$file = 'archive-collection.php';
			}

			if ( $file ) {
				$find     = learn_press_template_path() . "/addons/collections/{$file}";
				$template = locate_template( $find );
				if ( ! $template || ! realpath( $template ) ) {
					$template = LP_COLLECTIONS_TEMPLATES . $file;
				}
			}

			return $template;
		}

		/**
		 * Register new Collections widget
		 */
		public function register_widget() {
			register_widget( 'LP_Collections_Widget' );
		}

		/**
		 * Code old use shortcode to display courses in single collection, only for theme override using.
		 * When theme override by new way, this shortcode will remove.
		 *
		 * @param array $atts
		 *
		 * @return string
		 */
		public function shortcode( $atts = null ) {
			$atts = shortcode_atts(
				array(
					'id'    => 0,
					'limit' => 10,
				),
				$atts
			);
			ob_start();
			$id      = $atts['id'];
			$content = '';
			if ( $id ) {
				$courses = get_post_meta( $id, '_lp_collection_courses' );
				if ( ! $courses ) {
					$courses = array( 0 );
				}
				$limit    = absint( get_post_meta( $id, '_lp_collection_courses_per_page', true ) );
				$limit    = $limit ? $limit : $atts['limit'];
				$paged    = get_query_var( 'paged', 1 );
				$args     = array(
					'post_type'           => 'lp_course',
					'post_status'         => 'publish',
					'post__in'            => $courses,
					'ignore_sticky_posts' => 1,
					'paged'               => $paged,
					'posts_per_page'      => $limit,
					'offset'              => ( max( intval( $paged ) - 1, 0 ) ) * $limit,
				);
				$query    = new WP_Query( $args );
				$template = learn_press_collections_locate_template( 'archive-collection-course.php' );
				set_query_var( 'collection_page', $paged );
				include $template;
				wp_reset_postdata();
			}
			$content = ob_get_clean();

			return $content;
		}

		public function admin_settings( $tabs ) {
			$tabs['collections'] = include_once LP_ADDON_COLLECTIONS_PATH . '/inc/class-lp-collection-settings.php';
			return $tabs;
		}

		public function add_block_templates( $templates ) {
			$templates[] = new SingleCollectionBlockTemplate();
			$templates[] = new SingleCollectionLearningBlockTemplate();
			$templates[] = new ArchiveCollectionsBlockTemplate();
			return $templates;
		}

		public function add_block_elements( $elements ) {
			$elements[] = new ArchiveCollectionBlockLegacy();
			$elements[] = new SingleCollectionBlockLegacy();
			$elements[] = new SingleCollectionLearningBlockLegacy();
			$elements[] = new ListCollectionBlockLegacy();
			return $elements;
		}

		/**
		 * Get permalink slug for collections.
		 *
		 * @return string
		 * @since 4.0.2
		 * @version 1.0.0
		 */
		public static function get_permalink_slug(): string {
			$collection_slug_default = 'collection';
			try {
				$collection_slug = LP_Settings::instance()->get( 'collections.slug', 'collection' );
				if ( empty( $collection_slug ) ) {
					$collection_slug = $collection_slug_default;
				}
				$collection_slug = preg_replace( '!^/!', '', $collection_slug );
			} catch ( Throwable $e ) {
				$collection_slug = $collection_slug_default;
			}

			return $collection_slug;
		}

		public function disable_gutenberg_for_post_types( $current_status, $post_type ) {
			if ( $post_type === 'lp_collection' ) {
				return false;
			}
			return $current_status;
		}

		public function add_rule_collection( $rules ) {
			$collection_slug = LP_Addon_Collections::get_permalink_slug();
			$page_slug       = 'collections';
			$page_id         = learn_press_get_page_id( 'collections' );
			if ( $page_id ) {
				$page_slug = urldecode( get_post_field( 'post_name', $page_id ) );
			}

			// Rule archive collections
			$rules['archive-collection'][] = [
				"^{$page_slug}/?$" =>
					'index.php?post_type=' . LP_COLLECTION_CPT,
			];

			// Rule single collection
			$rules['single-collection'][] = [
				"^{$collection_slug}/([^/]+)/?$" =>
					'index.php?' . LP_COLLECTION_CPT . '=$matches[1]',
			];

			// Rule single collection learning
			$rules['single-collection'][] = [
				"^{$collection_slug}/([^/]+)/learning/?$" =>
					'index.php?' . LP_COLLECTION_CPT . '=$matches[1]&lp_collection_tab=learning',
			];

			return $rules;
		}

		public function add_permalink_collection( $setting ) {
			$permalink = [
				[
					'title' => esc_html__( 'Permalinks collections', 'learnpress-collections' ),
					'type'  => 'title',
				],
				[
					'title'   => esc_html__( 'Collection base', 'learnpress-collections' ),
					'type'    => 'text',
					'default' => 'collection',
					'id'      => 'collections[slug]',
				],
				[
					'type' => 'sectionend',
				],
			];

			return array_merge( $setting, $permalink );
		}

		public function add_metabox_collection( $tabs, $post_id ) {
			$course = CourseModel::find( $post_id, true );
			if ( ! $course ) {
				return $tabs;
			}

			/*if ( $course->is_offline() ) {
			return $tabs;
			}*/

			$tabs['course_collections'] = array(
				'label'    => esc_html__( 'Collections', 'learnpress-collections' ),
				'icon'     => 'dashicons-list-view',
				'target'   => 'lp_collections_course_data',
				'priority' => 60,
			);

			return $tabs;
		}

		public function save_lp_course_metabox( $post_id = 0 ) {
			$new_collections = isset( $_POST['_lp_course_collections'] ) ? (array) wp_unslash( $_POST['_lp_course_collections'] ) : array();
			$old_collections = get_post_meta( $post_id, '_lp_course_collections', false ) ?? array();
			$added           = array_diff( $new_collections, $old_collections );
			$removed         = array_diff( $old_collections, $new_collections );

			if ( $added ) {
				foreach ( $added as $collection ) {
					add_post_meta( $post_id, '_lp_course_collections', $collection, false );

					$courses = get_post_meta( $collection, '_lp_collection_courses', false );

					if ( ! in_array( $post_id, $courses ) ) {
						add_post_meta( $collection, '_lp_collection_courses', $post_id );
					}
				}
			}

			if ( $removed ) {
				foreach ( $removed as $collection ) {
					delete_post_meta( $post_id, '_lp_course_collections', $collection );

					$courses = get_post_meta( $collection, '_lp_collection_courses', false );

					if ( in_array( $post_id, $courses ) ) {
						delete_post_meta( $collection, '_lp_collection_courses', $post_id );
					}
				}
			}
		}

		public function add_collection_admin_bar( $wp_admin_bar ) {
			if ( ! current_user_can( 'administrator' ) ) {
				return;
			}

			$wp_admin_bar->add_node(
				array(
					'id'     => 'lp-collections',
					'parent' => 'site-name',
					'title'  => sprintf(
						'<span class="ab-label">%s</span>',
						__( 'View Page Collections', 'learnpress-collections' )
					),
					'href'   => home_url( LP_Addon_Collections::get_permalink_slug() ),
				)
			);
		}

		public function add_pre_get_posts( WP_Query $q ) {
			// Affect only the main query and not in admin
			if ( ! $q->is_main_query() && ! is_admin() ) {
				return;
			}

			// If theme override file archive content return.
			$is_override = Template::check_template_is_override( 'addons/collections/content-collection.php' );
			if ( $is_override ) {
				return;
			}

			if ( $q->is_post_type_archive( LP_COLLECTION_CPT )
			|| $q->is_tax( 'lp_collection_category' )
			|| $q->is_tax( 'lp_collection_tag' ) ) {
				$q->set( 'posts_per_page', 1 );
			}
		}

		public function add_query_vars( $vars ) {
			$vars[] = 'lp_collection_tab';
			return $vars;
		}

		public function general_settings_fields( $fields ) {
			$insert_position = 0;
			foreach ( $fields as $index => $field ) {
				if ( isset( $field['id'] ) && $field['id'] === 'term_conditions_page_id' ) {
					$insert_position = $index + 1;
					break;
				}
			}

			$new_field = array(
				'title'   => esc_html__( 'All collections page', 'learnpress' ),
				'id'      => 'collections_page_id',
				'default' => '',
				'type'    => 'pages-dropdown',
				'value'   => learn_press_get_page_id( 'collections' ),
			);

			if ( $insert_position === 0 ) {
				$fields[] = $new_field;
			} else {
				array_splice( $fields, $insert_position, 0, array( $new_field ) );
			}

			return $fields;
		}

		/**
		 * Admin assets.
		 * @since 4.0.2
		 * @version 1.0.0
		 */
		public function admin_enqueue_assets( $styles ) {
			$is_rtl = is_rtl() ? '-rtl' : '';
			$min    = '.min';
			$ver    = LP_ADDON_COLLECTIONS_VER;
			if ( LP_Debug::is_debug() ) {
				$ver = time();
				$min = '';
			}

			$styles['admin-collection'] = new LP_Asset_Key(
				$this->get_plugin_url( "/assets/dist/css/admin{$is_rtl}{$min}.css" ),
				[],
				[],
				0,
				0,
				$ver
			);

			return $styles;
		}

		/**
		 * Register frontend styles.
		 *
		 * @param array $styles
		 *
		 * @return array
		 * @since 4.0.3
		 * @version 1.0.0
		 */
		public function add_styles_frontend_default( $styles ) {
			$is_rtl = is_rtl() ? '-rtl' : '';
			$min    = '.min';
			$ver    = LP_ADDON_COLLECTIONS_VER;
			if ( LP_Debug::is_debug() ) {
				$ver = time();
				$min = '';
			}

			$styles['learnpress-collection'] = new LP_Asset_Key(
				$this->get_plugin_url( "assets/dist/css/collection{$is_rtl}{$min}.css" ),
				[],
				[
					LP_PAGE_SINGLE_COLLECTION,
					LP_PAGE_COLLECTIONS,
				],
				0,
				0,
				$ver
			);

			return $styles;
		}

		/**
		 * Register frontend scripts.
		 *
		 * @param array $scripts
		 *
		 * @return array
		 * @since 4.0.3
		 * @version 1.0.0
		 */
		public function add_scripts_frontend_default( $scripts ) {
			$_min_assets = '.min';
			$ver         = LP_ADDON_COLLECTIONS_VER;
			if ( LP_Debug::is_debug() ) {
				$_min_assets = '';
				$ver         = uniqid();
			}

			$scripts['single-collection'] = new LP_Asset_Key(
				$this->get_plugin_url( 'assets/dist/js/single-collection' . $_min_assets . '.js' ),
				[],
				[ LP_PAGE_SINGLE_COLLECTION ],
				0,
				0,
				$ver,
				[ 'strategy' => 'async' ]
			);

			return $scripts;
		}

		public function add_page_collection( $page ) {
			if ( is_singular( LP_COLLECTION_CPT ) ) {
				$page = LP_PAGE_SINGLE_COLLECTION;
			}

			if ( is_post_type_archive( LP_COLLECTION_CPT ) ) {
				$page = LP_PAGE_COLLECTIONS;
			}

			return $page;
		}

		/**
		 * Check is page single collection and tab learning.
		 *
		 * @return bool
		 * @since 4.0.2
		 * @version 1.0.0
		 */
		public static function is_page_collection_learning(): bool {
			global $wp;
			$vars = $wp->query_vars;
			$tab  = $vars['lp_collection_tab'] ?? '';
			return $tab === 'learning';
		}
	}
}
