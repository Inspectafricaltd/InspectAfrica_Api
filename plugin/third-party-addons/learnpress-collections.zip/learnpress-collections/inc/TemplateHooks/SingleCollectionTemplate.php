<?php
/**
 * Template hooks Single Collection.
 *
 * @since 4.0.2
 * @version 1.0.0
 */

namespace LearnPressCollection\TemplateHooks;

use Exception;
use LearnPress\Helpers\Template;
use LearnPress\Helpers\Singleton;
use LearnPress\Models\Courses;
use LearnPress\TemplateHooks\Course\ListCoursesTemplate;
use LearnPress\Models\CourseModel;
use LearnPress\TemplateHooks\Course\SingleCourseOfflineTemplate;
use LearnPress\TemplateHooks\Course\SingleCourseTemplate;
use LearnPress\TemplateHooks\Instructor\SingleInstructorTemplate;
use LearnPress\TemplateHooks\TemplateAJAX;
use LearnPress\TemplateHooks\UserTemplate;
use LearnPressCollection\Models\CollectionPostModel;
use LP_Addon_Collections;
use LP_Course_Filter;
use LP_Datetime;
use LP_Page_Controller;
use stdClass;
use Throwable;

class SingleCollectionTemplate {
	use Singleton;

	public function init() {
		add_filter( 'lp/rest/ajax/allow_callback', [ $this, 'allow_callback' ] );
		add_action( 'learn-press/single-collection/layout', [ $this, 'layout' ] );
		add_action( 'learn-press/layout/list-courses/item-li', [ $this, 'html_index_course' ], 10, 3 );
	}

	/**
	 * Allow callback for block
	 *
	 * @param array $callbacks.
	 *
	 * @return array
	 */
	public function allow_callback( array $callbacks ): array {
		/**
		 * @uses html_course_overview
		 */
		$callbacks[] = get_class( $this ) . ':html_course_overview';
		return $callbacks;
	}

	/**
	 * Render layout for single collection.
	 *
	 * @param array $data
	 *
	 * @throws Exception
	 * @version 1.0.1
	 * @since 4.0.2
	 */
	public function layout( array $data = [] ) {
		wp_enqueue_style( 'learnpress' );
		wp_enqueue_style( 'learnpress-collection' );
		wp_enqueue_script( 'lp-single-course' );

		$collection_id       = $data['collection_id'] ?? get_the_ID();
		$collectionPostModel = CollectionPostModel::find( $collection_id, true );
		if ( ! $collectionPostModel ) {
			echo Template::print_message( __( 'Collection not found', 'learnpress-collections' ), 'error', false );
			return;
		}

		$args                            = array_merge(
			lp_archive_skeleton_get_args(),
			[
				'id_url'        => 'collection-courses',
				'collection_id' => $collection_id,
			]
		);
		$content_obj                     = static::html_course_overview( $args );
		$args['html_no_load_ajax_first'] = $content_obj->content;
		$html_courses                    = TemplateAJAX::load_content_via_ajax(
			$args,
			[
				'class'  => get_class( $this ),
				'method' => 'html_course_overview',
			]
		);

		$info_meta = apply_filters(
			'learn-press/single-collection/layout/info-meta',
			[
				'wrapper'      => '<div class="collection-info-meta">',
				'duration'     => $this->html_duration( $collectionPostModel ),
				'total_course' => $this->html_total_course( $collectionPostModel ),
				'level'        => $this->html_level( $collectionPostModel ),
				'wrapper_end'  => '</div>',
			]
		);

		ob_start();
		learn_press_breadcrumb();
		$html_breadcrumb = ob_get_clean();

		$section_top = apply_filters(
			'learn-press/single-collection/layout/section-top',
			[
				'wrapper'            => '<div class="lp-collection-header">',
				'container'          => '<div class="lp-collection-header-content">',
				'wrapper_left'       => '<div class="lp-collection-header-left">',
				'breadcrumb'         => $html_breadcrumb,
				'title'              => $this->html_title( $collectionPostModel ),
				'excerpt'            => $this->html_excerpt( $collectionPostModel ),
				'info_meta'          => Template::combine_components( $info_meta ),
				'instructors'        => $this->html_instructor( $collectionPostModel ),
				'content_footer'     => '<div class="lp-collection-header__footer">',
				'btn_start'          => $this->html_button_enroll( $collectionPostModel ),
				'total_students'     => $this->html_total_student( $collectionPostModel ),
				'content_footer_end' => '</div>',
				'wrapper_left_end'   => '</div>',
				'wrapper_right'      => '<div class="lp-collection-header-right">',
				'image'              => $this->html_image(
					$collectionPostModel,
					[
						'image_size' => 'full',
						'is_link'    => false,
					]
				),
				'wrapper_right_end'  => '</div>',
				'container_end'      => '</div>',
				'wrapper_end'        => '</div>',
			],
			$collectionPostModel
		);

		$section = apply_filters(
			'learn-press/single-collection/layout/section',
			[
				'wrap'                => '<div class="lp-single-collection">',
				'section_top'         => Template::combine_components( $section_top ),
				'container'           => '<div class="lp-content-area">',
				'description'         => $this->html_description( $collectionPostModel ),
				'courses'             => $html_courses,
				'faqs'                => $this->html_faqs( $collectionPostModel ),
				'related_collections' => $this->html_related_collections( $collectionPostModel ),
				'container_end'       => '</div>',
				'wrap_end'            => '</div>',
			],
			$collectionPostModel
		);

		echo Template::combine_components( $section );
	}

	/**
	 * Generate HTML for the title of a collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 * @param array $data
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_title( CollectionPostModel $collectionPostModel, array $data = [] ): string {
		$tag     = esc_html( $data['tag'] ?? 'h1' );
		$is_link = $data['is_link'] ?? false;
		$title   = $collectionPostModel->get_the_title();

		$html = sprintf(
			'<%1$s class="collection-title">%2$s</%1$s>',
			$tag,
			$is_link ? sprintf(
				'<a href="%s" class="collection-permalink">%s</a>',
				esc_url_raw( $collectionPostModel->get_permalink() ),
				$title
			) : $title
		);

		return apply_filters(
			'learn-press/collection/html-title',
			$html,
			$collectionPostModel,
			$data
		);
	}

	/**
	 * Generate HTML for the read more button of a collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 * @param array $data
	 *
	 * @return string
	 */
	public function html_btn_read_more( CollectionPostModel $collectionPostModel, array $data = [] ): string {
		$html = apply_filters(
			'learn-press/collection/html-btn-read-more',
			[
				'wrapper'     => '<div class="collection-btn-read-more">',
				'link'        => sprintf(
					'<a href="%s" class="collection-permalink">%s</a>',
					$collectionPostModel->get_permalink(),
					__( 'Read more', 'learnpress' )
				),
				'wrapper_end' => '</div>',
			],
			$collectionPostModel,
			$data
		);

		return Template::combine_components( $html );
	}

	/**
	 * Generate HTML for the count total course of a collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 * @param array $data
	 *
	 * @return string
	 */
	public function html_course_count( CollectionPostModel $collectionPostModel, array $data = [] ): string {
		$course_count = $collectionPostModel->get_total_course() ?? 0;
		$html         = apply_filters(
			'learn-press/collection/html-course-count',
			[
				'wrap'       => '<div class="info-meta-item">',
				'info-left'  => '<span class="info-meta-left"><i class="lp-icon-file-o"></i></span>',
				'info-right' => sprintf(
					'<span class="info-meta-right">%d %s</span>',
					$course_count,
					_n( 'course', 'courses', $course_count, 'learnpress-collections' )
				),
				'wrap_end'   => '</div>',
			],
			$collectionPostModel,
			$data
		);

		return Template::combine_components( $html );
	}

	/**
	 * Generate HTML for the image of a collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 * @param array               $data
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_image( CollectionPostModel $collectionPostModel, array $data = [] ): string {
		$is_link    = $data['is_link'] ?? true;
		$image_size = $data['image_size'] ?? 'medium';
		$image_url  = $collectionPostModel->get_image_url( $image_size );

		$html = apply_filters(
			'learn-press/collection/html-image',
			[
				'link'     => $is_link ? sprintf(
					'<a href="%s">',
					$collectionPostModel->get_permalink()
				) : '',
				'wrap'     => '<div class="collection-img">',
				'img'      => sprintf(
					'<img src="%s" alt="%s">',
					esc_url_raw( $image_url ),
					esc_html__( 'Collection image', 'learnpress-collections' )
				),
				'wrap_end' => '</div>',
				'link_end' => $is_link ? '</a>' : '',
			],
			$collectionPostModel,
			$data
		);

		return Template::combine_components( $html );
	}

	/**
	 * Generate HTML for the description of a collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_description( CollectionPostModel $collectionPostModel ): string {
		$description = $collectionPostModel->get_the_content();
		if ( empty( $description ) ) {
			return '';
		}

		return apply_filters(
			'learn-press/collection/html-description',
			sprintf(
				'<div class="collection-description">%s</div>',
				wp_kses_post( $description )
			),
			$collectionPostModel
		);
	}

	/**
	 * Generate HTML for the description of a collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 * @param int $number_words
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_excerpt( CollectionPostModel $collectionPostModel, int $number_words = 0 ): string {
		$excerpt = $collectionPostModel->post_excerpt;

		if ( empty( $excerpt ) ) {
			return '';
		}

		$excerpt = $collectionPostModel->get_the_excerpt();

		$html_wrapper = [
			'<p class="collection-excerpt">' => '</p>',
		];

		if ( $number_words > 0 ) {
			$excerpt = wp_trim_words( $excerpt, $number_words, '...' );
		}

		return Template::instance()->nest_elements( $html_wrapper, $excerpt );
	}

	public function html_duration( CollectionPostModel $collectionPostModel ): string {
		$html     = '';
		$duration = $collectionPostModel->get_duration();
		if ( empty( $duration ) ) {
			return $html;
		}

		$duration_arr        = explode( ' ', $duration );
			$duration_number = floatval( $duration_arr[0] ?? 0 );
			$duration_type   = $duration_arr[1] ?? '';
		if ( empty( $duration_number ) ) {
			$duration_str = __( 'Lifetime', 'learnpress' );
		} else {
			$duration_str = LP_Datetime::get_string_plural_duration( $duration_number, $duration_type );
		}

		$section = [
			'wrap'       => '<div class="info-meta-item">',
			'info-left'  => '<span class="info-meta-left"><i class="lp-icon-clock-o"></i></span>',
			'info-right' => sprintf(
				'<span class="info-meta-right">%s</span>',
				$duration_str
			),
			'wrap_end'   => '</div>',
		];

		$html = Template::combine_components( $section );

		return $html;
	}

	public function html_level( CollectionPostModel $collectionPostModel ): string {
		$html   = '';
		$level  = $collectionPostModel->get_level();
		$levels = [
			'all'          => esc_html__( 'All levels', 'learnpress' ),
			'beginner'     => esc_html__( 'Beginner', 'learnpress' ),
			'intermediate' => esc_html__( 'Intermediate', 'learnpress' ),
			'expert'       => esc_html__( 'Expert', 'learnpress' ),
		];
		$level  = $levels[ $level ] ?? $levels['all'];
		$html   = apply_filters(
			'learn-press/collection/html-level',
			[
				'wrap'       => '<div class="info-meta-item">',
				'info-left'  => '<span class="info-meta-left"><i class="lp-icon-signal"></i></span>',
				'info-right' => sprintf(
					'<span class="info-meta-right">%s</span>',
					$level
				),
				'wrap_end'   => '</div>',
			],
			$collectionPostModel
		);

		return Template::combine_components( $html );
	}

	public function html_instructor( CollectionPostModel $collectionPostModel ): string {
		$html           = '';
		$instructor_ids = $collectionPostModel->get_instructor_ids();

		if ( empty( $instructor_ids ) ) {
			return $html;
		}

		$singleInstructorTemplate = SingleInstructorTemplate::instance();
		$userTemplate             = new UserTemplate( 'instructor' );

		$instructor_avatar = '';
		foreach ( $instructor_ids as $instructor ) {
			$instructor_avatar .= $userTemplate->html_avatar( $instructor );
		}

		$instructor_name = '';
		foreach ( $instructor_ids as $instructor ) {
			if ( ! empty( $instructor->display_name ) ) {
				$instructor_name .= sprintf(
					'<a class="collection-instructor__link" href="%s" >%s</a>',
					$instructor->get_url_instructor(),
					$singleInstructorTemplate->html_display_name( $instructor )
				);
			}
		}

		$html = [
			'wrapper'            => '<div class="collection-instructor">',
			'wrapper_avatar'     => '<div class="collection-instructor__avatar">',
			'avatar'             => $instructor_avatar,
			'wrapper_avatar_end' => '</div>',
			'title'              => sprintf(
				'<span class="collection-instructor__title">%s: </span>',
				__( 'Instructors', 'learnpress-collections' )
			),
			'wrapper_name'       => '<div class="collection-instructor__name">',
			'instructor_name'    => $instructor_name,
			'wrapper_name_end'   => '</div>',
			'wrapper_end'        => '</div>',
		];

		return Template::combine_components( $html );
	}

	/**
	 * HTML meta faqs
	 *
	 * @param CourseModel $courseModel
	 * @param array $data
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_faqs( CollectionPostModel $collectionPostModel ): string {
		$faqs = $collectionPostModel->get_faqs();
		if ( empty( $faqs ) ) {
			return '';
		}

		$section = apply_filters(
			'learn-press/collection/html-faqs',
			[
				'wrapper'     => '<div class="collection-faqs">',
				'title'       => sprintf(
					'<h3 class="collection-faqs__title">%s</h3>',
					__( 'Faqs', 'learnpress-collections' )
				),
				'content'     => $faqs,
				'wrapper_end' => '</div>',
			],
			$collectionPostModel
		);
		$html    = Template::combine_components( $section );

		return $html;
	}

	/**
	 * HTML total students
	 *
	 * @param CollectionPostModel $collectionPostModel
	 *
	 * @return string
	 * @throws Exception
	 * @version 1.0.0
	 * @since 4.0.3
	 */
	public function html_total_student( CollectionPostModel $collectionPostModel ): string {
		$users          = $collectionPostModel->get_users();
		$total_students = count( $users ) ?? 0;

		$html = apply_filters(
			'learn-press/collection/html-total-students',
			sprintf(
				'<div class="collection-total-students">%s</div>',
				sprintf(
					__( '%s people have already started the paths', 'learnpress-collections' ),
					$total_students
				)
			),
			$collectionPostModel,
			$total_students
		);

		return $html;
	}

	/**
	 * HTML button start learning for collection.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 *
	 * @return string
	 * @throws Exception
	 * @version 1.0.0
	 * @since 4.0.2
	 */
	public function html_button_enroll( CollectionPostModel $collectionPostModel ): string {
		$course_ids = $collectionPostModel->get_course_ids();
		if ( empty( $course_ids ) ) {
			return '';
		}

		$course = CourseModel::find( $course_ids[0], true );
		if ( ! $course ) {
			return '';
		}

		$current_user_id = get_current_user_id();

		if ( ! $current_user_id ) {
			$html_link = sprintf(
				'<a href="%s" class="lp-button lp-collection-btn collection-login">%s</a>',
				learn_press_get_login_url( $collectionPostModel->get_permalink() ),
				__( 'Login to Start Learning', 'learnpress-collections' )
			);

			$html_btn = apply_filters(
				'learn-press/collection/html-btn-start',
				[
					'wrapper'     => '<div class="collection-btn-start">',
					'content'     => $html_link,
					'wrapper_end' => '</div>',
				],
				$collectionPostModel
			);
			return Template::combine_components( $html_btn );
		}

		$users     = $collectionPostModel->get_users();
		$link      = $collectionPostModel->get_learning_link();
		$title     = __( 'Start Now', 'learnpress-collections' );
		$html_link = sprintf(
			'<form name="%1$s" class="%1$s" method="post" enctype="multipart/form-data">
				<input type="hidden" name="collection-id" value="%2$s"/>
				<button type="submit" class="lp-button lp-btn-collection-enroll" >
					%3$s
				</button>
			</form>',
			'lp-form-collection-enroll',
			$collectionPostModel->get_id(),
			$title
		);

		$total_course_finish = $collectionPostModel->get_total_course_finish() ?? 0;
		$total_course        = $collectionPostModel->get_total_course() ?? 0;

		if ( $total_course_finish >= $total_course && in_array( $current_user_id, $users ) ) {
			$title     = __( 'Completed', 'learnpress-collections' );
			$html_link = sprintf(
				'<div class="lp-button lp-collection-btn collection-completed">%s</div>',
				$title
			);
		} elseif ( in_array( $current_user_id, $users ) ) {
			$title     = __( 'Continue', 'learnpress-collections' );
			$html_link = sprintf(
				'<a href="%s" class="lp-button lp-collection-btn">%s</a>',
				esc_url_raw( $link ),
				$title
			);
		}

		$html_btn = apply_filters(
			'learn-press/collection/html-btn-start',
			[
				'wrapper'     => '<div class="collection-btn-start">',
				'content'     => $html_link,
				'wrapper_end' => '</div>',
			],
			$collectionPostModel
		);
		return Template::combine_components( $html_btn );
	}

	/**
	 * HTML total courses in collection
	 *
	 * @param CollectionPostModel $courseModel
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_total_course( CollectionPostModel $collectionPostModel ): string {
		$total_courses = $collectionPostModel->get_total_course() ?? 0;
		$html          = apply_filters(
			'learn-press/collection/html-course-count',
			[
				'wrap'       => '<div class="info-meta-item">',
				'info-left'  => '<span class="info-meta-left"><i class="lp-icon-file-o"></i></span>',
				'info-right' => sprintf(
					'<span class="info-meta-right">%d %s</span>',
					$total_courses,
					_n( 'Course', 'Courses', $total_courses, 'learnpress-collections' )
				),
				'wrap_end'   => '</div>',
			],
			$collectionPostModel,
			$total_courses
		);

		return Template::combine_components( $html );
	}

	/**
	 * HTML course overview
	 *
	 * @param array $settings
	 *
	 * @return stdClass
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_course_overview( array $settings = [] ): stdClass {
		$content          = new stdClass();
		$content->content = '';
		$collection_id    = $settings['collection_id'] ?? 0;
		$collectionModel  = CollectionPostModel::find( $collection_id, true );

		if ( ! $collectionModel ) {
			$content->content = Template::print_message(
				__( 'Collection not found', 'learnpress-collections' ),
				'error',
				false
			);
			return $content;
		}

		$course_ids = $collectionModel->get_course_ids();
		if ( ! $course_ids ) {
			$content->content = Template::print_message(
				__( 'No course found', 'learnpress' ),
				'info',
				false
			);
			return $content;
		}

		$html_list           = '';
		$total_rows          = 0;
		$filter              = new LP_Course_Filter();
		$filter->only_fields = [ 'DISTINCT(ID) AS ID' ];
		$filter->page        = $settings['paged'] ?? 1;
		$course_ids_str      = join( ',', $course_ids );
		$filter->where[]     = "AND p.ID IN ($course_ids_str)";
		$filter->limit       = -1;
		$filter->order       = 'DESC';
		$filter->order_by    = 'p.ID';

		$filter  = apply_filters(
			'learn-press/collection/courses/query',
			$filter,
			$settings
		);
		$courses = Courses::get_courses( $filter, $total_rows );

		if ( ! $courses ) {
			$content->content = Template::print_message( __( 'No course found', 'learnpress' ), 'info', false );
			return $content;
		}

		$i = 0;
		foreach ( $courses as $courseObj ) {
			$courseModel = CourseModel::find( $courseObj->ID, true );
			/*$html_list_item = [
				'wrapper_li'     => '<li class="course">',
				'course'         => $this->render_course( $courseModel ),
				'wrapper_li_end' => '</li>',
			];

			$html_list .= Template::combine_components( $html_list_item );*/

			$settings['course_index'] = ++$i;
			$html_list               .= ListCoursesTemplate::render_course( $courseModel, $settings );
		}

		$section_courses = [
			'title'       => sprintf(
				'<h3 class="collection-course-overview__title">%s</h3>',
				__( 'Course Overview', 'learnpress-collections' )
			),
			'wrapper'     => sprintf(
				'<ul class="collection-course-overview__content learn-press-courses lp-list-courses-no-css %1$s" data-layout="%1$s">',
				'list'
			),
			'courses'     => $html_list,
			'wrapper_end' => '</ul>',
		];

		$content->content = Template::combine_components( $section_courses );
		$content->paged   = $filter->page;

		return $content;
	}

	/**
	 * HTML course index
	 *
	 * @param array $section
	 * @param CourseModel $courseModel
	 * @param array $settings
	 *
	 * @return array
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_index_course( $section, $courseModel, $settings ) {
		if ( LP_Page_Controller::page_current() !== LP_PAGE_SINGLE_COLLECTION
			|| LP_Addon_Collections::is_page_collection_learning() ) {
			return $section;
		}

		$section_index = [
			'wrap'     => '<div class="course-index">',
			'content'  => sprintf( '%s %s', __( 'Course', 'learnpress' ), $settings['course_index'] ?? '' ),
			'wrap_end' => '</div>',
		];

		return Template::insert_value_to_position_array(
			$section,
			'after',
			'wrapper_div',
			'course-index',
			Template::combine_components( $section_index )
		);
	}

	public static function render_course( $course, array $settings = [] ): string {
		if ( ! $course instanceof CourseModel ) {
			$course = CourseModel::find( $course->get_id(), true );
		}
		$singleCourseTemplate = SingleCourseTemplate::instance();

		try {
			// New layout course item.

			// HTML top section, show image.
			$section_top = apply_filters(
				'learn-press/collection/course-item/image',
				[
					'wrapper'     => '<div class="course-thumbnail">',
					'img'         => sprintf(
						'<a href="%s">%s</a>',
						$course->get_permalink(),
						$singleCourseTemplate->html_image( $course )
					),
					'wrapper_end' => '</div>',
				],
				$course,
				$settings
			);

			$meta_data = apply_filters(
				'learn-press/collection/course-item/meta-data',
				[
					'student'  => $singleCourseTemplate->html_count_student( $course ),
					'duration' => $singleCourseTemplate->html_duration( $course ),
				],
				$course,
				$settings
			);

			if ( $course->is_offline() ) {
				$singleCourseOfflineTemplate = SingleCourseOfflineTemplate::instance();
				unset( $meta_data['student'] );
				$html_address = $singleCourseOfflineTemplate->html_address( $course );
				if ( ! empty( $html_address ) ) {
					$meta_data['address'] = $singleCourseOfflineTemplate->html_address( $course );
				}
			}

			$html_meta_data = '';
			if ( ! empty( $meta_data ) ) {
				foreach ( $meta_data as $k => $v ) {
					$html_meta_data .= sprintf( '<div class="meta-item meta-item-%s">%s</div>', $k, $v );
				}

				$html_meta_data = sprintf( '<div class="course-wrap-meta">%s</div>', $html_meta_data );
			}

			// HTML bottom section.
			$html_categories = $singleCourseTemplate->html_categories( $course );
			if ( ! empty( $html_categories ) ) {
				$html_categories = sprintf(
					'<div>%s %s</div>',
					sprintf( '<label>%s</label>', __( 'in', 'learnpress' ) ),
					$html_categories
				);
			}
			$section_bottom = apply_filters(
				'learn-press/collection/course-item/content',
				[
					'wrapper'                     => '<div class="course-content">',
					'title'                       => sprintf(
						'<h3 class="wap-course-title"><a class="course-permalink" href="%s">%s</a></h3>',
						$course->get_permalink(),
						$singleCourseTemplate->html_title( $course )
					),
					'featured'                    => $singleCourseTemplate->html_featured( $course ),
					'wrapper_instructor_cate'     => '<div class="course-instructor-category">',
					'instructor'                  => sprintf(
						'<div>%s %s</div>',
						sprintf( '<label>%s</label>', __( 'by', 'learnpress' ) ),
						$singleCourseTemplate->html_instructor( $course )
					),
					'category'                    => $html_categories,
					'wrapper_instructor_cate_end' => '</div>',
					'meta'                        => $html_meta_data,
					'description'                 => $singleCourseTemplate->html_short_description( $course, 50 ),
					'wrapper_end'                 => '</div>',
				],
				$course,
				$settings
			);

			$section = apply_filters(
				'learn-press/collection/course-item',
				[
					'wrapper_div'     => sprintf( '<div class="course-item" data-id="%s">', esc_attr( $course->get_id() ) ),
					'top'             => Template::combine_components( $section_top ),
					'bottom'          => Template::combine_components( $section_bottom ),
					'wrapper_div_end' => '</div>',
				],
				$course,
				$settings
			);

			// For old themes use old hook.
			$section = ListCoursesTemplate::fix_theme_course_old( $section, $course, $settings );
			// End.

			$html_item = Template::combine_components( $section );
			// End new layout course item.
		} catch ( Throwable $e ) {
			$html_item = $e->getMessage();
		}

		return $html_item;
	}

	/**
	 * HTML related collections
	 *
	 * @param CollectionPostModel $collectionPostModel
	 *
	 * @return string
	 * @throws Exception
	 * @version 1.0.0
	 * @since 4.0.3
	 */
	public function html_related_collections( CollectionPostModel $collectionPostModel ): string {
		$html_list           = '';
		$related_collections = $collectionPostModel->get_related_collections();
		if ( empty( $related_collections ) ) {
			return $html_list;
		}

		foreach ( $related_collections as $collection ) {
			$html_list .= ListCollectionsTemplate::instance()->render_collection( $collection );
		}

		$section_collections = apply_filters(
			'learn-press/list-collections/related',
			[
				'wrapper_section'        => '<div class="collection-related">',
				'section_title'          => sprintf(
					'<h3 class="collection-related__title">%s</h3>',
					__( 'Related Collection', 'learnpress-collections' )
				),
				'wrapper_collection'     => '<ul class="learn-press-collections">',
				'collections'            => $html_list,
				'end_wrapper_collection' => '</ul>',
				'end_wrapper_section'    => '</div>',
			],
			$collectionPostModel
		);

		return Template::combine_components( $section_collections );
	}
}
