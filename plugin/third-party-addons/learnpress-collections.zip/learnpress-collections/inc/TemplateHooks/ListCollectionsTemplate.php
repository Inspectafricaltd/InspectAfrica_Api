<?php
/**
 * Template hooks List Collections.
 *
 * @since 4.0.2
 * @version 1.0.0
 */

namespace LearnPressCollection\TemplateHooks;

use Exception;
use LearnPress\Helpers\Template;
use LearnPress\Helpers\Singleton;
use LearnPress\TemplateHooks\TemplateAJAX;
use LearnPressCollection\Filters\CollectionFilter;
use LearnPressCollection\Models\CollectionPostModel;
use LearnPressCollection\Models\CollectionPostsModel;
use LP_Database;
use stdClass;

class ListCollectionsTemplate {
	use Singleton;

	public function init() {
		add_action( 'learn-press/list-collections/layout', [ $this, 'layout_collections' ] );
		add_filter( 'lp/rest/ajax/allow_callback', [ $this, 'allow_callback' ] );
	}

	/**
	 * Allow callback for AJAX request.
	 *
	 * @param array $callbacks
	 *
	 * @return array
	 */
	public function allow_callback( array $callbacks ): array {
		/**
		 * @uses self::render_collections()
		 */
		$callbacks[] = get_class( $this ) . ':render_collections';

		return $callbacks;
	}

	/**
	 * Render html layout for archive collections.
	 *
	 * @param array $data
	 * @throws Exception
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function layout_collections( array $data = [] ) {
		wp_enqueue_style( 'learnpress' );

		$callback = [
			'class'  => get_class( $this ),
			'method' => 'render_collections',
		];

		$args           = lp_archive_skeleton_get_args();
		$args['id_url'] = 'list-collections';

		$content_obj                     = static::render_collections( $args );
		$args['html_no_load_ajax_first'] = $content_obj->content;
		$content                         = TemplateAJAX::load_content_via_ajax( $args, $callback );

		$section = apply_filters(
			'learn-press/layout/list-collections/section',
			[
				'container'     => '<div class="lp-content-area">',
				'wrap'          => '<div class="learn-press-collections-wrapper">',
				'title'         => sprintf(
					'<h1 class="lp-collections-archive-title">%s</h1>',
					__( 'Collections', 'learnpress-collections' )
				),
				'content'       => $content,
				'wrap_end'      => '</div>',
				'container_end' => '</div>',
			],
			$content_obj,
			$args
		);

		echo Template::combine_components( $section );
	}

	/**
	 * Render html list collections.
	 *
	 * @throws Exception
	 * @since 4.0.2
	 * @version 1.0.1
	 */
	public static function render_collections( array $data = [] ): stdClass {
		$content    = new stdClass();
		$total_rows = 0;

		$filter              = new CollectionFilter();
		$filter->only_fields = [ 'ID' ];
		$filter->post_status = [ 'publish' ];
		CollectionPostsModel::handle_params_for_query_collections( $filter, $data );

		$collections = CollectionPostsModel::get_collections( $filter, $total_rows );
		$total_pages = LP_Database::get_total_pages( $filter->limit, $total_rows );

		$html_list = '';
		if ( ! $collections ) {
			$html_list = Template::print_message( __( 'No collections found', 'learnpress-collections' ), 'info', false );
		} else {
			foreach ( $collections as $collection ) {
				$collectionPostModel = CollectionPostModel::find( $collection->ID, true );
				if ( ! $collectionPostModel ) {
					continue;
				}

				$html_list .= self::render_collection( $collectionPostModel, $data );
			}
		}

		$section_collections = apply_filters(
			'learn-press/layout/list-collections/collections/section',
			[
				'wrap'        => '<ul class="learn-press-collections">',
				'collections' => $html_list,
				'wrap_end'    => '</ul>',
			],
			$collections,
			$data
		);

		$section = [
			'list_collections' => Template::combine_components( $section_collections ),
			'pagination'       => self::instance()->html_collection_pagination(
				[
					'total_pages' => $total_pages,
					'base'        => add_query_arg( 'paged', '%#%', '' ),
					'paged'       => $data['paged'] ?? 1,
				]
			),
		];

		$content->content     = Template::combine_components( $section );
		$content->total_pages = $total_pages;
		$content->paged       = $filter->page;

		return $content;
	}

	/**
	 * Render a single collection item.
	 *
	 * @param CollectionPostModel $collectionPostModel
	 * @param array               $data
	 *
	 * @return string
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public static function render_collection( CollectionPostModel $collectionPostModel, array $data = [] ): string {
		$singleCollectionTemplate = SingleCollectionTemplate::instance();

		$section = apply_filters(
			'learn-press/layout/list-collections/item/section',
			[
				'wrap'             => sprintf(
					'<li class="collection" data-id="%s">',
					esc_attr( $collectionPostModel->ID )
				),
				'img'              => $singleCollectionTemplate->html_image( $collectionPostModel, $data ),
				'wrap_content'     => '<div class="collection__content">',
				'title'            => $singleCollectionTemplate->html_title(
					$collectionPostModel,
					[
						'tag'     => 'h2',
						'is_link' => true,
					]
				),
				'course_count'     => $singleCollectionTemplate->html_course_count( $collectionPostModel ),
				'short_des'        => $singleCollectionTemplate->html_excerpt( $collectionPostModel, 10 ),
				'btn_read_more'    => $singleCollectionTemplate->html_btn_read_more( $collectionPostModel ),
				'wrap_content_end' => '</div>',
				'wrap_end'         => '</li>',
			],
			$collectionPostModel,
			$data
		);

		return Template::combine_components( $section );
	}

	/**
	 * Generate HTML for pagination of collections.
	 *
	 * @param array $data
	 *
	 * @return string HTML for pagination.
	 */
	public function html_collection_pagination( array $data = [] ): string {
		if ( empty( $data['total_pages'] ) || $data['total_pages'] <= 1 ) {
			return '';
		}

		$html_wrapper = $data['wrapper'] ?? [
			'<nav class="learn-press-pagination navigation pagination">' => '</nav>',
		];

		$pagination = paginate_links(
			apply_filters(
				'learn_press_pagination_args',
				array(
					'base'      => $data['base'] ?? '',
					'format'    => '',
					'add_args'  => '',
					'current'   => max( 1, $data['paged'] ?? 1 ),
					'total'     => $data[ 'total_pages' ?? 1 ],
					'prev_text' => '<i class="lp-icon-arrow-left"></i>',
					'next_text' => '<i class="lp-icon-arrow-right"></i>',
					'type'      => 'list',
					'end_size'  => 3,
					'mid_size'  => 3,
				)
			)
		);

		return Template::instance()->nest_elements( $html_wrapper, $pagination );
	}
}
