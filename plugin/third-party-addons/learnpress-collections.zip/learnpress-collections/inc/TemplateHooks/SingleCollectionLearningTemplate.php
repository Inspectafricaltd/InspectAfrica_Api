<?php
/**
 * Template hooks Single Collection.
 *
 * @since 4.0.2
 * @version 1.0.0
 */

namespace LearnPressCollection\TemplateHooks;

use Exception;
use LearnPress\Helpers\Template;
use LearnPress\Helpers\Singleton;
use LearnPress\Models\Courses;
use LearnPress\TemplateHooks\Course\ListCoursesTemplate;
use LearnPress\Models\CourseModel;
use LearnPress\Models\UserItems\UserCourseModel;
use LearnPress\Models\UserItems\UserItemModel;
use LearnPress\Models\UserModel;
use LearnPress\TemplateHooks\Course\SingleCourseModernLayout;
use LearnPress\TemplateHooks\Course\SingleCourseTemplate;
use LearnPress\TemplateHooks\TemplateAJAX;
use LearnPressCollection\Models\CollectionPostModel;
use LP_Addon_Collections;
use LP_Course_Filter;
use LP_Database;
use LP_Helper;
use LP_Page_Controller;
use stdClass;
use Throwable;

class SingleCollectionLearningTemplate {
	use Singleton;

	public function init() {
		add_filter( 'lp/rest/ajax/allow_callback', [ $this, 'allow_callback' ] );
		add_action( 'learn-press/single-collection-learning/layout', [ $this, 'layout' ] );
		add_filter( 'learn_press_get_breadcrumb', [ $this, 'add_breadcrumb_learning' ] );
		add_filter( 'learn-press/layout/list-courses/item/section/bottom', [ $this, 'html_course_progress' ], 10, 3 );
		add_filter( 'learn-press/layout/list-courses/item/section/bottom/end', [ $this, 'html_course_button' ], 10, 3 );
	}

	/**
	 * Allow callback for block
	 *
	 * @param array $callbacks.
	 *
	 * @return array
	 */
	public function allow_callback( array $callbacks ): array {
		/**
		 * @uses html_course_learning
		 */
		$callbacks[] = get_class( $this ) . ':html_course_learning';

		return $callbacks;
	}

	/**
	 * Render layout for single collection.
	 *
	 * @param array $data
	 *
	 * @throws Exception
	 * @version 1.0.0
	 * @since 4.0.2
	 */
	public function layout( array $data = [] ) {
		wp_enqueue_style( 'learnpress' );
		wp_enqueue_script( 'lp-single-course' );

		$collection_id = $data['collection_id'] ?? get_the_ID();

		$collectionPostModel = CollectionPostModel::find( $collection_id, true );
		if ( ! $collectionPostModel ) {
			echo Template::print_message( __( 'Collection not found', 'learnpress-collections' ), 'error', false );
			return;
		}

		ob_start();
		learn_press_breadcrumb();
		$html_breadcrumb = ob_get_clean();

		$html_header = apply_filters(
			'learn-press/single-collection-learning/layout/section-top',
			[
				'wrapper'        => '<div class="lp-collection-learning__header">',
				'container'      => '<div class="lp-collection-learning__header-content">',
				'breadcrumb'     => $html_breadcrumb,
				'title_learning' => sprintf(
					'<h1 class="colleciton-learning__title">%s</h1>',
					__( 'Your Learning', 'learnpress-collections' )
				),
				'container_end'  => '</div>',
				'wrapper_end'    => '</div>',
			]
		);

		$args_learning                            = array_merge(
			lp_archive_skeleton_get_args(),
			[
				'id_url'        => 'collection-courses-learning',
				'collection_id' => $collection_id,
			]
		);
		$content_obj_learning                     = static::html_course_learning( $args_learning );
		$args_learning['html_no_load_ajax_first'] = $content_obj_learning->content;
		$html_courses_learning                    = TemplateAJAX::load_content_via_ajax(
			$args_learning,
			[
				'class'  => get_class( $this ),
				'method' => 'html_course_learning',
			]
		);

		$learning = apply_filters(
			'learn-press/single-collection/layout/learning',
			[
				'wrapper'          => '<div class="lp-collection-learning__info lp-content-area">',
				'title_collection' => SingleCollectionTemplate::instance()->html_title(
					$collectionPostModel,
					[
						'tag'     => 'h2',
						'is_link' => true,
					]
				),
				'learning'         => $this->html_collection_progress( $collectionPostModel ),
				'course_learning'  => $html_courses_learning,
				'wrapper_end'      => '</div>',
			],
			$collectionPostModel
		);

		if ( ! is_user_logged_in() ) {
			$error_message = sprintf(
				__( 'Please %s in to enroll in the collection!', 'learnpress-collections' ),
				sprintf(
					'<a class="lp-link-login" href="%s">%s</a>',
					learn_press_get_login_url( $collectionPostModel->get_permalink() ),
					__( 'login', 'learnpress-collections' )
				)
			);
			$learning      = apply_filters(
				'learn-press/single-collection/layout/learning',
				[
					'wrapper'       => '<div class="lp-content-area">',
					'error'         => '<div class="learn-press-message error">',
					'error_message' => $error_message,
					'error_end'     => '</div>',
					'wrapper_end'   => '</div>',
				],
				$collectionPostModel
			);
		}

		$users = $collectionPostModel->get_users();
		if ( get_current_user_id() && ! in_array( get_current_user_id(), $users ) ) {
			$error_message = sprintf(
				__( 'This content is protected. Please %s in the collection to view this content!', 'learnpress-collections' ),
				sprintf(
					'<a class="lp-link-login" href="%s">%s</a>',
					$collectionPostModel->get_permalink(),
					__( 'enroll', 'learnpress-collections' )
				)
			);
			$learning      = apply_filters(
				'learn-press/single-collection/layout/learning',
				[
					'wrapper'       => '<div class="lp-content-area">',
					'error'         => '<div class="learn-press-message error">',
					'error_message' => $error_message,
					'error_end'     => '</div>',
					'wrapper_end'   => '</div>',
				],
				$collectionPostModel
			);
		}

		$section = apply_filters(
			'learn-press/single-collection-learning/layout/section',
			[
				'container'     => '<div class="lp-collection-learning">',
				'header'        => Template::combine_components( $html_header ),
				'learning'      => Template::combine_components( $learning ),
				'container_end' => '</div>',
			],
			$collectionPostModel
		);

		echo Template::combine_components( $section );
	}

	/**
	 * Render layout for list courses include on Collection.
	 *
	 * @param array $settings
	 *
	 * @return stdClass
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public static function html_course_learning( array $settings = [] ): stdClass {
		$content          = new stdClass();
		$content->content = '';
		$collection_id    = $settings['collection_id'] ?? 0;
		$collectionModel  = CollectionPostModel::find( $collection_id, true );

		if ( ! $collectionModel ) {
			$content->content = Template::print_message( __( 'Collection not found', 'learnpress-collections' ), 'error', false );
			return $content;
		}

		$html_list           = '';
		$total_rows          = 0;
		$filter              = new LP_Course_Filter();
		$filter->only_fields = [ 'DISTINCT(ID) AS ID' ];
		$filter->page        = $settings['paged'] ?? 1;
		$course_ids          = join( ',', $collectionModel->get_course_ids() );
		$filter->where[]     = "AND p.ID IN ($course_ids)";
		$filter->limit       = $collectionModel->get_course_per_page();
		$filter->order       = 'DESC';
		$filter->order_by    = 'p.ID';

		$filter      = apply_filters(
			'learn-press/collection/courses/query',
			$filter,
			$settings
		);
		$courses     = Courses::get_courses( $filter, $total_rows );
		$total_pages = LP_Database::get_total_pages( $filter->limit, $total_rows );

		if ( ! $courses ) {
			$content->content = Template::print_message( __( 'No course found', 'learnpress-collections' ), 'info', false );
			return $content;
		}

		foreach ( $courses as $course ) {
			$course = CourseModel::find( $course->ID, true );
			//$html_list .= static::render_course_progress( $course );
			$html_list .= ListCoursesTemplate::render_course( $course, $settings );
		}

		$section_courses = [
			'wrapper'     => sprintf( '<ul class="collection-course-progress learn-press-courses lp-list-courses-no-css %1$s" data-layout="%1$s">', 'list' ),
			'courses'     => $html_list,
			'wrapper_end' => '</ul>',
		];

		$data_pagination = [
			'total_pages' => $total_pages,
			'base'        => add_query_arg( 'paged', '%#%', $settings['url_current'] ?? '' ),
			'paged'       => $filter->page,
		];
		$html_pagination = ListCoursesTemplate::instance()->html_pagination( $data_pagination );

		$section = apply_filters(
			'learn-press/layout/single-collection/courses',
			[
				'courses'    => Template::combine_components( $section_courses ),
				'pagination' => $html_pagination,
			],
			$courses,
			$settings
		);

		$content          = new stdClass();
		$content->content = Template::combine_components( $section );
		$content->paged   = $filter->page;

		return $content;
	}

	/**
	 * HTML course progress in list courses.
	 *
	 * @param array  $section
	 * @param CourseModel $courseModel
	 * @param array  $settings
	 *
	 * @return array
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_course_progress( $section, $courseModel, $settings ) {
		$user_id         = get_current_user_id();
		$is_from_request = $_REQUEST['id_url'] ?? '';

		if ( ! LP_Addon_Collections::is_page_collection_learning()
			&& $is_from_request !== 'collection-courses-learning' ) {
			return $section;
		}

		if ( ! $user_id ) {
			return $section;
		}

		$userCourseModel = UserCourseModel::find( $user_id, $courseModel->get_id(), true );
		if ( ! $userCourseModel instanceof UserCourseModel ||
			$userCourseModel->get_status() === UserItemModel::STATUS_CANCEL ||
			$userCourseModel->get_status() === UserItemModel::STATUS_PURCHASED ) {
			return $section;
		}

		// Course Progress
		$calculate         = $userCourseModel->calculate_course_results();
		$passing_condition = $courseModel->get_passing_condition();
		$html_percentage   = sprintf(
			'<div class="course-progress__line">
				<div class="course-progress__line__active" style="width: %s%%"></div>
				<div class="course-progress__line__point" style="left: %s%%"></div>
			</div>',
			$calculate['result'],
			$passing_condition
		);

		return Template::insert_value_to_position_array( $section, 'after', 'title', 'course-progress', $html_percentage );
	}

	/**
	 * HTML course progress in list courses.
	 *
	 * @param array  $section
	 * @param CourseModel $courseModel
	 * @param array  $settings
	 *
	 * @return array
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public function html_course_button( $section, $courseModel, $settings ) {
		$is_from_request = $_REQUEST['id_url'] ?? '';

		if ( LP_Page_Controller::page_current() != LP_PAGE_SINGLE_COLLECTION
			&& $is_from_request !== 'collection-courses-learning' ) {
			return $section;
		}

		$userModel    = UserModel::find( get_current_user_id(), true );
		$html_buttons = SingleCourseModernLayout::instance()->html_buttons( $courseModel, $userModel );

		$section['btn_read_more'] = '';

		return Template::insert_value_to_position_array( $section, 'after', 'btn_read_more', 'course-buttons', $html_buttons );
	}

	public static function render_course_progress( $course, array $settings = [] ): string {
		if ( ! $course instanceof CourseModel ) {
			$course = CourseModel::find( $course->get_id(), true );
		}
		$singleCourseTemplate     = SingleCourseTemplate::instance();
		$singleCourseModernLayout = SingleCourseModernLayout::instance();

		try {
			$user_id = get_current_user_id();
			// New layout course item.
			$userModel = UserModel::find( $user_id, true );

			// HTML top section, show image.
			$section_top = apply_filters(
				'learn-press/collection/learning/course-item/image',
				[
					'wrapper'     => '<div class="course-thumbnail">',
					'img'         => sprintf(
						'<a href="%s">%s</a>',
						$course->get_permalink(),
						$singleCourseTemplate->html_image( $course )
					),
					'wrapper_end' => '</div>',
				],
				$course,
				$settings
			);

			// HTML bottom section.
			$html_categories = $singleCourseTemplate->html_categories( $course );
			if ( ! empty( $html_categories ) ) {
				$html_categories = sprintf(
					'<div>%s %s</div>',
					sprintf( '<label>%s</label>', __( 'in', 'learnpress-collections' ) ),
					$html_categories
				);
			}

			// Course Progress
			$userCourseModel = UserCourseModel::find( $user_id, $course->get_id(), true );
			$calculate       = [];
			if ( $userCourseModel instanceof UserCourseModel
			&& $userCourseModel->get_status() !== UserItemModel::STATUS_CANCEL
			&& $userCourseModel->get_status() !== UserCourseModel::STATUS_PURCHASED
			&& $userModel ) {
				$calculate = $userCourseModel->calculate_course_results();
			} else {
				$calculate['result'] = 0;
			}

			$passing_condition = $course->get_passing_condition();
			$html_percentage   = sprintf(
				'<div class="course-progress__line">
							<div class="course-progress__line__active" style="width: %s%%"></div>
							<div class="course-progress__line__point" style="left: %s%%"></div>
					</div>',
				$calculate['result'],
				$passing_condition
			);

			$section_bottom = apply_filters(
				'learn-press/collection/learning/course-item/info',
				[
					'wrapper'     => '<div class="course-content">',
					'title'       => sprintf(
						'<h3 class="wap-course-title"><a class="course-permalink" href="%s">%s</a></h3>',
						$course->get_permalink(),
						$singleCourseTemplate->html_title( $course )
					),
					'description' => $singleCourseTemplate->html_short_description( $course, 50 ),
					'button'      => $singleCourseModernLayout->html_buttons( $course, $userModel ),
					'wrapper_end' => '</div>',
					'progress'    => $html_percentage,
				],
				$course,
				$settings
			);

			$section = apply_filters(
				'learn-press/collection/learning/course-item',
				[
					'wrapper_li'      => '<li class="course">',
					'wrapper_div'     => sprintf( '<div class="course-item" data-id="%s">', esc_attr( $course->get_id() ) ),
					'top'             => Template::combine_components( $section_top ),
					'bottom'          => Template::combine_components( $section_bottom ),
					'wrapper_div_end' => '</div>',
					'wrapper_li_end'  => '</li>',
				],
				$course,
				$settings
			);

			// For old themes use old hook.
			$section = ListCoursesTemplate::fix_theme_course_old( $section, $course, $settings );
			// End.

			$html_item = Template::combine_components( $section );
			// End new layout course item.
		} catch ( Throwable $e ) {
			$html_item = $e->getMessage();
		}

		return $html_item;
	}

	public function html_collection_progress( CollectionPostModel $collectionPostModel ) {
		$html = '';
		try {
			$section = apply_filters(
				'learn-press/collection/html-collection-progress',
				[
					'wrapper'             => '<div class="collection-progress">',
					'wrapper_content'     => '<div class="collection-progress__content">',
					'title'               => sprintf(
						'<span class="collection-progress__title">%s</span>',
						__( 'Your Progress', 'learnpress-collections' )
					),
					'content'             => sprintf(
						'<div class="collection-progress__progress">%s/%s %s</div>',
						$collectionPostModel->get_total_course_finish(),
						$collectionPostModel->get_total_course(),
						__( 'Course Completed', 'learnpress-collections' )
					),
					'wrapper_content_end' => '</div>',
					'line'                => sprintf(
						'<div class="collection-progress__line"><span class="collection-progress__line-inner" style="width: %s%%"></span></div>',
						$collectionPostModel->get_total_course_finish() / ( $collectionPostModel->get_total_course() ? $collectionPostModel->get_total_course() : 1 ) * 100
					),
					'wrapper_end'         => '</div>',
				],
				$collectionPostModel
			);
			$html    = Template::combine_components( $section );
		} catch ( Throwable $e ) {
			error_log( $e->getMessage() );
			$html = Template::print_message( __( 'An error occurred while generating the collection learning.', 'learnpress-collections' ), 'error', false );
		}

		return $html;
	}

	public function add_breadcrumb_learning( $crumbs ) {
		if ( is_singular( LP_COLLECTION_CPT ) ) {
			$tab = get_query_var( 'lp_collection_tab' );
			if ( $tab === 'learning' ) {
				$collection_id       = $data['collection_id'] ?? get_the_ID();
				$collectionPostModel = CollectionPostModel::find( $collection_id, true );
				array_pop( $crumbs );
				$crumbs[] = [
					$collectionPostModel->get_the_title(),
					$collectionPostModel->get_permalink(),
				];
				$crumbs[] = [
					__( 'Learning', 'learnpress-collections' ),
				];
			}
		}

		return $crumbs;
	}
}
