<?php

use LearnPressCollection\Models\CollectionPostModel;

/**
 * LearnPress Collections Metabox
 * Use in LP4.
 */
class LP_Collections_Meta_Box_Settings {

	public static function output( $post ) {
		wp_enqueue_script( 'lp-admin-learnpress' );
		$post_id             = $post->ID;
		$collectionPostModel = CollectionPostModel::find( $post_id, true );
		if ( ! $collectionPostModel ) {
			return;
		}

		$data_struct_course = [
			'urlApi'      => get_rest_url( null, 'lp/v1/admin/tools/search-course' ),
			'dataType'    => 'courses',
			'keyGetValue' => [
				'value'      => 'ID',
				'text'       => '{{post_title}} (#{{ID}})',
				'key_render' => [
					'post_title' => 'post_title',
					'ID'         => 'ID',
				],
			],
			'setting'     => [
				'placeholder' => esc_html__( 'Choose Course', 'learnpress-collections' ),
			],
		];

		$course_collection = new LP_Meta_Box_Select_Field(
			esc_html__( 'Courses', 'learnpress-collections' ),
			esc_html__( 'Collecting related courses into one collection.', 'learnpress-collections' ),
			'',
			[
				'options'           => '',
				'tom_select'        => true,
				'multiple'          => true,
				'multil_meta'       => true,
				'custom_attributes' => [ 'data-struct' => htmlentities2( json_encode( $data_struct_course ) ) ],
				'data-saved'        => $collectionPostModel->get_course_ids(),
			]
		);
		$faqs              = new LP_Meta_Box_WP_Editor_Field( esc_html__( 'FAQs', 'learnpress-collections' ) );
		$level             = new LP_Meta_Box_Select_Field(
			esc_html__( 'Level', 'learnpress' ),
			esc_html__( 'Choose a difficulty level.', 'learnpress' ),
			'all',
			array(
				'options' => array(
					'all'          => esc_html__( 'All levels', 'learnpress' ),
					'beginner'     => esc_html__( 'Beginner', 'learnpress' ),
					'intermediate' => esc_html__( 'Intermediate', 'learnpress' ),
					'expert'       => esc_html__( 'Expert', 'learnpress' ),
				),
			)
		);
		$duration          = new LP_Meta_Box_Duration_Field(
			esc_html__( 'Duration', 'learnpress' ),
			esc_html__( 'Set to 0 for the lifetime access.', 'learnpress' ),
			'10 week',
			array(
				'default_time'      => 'week',
				'custom_attributes' => array(
					'min'  => '0',
					'step' => '1',
				),
			)
		);
		$ppp               = new LP_Meta_Box_Text_Field(
			esc_html__( 'Courses per page', 'learnpress' ),
			esc_html__( 'Number of courses per each page. Default is 10.', 'learnpress-collections' ),
			10,
			array(
				'type_input'        => 'number',
				'custom_attributes' => array(
					'min'  => '0',
					'step' => '1',
				),
				'style'             => 'width: 70px;',
			)
		);

		$ppp->id               = '_lp_collection_courses_per_page';
		$duration->id          = '_lp_collection_duration';
		$faqs->id              = '_lp_collection_faqs';
		$level->id             = '_lp_collection_level';
		$course_collection->id = '_lp_collection_courses';

		?>

		<div class="lp-meta-box lp-meta-box--collectionss">
			<div class="lp-meta-box__inner">
				<?php
				do_action( 'learnpress/collections-settings/before' );
				$duration->output( $post_id );
				$level->output( $post_id );
				$course_collection->output( $post_id );
				$ppp->output( $post_id );
				$faqs->output( $post_id );
				do_action( 'learnpress/collections-settings/after' );
				wp_nonce_field( 'learnpress_save_meta_box', 'learnpress_meta_box_nonce' );
				?>
			</div>
		</div>

		<?php
	}

	public static function save( $post_id ) {
		$new_courses = LP_Request::get_param( '_lp_collection_courses', [], 'int', 'post' );
		$old_courses = get_post_meta( $post_id, '_lp_collection_courses' );
		if ( ! is_array( $old_courses ) ) {
			$old_courses = [];
		}

			$added   = array_diff( $new_courses, $old_courses );
			$removed = array_diff( $old_courses, $new_courses );

		if ( $added ) {
			foreach ( $added as $course ) {
				add_post_meta( $post_id, '_lp_collection_courses', $course, false );

				$collections = get_post_meta( $course, '_lp_course_collections', false );
				if ( ! in_array( $post_id, $collections ) ) {
					add_post_meta( $course, '_lp_course_collections', $post_id );
				}
			}
		}

		if ( $removed ) {
			foreach ( $removed as $course ) {
				delete_post_meta( $post_id, '_lp_collection_courses', $course );

				$collections = get_post_meta( $course, '_lp_course_collections', false );
				if ( in_array( $post_id, $collections ) ) {
					delete_post_meta( $course, '_lp_course_collections', $post_id );
				}
			}
		}

		$ppp      = new LP_Meta_Box_Text_Field();
		$duration = new LP_Meta_Box_Duration_Field();
		$level    = new LP_Meta_Box_Select_Field();
		$faqs     = new LP_Meta_Box_WP_Editor_Field();

		$duration->id = '_lp_collection_duration';
		$level->id    = '_lp_collection_level';
		$faqs->id     = '_lp_collection_faqs';
		$ppp->id      = '_lp_collection_courses_per_page';

		$ppp->save( $post_id );
		$duration->save( $post_id );
		$level->save( $post_id );
		$faqs->save( $post_id );
	}
}

add_action( 'learnpress_save_lp_collection_metabox', 'LP_Collections_Meta_Box_Settings::save' );
