<?php

/**
 * Class Collection Post Model
 *
 * @package LearnPressCollection/Models
 * @version 1.0.1
 * @since 4.0.2
 */

namespace LearnPressCollection\Models;

use Exception;
use LearnPress\Models\CourseModel;
use LearnPress\Models\PostModel;
use LearnPress\Models\UserItems\UserCourseModel;
use LearnPressCollection\Filters\CollectionFilter;
use LP_Cache;
use LP_Helper;
use LP_Post_DB;

class CollectionPostModel extends PostModel {
	/**
	 * @var string Post Type
	 */
	public $post_type = LP_COLLECTION_CPT;

	/**
	 * Const meta key
	 */
	const META_KEY_COURSES         = '_lp_collection_courses';
	const META_KEY_COURSE_PER_PAGE = '_lp_collection_courses_per_page';
	const META_KEY_DURATION        = '_lp_collection_duration';
	const META_KEY_LEVEL           = '_lp_collection_level';
	const META_KEY_FAQS            = '_lp_collection_faqs';
	const META_KEY_USERS           = '_lp_collection_users';

	/**
	 * Get post assignment by ID
	 *
	 * @param int $post_id
	 * @param bool $check_cache
	 *
	 * @return false|static
	 */
	public static function find( int $post_id, bool $check_cache = false ) {
		$filter_post     = new CollectionFilter();
		$filter_post->ID = $post_id;

		$key_cache         = "collectionPostModel/find/{$post_id}";
		$lpCollectionCache = new LP_Cache();

		if ( $check_cache ) {
			$collectionPostModel = $lpCollectionCache->get_cache( $key_cache );
			if ( $collectionPostModel instanceof CollectionPostModel ) {
				return $collectionPostModel;
			}
		}

		$collectionPostModel = self::get_item_model_from_db( $filter_post );

		if ( $collectionPostModel instanceof CollectionPostModel ) {
			$lpCollectionCache->set_cache( $key_cache, $collectionPostModel );
		}

		return $collectionPostModel;
	}

	/**
	 * Get all course's ids of the collection.
	 * @return int[]
	 * @version 1.0.1
	 * @since 4.0.2
	 */
	public function get_course_ids(): array {
		return $this->get_meta_value_by_key( self::META_KEY_COURSES, [], false );
	}

	/**
	 * Get course per page of the collection.
	 *
	 * @return int
	 */
	public function get_course_per_page(): int {
		return (int) $this->get_meta_value_by_key( self::META_KEY_COURSE_PER_PAGE, 10 );
	}

	public function get_duration(): string {
		return (string) $this->get_meta_value_by_key( self::META_KEY_DURATION, '' );
	}

	public function get_level(): string {
		return (string) $this->get_meta_value_by_key( self::META_KEY_LEVEL, '' );
	}

	public function get_faqs(): string {
		return (string) $this->get_meta_value_by_key( self::META_KEY_FAQS, '' );
	}

	/**
	 * Get users attend of the collection.
	 *
	 * @throws Exception
	 */
	public function get_users(): array {
		$user_attend_str = $this->get_meta_value_by_key( self::META_KEY_USERS, '' );
		if ( ! $user_attend_str ) {
			return [];
		}

		return LP_Helper::json_decode( $user_attend_str, true );
	}

	/**
	 * Get link learning of collection.
	 *
	 * @return string
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public function get_learning_link(): string {
		$collection_link = $this->get_permalink();
		if ( empty( $collection_link ) ) {
			return '';
		}
		$learning_link = rtrim( $collection_link, '/' ) . '/learning/';

		return apply_filters( 'learn-press/collection/learning-link', $learning_link, $collection_link );
	}

	/**
	 * Get ids instructor.
	 *
	 * @return array
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public function get_instructor_ids(): array {
		$course_ids = $this->get_course_ids();
		if ( empty( $course_ids ) ) {
			return [];
		}

		$instructors = [];
		foreach ( $course_ids as $course_id ) {
			$course = CourseModel::find( $course_id, true );
			if ( ! $course ) {
				continue;
			}

			$author = $course->get_author_model();
			if ( ! $author ) {
				continue;
			}

			$author_id = $author->get_id();
			if ( ! isset( $instructors[ $author_id ] ) ) {
				$instructors[ $author_id ] = $author;
			}
		}

		return $instructors;
	}

	/**
	 * Get related collections.
	 *
	 * @param int $limit
	 *
	 * @return array
	 * @throws Exception
	 * @version 1.0.0
	 * @since 4.0.3
	 */
	public function get_related_collections( int $limit = 4 ): array {
		$collection_id = $this->get_id();

		$db                      = LP_Post_DB::getInstance();
		$filter                  = new CollectionFilter();
		$filter->only_fields     = [ 'ID' ];
		$filter->post_status     = [ 'publish' ];
		$filter->limit           = $limit;
		$filter->order_by        = 'rand()';
		$filter->where[]         = $db->wpdb->prepare( 'AND ID != %d', $collection_id );
		$filter->run_query_count = false;
		$collections             = CollectionPostsModel::get_collections( $filter );

		if ( ! $collections ) {
			return [];
		}

		$related_collections = [];
		foreach ( $collections as $collectionObj ) {
			$collectionPostModel = self::find( $collectionObj->ID, true );
			if ( ! $collectionPostModel ) {
				continue;
			}

			$related_collections[] = $collectionPostModel;
		}

		return apply_filters(
			'learn-press/collection/related-collections',
			$related_collections,
			$this
		);
	}

	/**
	 * Get total course finished of current user in the collection.
	 *
	 * @return int
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public function get_total_course_finish(): int {
		$course_ids = $this->get_course_ids();

		if ( ! $course_ids ) {
			return 0;
		}

		$user = get_current_user_id();
		if ( ! $user ) {
			return 0;
		}

		$total = 0;

		foreach ( $course_ids as $course_id ) {
			$course = CourseModel::find( $course_id, true );
			if ( ! $course ) {
				continue;
			}

			$userCourseModel = UserCourseModel::find( $user, $course_id, true );
			if ( $userCourseModel && $userCourseModel->is_finished() ) {
				++$total;
			}
		}

		return apply_filters( 'learn-press/collection/total-course-finish', $total, $this->get_id() );
	}

	/**
	 * Get total course of the collection.
	 *
	 * @return int
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public function get_total_course(): int {
		$size       = 0;
		$course_ids = $this->get_course_ids();

		if ( $course_ids ) {
			$size = sizeof( $course_ids );
		}

		return (int) apply_filters( 'learn-press/collection/total-courses', $size, $this->get_id() );
	}
}
