<?php

namespace LearnPressCollection\Models;

use LearnPressCollection\Filters\CollectionFilter;
use LP_Debug;
use LP_Helper;
use LP_Post_DB;
use LP_Settings;
use Throwable;

/**
 * Class CollectionsModel
 *
 * Handle all method about list collections
 *
 * @version 1.0.0
 * @since 4.0.3
 */
class CollectionPostsModel {
	/**
	 * Handle params before query collections
	 *
	 * @param array $param
	 * @param CollectionFilter $filter
	 *
	 * @return void
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public static function handle_params_for_query_collections( CollectionFilter &$filter, array $param = [] ) {
		$filter->page  = (int) ( $param['paged'] ?? 1 );
		$filter->limit = (int) ( $param['limit'] ?? LP_Settings::instance()->get( 'collections.per_page', 10 ) );

		// Order
		if ( ! empty( $param['order'] ) ) {
			$filter->order = LP_Helper::sanitize_params_submitted( $param['order'] );
		}

		// Order by
		if ( ! empty( $param['order_by'] ) ) {
			switch ( $param['order_by'] ) {
				case 'post_title':
					$filter->order = 'ASC';
					break;
				case 'post_title_desc':
					$filter->order_by = 'post_title';
					$filter->order    = 'DESC';
					break;
				case 'menu_order':
					$filter->order_by = 'menu_order';
					$filter->order    = 'ASC';
					break;
				default:
					$filter = apply_filters( 'lp/collections/filter/order_by/' . $filter->order_by, $filter );
					break;
			}
		}

		do_action( 'learn-press/collections/handle_params_for_query_collections', $filter, $param );
	}

	/**
	 * Get list collections
	 *
	 * @param CollectionFilter $filter
	 * @param int $total_rows
	 *
	 * @return array|int|string|null
	 * @author tungnx
	 * @version 1.0.0
	 * @sicne 4.0.3
	 */
	public static function get_collections( CollectionFilter $filter, int &$total_rows = 0 ) {
		$db = LP_Post_DB::getInstance();

		try {
			// Query get results
			$filter      = apply_filters( 'lp/collections/filter', $filter );
			$collections = $db->get_posts( $filter, $total_rows );
		} catch ( Throwable $e ) {
			$collections = [];
			LP_Debug::error_log( $e );
		}

		return $collections;
	}
}
