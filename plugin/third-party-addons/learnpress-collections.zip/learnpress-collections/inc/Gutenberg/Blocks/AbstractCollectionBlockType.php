<?php
namespace LearnPressCollection\Gutenberg\Blocks;

use LearnPress\Gutenberg\Blocks\AbstractBlockType;
use LP_Settings;

/**
 * Class AbstractCollectionBlockType
 *
 * Handle register, render block template
 */
abstract class AbstractCollectionBlockType extends AbstractBlockType {

	public function get_source_js() {
		return LP_ADDON_COLLECTIONS_URL . 'assets/dist/js/blocks/' . $this->block_name . '.js';
	}
}
