<?php

namespace LearnPressCollection\Gutenberg\Blocks\Legacy;

use LearnPressCollection\Gutenberg\Blocks\AbstractCollectionBlockType;
use LearnPress\Helpers\Template;

/**
 * Class SingleCollectionLearningBlockLegacy
 *
 * Handle register, render block template
 */
class SingleCollectionLearningBlockLegacy extends AbstractCollectionBlockType {
	public $block_name = 'single-collection-learning-legacy';

	/**
	 * Render content of block tag
	 *
	 * @param array $attributes | Attributes of block tag.
	 *
	 * @return false|string
	 */
	public function render_content_block_template( array $attributes, $content, $block ): string {
		ob_start();
		do_action( 'learn-press/single-collection-learning/layout', $attributes );
		return ob_get_clean();
	}
}
