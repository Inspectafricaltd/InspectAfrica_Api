<?php

namespace LearnPressCollection\Gutenberg\Blocks\Legacy;

use Exception;
use LearnPress\Helpers\Template;
use LearnPress\TemplateHooks\TemplateAJAX;
use LearnPressCollection\Filters\CollectionFilter;
use LearnPressCollection\Gutenberg\Blocks\AbstractCollectionBlockType;
use LearnPressCollection\Models\CollectionPostModel;
use LearnPressCollection\Models\CollectionPostsModel;
use LearnPressCollection\TemplateHooks\ListCollectionsTemplate;
use LP_Database;
use LP_Post_DB;
use LP_Settings;
use stdClass;

/**
 * Class ListCollectionBlockLegacy
 *
 * Handle register, render block template
 */
class ListCollectionBlockLegacy extends AbstractCollectionBlockType {
	public $block_name = 'list-collection-legacy';

	public function __construct() {
		add_filter( 'lp/rest/ajax/allow_callback', [ $this, 'allow_callback' ] );
		parent::__construct();
	}

	/**
	 * Allow callback for block
	 *
	 * @param array $callbacks.
	 *
	 * @return array
	 */
	public function allow_callback( array $callbacks ): array {
		/**
		 * @uses render_collections
		 */
		$callbacks[] = get_class( $this ) . ':render_collections';

		return $callbacks;
	}

	/**
	 * Render content of block tag
	 *
	 * @param array $attributes | Attributes of block tag.
	 *
	 * @return false|string
	 * @throws Exception
	 */
	public function render_content_block_template( array $attributes, $content, $block ): string {
		wp_enqueue_style( 'learnpress-collection' );

		$callback = [
			'class'  => get_class( $this ),
			'method' => 'render_collections',
		];

		$args           = lp_archive_skeleton_get_args();
		$args['id_url'] = 'list-collections';
		$args['limit']  = $attributes['limit'] ?? 10;
		$id             = 0;
		if ( ! is_archive() && ! is_home() && ! is_search() ) {
			$id = get_the_ID();
		}
		$args['post_id']                 = $id;
		$args['pagination']              = $attributes['pagination'] ?? false;
		$args['order_by']                = $attributes['order_by'] ?? 'post_date';
		$args['layout']                  = $attributes['layout'] ?? 'grid';
		$content_obj                     = self::render_collections( $args );
		$args['html_no_load_ajax_first'] = $content_obj->content;
		$content                         = TemplateAJAX::load_content_via_ajax( $args, $callback );
		$html                            = $this->get_output( $content );
		return $html;
	}

		/**
	 * Render html list collections.
	 *
	 * @throws Exception
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public static function render_collections( array $data = [] ): stdClass {
		$content = new stdClass();
		$filter  = new CollectionFilter();
		CollectionPostsModel::handle_params_for_query_collections( $filter, $data );
		$filter->only_fields = [ 'ID' ];
		$filter->post_status = [ 'publish' ];
		$total_rows          = 0;

		$collectionModelCurrent = CollectionPostModel::find( $data['post_id'] ?? 0, true );
		if ( $collectionModelCurrent ) {
			$filter->where[] = LP_Database::getInstance()->wpdb->prepare( 'AND p.ID != %d', $data['post_id'] );
		}

		$collections = CollectionPostsModel::get_collections( $filter, $total_rows );
		$total_pages = LP_Database::get_total_pages( $filter->limit, $total_rows );

		$html_list = '';
		if ( ! $collections ) {
			$html_list = Template::print_message( __( 'No collections found', 'learnpress-collections' ), 'info', false );
		} else {
			foreach ( $collections as $collection ) {
				$collectionPostModel = CollectionPostModel::find( $collection->ID, true );
				if ( ! $collectionPostModel ) {
					continue;
				}

				$html_list .= ListCollectionsTemplate::render_collection( $collectionPostModel, $data );
			}
		}

		$section_collections = apply_filters(
			'learn-press/layout/list-collections/collections/section',
			[
				'wrap'        => sprintf( '<ul class="learn-press-collections" data-layout="%s">', $data['layout'] ?? 'grid' ),
				'collections' => $html_list,
				'wrap_end'    => '</ul>',
			],
			$collections,
			$data
		);

		$html_pagination = '';

		if ( $data['pagination'] ) {
			$html_pagination = ListCollectionsTemplate::instance()->html_collection_pagination(
				[
					'total_pages' => $total_pages,
					'base'        => add_query_arg( 'paged', '%#%', '' ),
					'paged'       => $data['paged'] ?? 1,
				]
			);
		}

		$section = [
			'list_collections' => Template::combine_components( $section_collections ),
			'pagination'       => $html_pagination,
		];

		$content->content     = Template::combine_components( $section );
		$content->total_pages = $total_pages;
		$content->paged       = $filter->page;

		return $content;
	}
}
