<?php

namespace LearnPressCollection\Gutenberg\Blocks\Legacy;

use LearnPress\Helpers\Template;
use LearnPressCollection\Gutenberg\Blocks\AbstractCollectionBlockType;

/**
 * Class ArchiveCollectionBlockLegacy
 *
 * Handle register, render block template
 */
class ArchiveCollectionBlockLegacy extends AbstractCollectionBlockType {
	public $block_name = 'archive-collection-legacy';

	/**
	 * Render content of block tag
	 *
	 * @param array $attributes | Attributes of block tag.
	 *
	 * @return false|string
	 */
	public function render_content_block_template( array $attributes, $content, $block ): string {
		ob_start();
		do_action( 'learn-press/list-collections/layout', $attributes );
		return ob_get_clean();
	}
}
