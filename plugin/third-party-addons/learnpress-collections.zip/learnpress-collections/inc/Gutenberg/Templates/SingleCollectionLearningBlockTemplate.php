<?php
namespace LearnPressCollection\Gutenberg\Templates;

/**
 * Class SingleCollectionLearningBlockTemplate
 *
 * @since 4.0.2
 * @version 1.0.0
 */
class SingleCollectionLearningBlockTemplate extends AbstractCollectionBlockTemplate {
	public $slug                          = 'single-lp_collection_learning';
	public $title                         = 'Sinlge Collection Learning Template';
	public $description                   = 'Sinlge Collection Learning Block Template';
	public $path_html_block_template_file = 'html/single-collection-learning-template-default.html';
}
