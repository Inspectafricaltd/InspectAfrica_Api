<?php
namespace LearnPressCollection\Gutenberg\Templates;

/**
 * Class SingleCollectionBlockTemplate
 *
 * @since 4.0.2
 * @version 1.0.0
 */
class SingleCollectionBlockTemplate extends AbstractCollectionBlockTemplate {
	public $slug                          = 'single-lp_collection';
	public $title                         = 'Sinlge Collection Template';
	public $description                   = 'Sinlge Collection Block Template';
	public $path_html_block_template_file = 'html/single-collection-template-default.html';
}
