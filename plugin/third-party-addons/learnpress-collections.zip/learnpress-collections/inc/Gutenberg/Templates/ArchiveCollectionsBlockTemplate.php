<?php
namespace LearnPressCollection\Gutenberg\Templates;

use LearnPressCollection\Gutenberg\Templates\AbstractCollectionBlockTemplate;

/**
 * Class ArchiveCollectionsBlockTemplate
 *
 * @since 4.0.2
 * @version 1.0.0
 */
class ArchiveCollectionsBlockTemplate extends AbstractCollectionBlockTemplate {
	public $slug                          = 'archive-lp_collection';
	public $title                         = 'Archive Collections Template';
	public $description                   = 'Archive Collections Block Template';
	public $path_html_block_template_file = 'html/archive-collection-template-default.html';
}
