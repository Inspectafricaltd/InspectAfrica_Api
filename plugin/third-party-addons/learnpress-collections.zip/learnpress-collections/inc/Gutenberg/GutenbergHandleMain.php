<?php

namespace LearnPressCollection\Gutenberg;

use LearnPress\Helpers\Singleton;
use LearnPressCollection\Gutenberg\Templates\SingleCollectionLearningBlockTemplate;
use WP_Post;

/**
 * Class GutenbergHandleMain
 *
 * Handle register, render block template
 * @since 4.2.8.3 Convert from old class Block_Template_Handle
 * @version 1.0.0
 */
class GutenbergHandleMain {
	use Singleton;

	/**
	 * Hooks handle block template
	 */
	public function init() {
		if ( ! wp_is_block_theme() ) {
			return;
		}
		add_filter( 'get_block_templates', array( $this, 'set_blocks_template' ), 10, 3 );
	}

	/**
	 * Set block template need to show on frontend/backend
	 * 1. Get all templates of LP declare.
	 * 2. Frontend: check blocks match with type page. Ex: single course, archive course....
	 * 3. If correct, set Block to $query_result.
	 *
	 * @param array $query_result Array of template objects.
	 * @param array $query Optional. Arguments to retrieve templates.
	 * @param mixed $template_type wp_template or wp_template_part.
	 *
	 * @return array
	 */
	public function set_blocks_template( array $query_result, array $query, $template_type ): array {
		if ( $template_type === 'wp_template_part' || is_admin() ) { // Template not Template part
			return $query_result;
		}

		// Check is collection learning.
		global $wp;
		$vars = $wp->query_vars;
		$tab  = $vars['lp_collection_tab'] ?? '';
		if ( $tab !== 'learning' ) {
			return $query_result;
		}

		$singleCollectionLearningBlockTemplate = new SingleCollectionLearningBlockTemplate();
		$block_custom                          = $this->is_custom_block_template( $template_type, $singleCollectionLearningBlockTemplate->slug );
		if ( $block_custom ) {
			$singleCollectionLearningBlockTemplate->is_custom = true;
			$singleCollectionLearningBlockTemplate->source    = 'custom';
			$singleCollectionLearningBlockTemplate->content   = traverse_and_serialize_blocks( parse_blocks( $block_custom->post_content ) );
		}

		/**
		 * Set slug to single course, to compare with slug in query.
		 * Because don't have slug 'single-lp_collection_learning'.
		 * Slug 'single-lp_collection_learning' is for save content of block template.
		 */
		$singleCollectionLearningBlockTemplate->slug = 'single-lp_collection';
		$query_result                                = [ $singleCollectionLearningBlockTemplate ];
		return $query_result;
	}

		/**
	 * Check is custom block template
	 *
	 * @param $template_type
	 * @param $post_name
	 *
	 * @return WP_Post|null
	 */
	public function is_custom_block_template( $template_type, $post_name ) {
		$post_block_theme = null;

		$check_query_args = array(
			'post_type'      => $template_type,
			'posts_per_page' => 1,
			'no_found_rows'  => true,
			'post_status'    => 'publish',
			'post_name__in'  => array( $post_name ),
		);

		$check = new \WP_Query( $check_query_args );

		if ( count( $check->get_posts() ) > 0 ) {
			$post_block_theme = $check->get_posts()[0];
		}

		return $post_block_theme;
	}
}
