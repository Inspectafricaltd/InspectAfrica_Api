<?php
/**
 * Class CollectionFilter
 *
 * @package LearnPressCollection/Filters
 * @since 4.0.2
 * @version 1.0.0
 */

namespace LearnPressCollection\Filters;

use LP_Post_Type_Filter;

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();

if ( class_exists( 'CollectionFilter' ) ) {
	return;
}

class CollectionFilter extends LP_Post_Type_Filter {
	/**
	 * @var string
	 */
	public $post_type = LP_COLLECTION_CPT;

	/**
	 * @var string Level of Course
	 */
	public $levels = [];
}
