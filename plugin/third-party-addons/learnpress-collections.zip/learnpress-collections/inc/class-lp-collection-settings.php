<?php
/**
 * Class LP_Collections_Admin_Settings
 *
 * @since 3.0.0
 * @version 1.0.1
 */
class LP_Collections_Admin_Settings extends LP_Abstract_Settings_Page {
	/**
	 * Constructor
	 */
	public function __construct() {
		$this->id   = 'collections';
		$this->text = __( 'Collections', 'learnpress-collections' );
		parent::__construct();
	}

	public function get_settings( $section = '', $tab = '' ) {
		return apply_filters(
			'learn-press/admin/collections-settings/general',
			array(
				array(
					'type' => 'title',
				),
				array(
					'title'   => esc_html__( 'Collections per page', 'learnpress-collections' ),
					'id'      => 'collections[per_page]',
					'default' => 10,
					'type'    => 'number',
					'min'     => 1,
				),
				array(
					'type' => 'sectionend',
				),
			)
		);
	}
}

return new LP_Collections_Admin_Settings();
