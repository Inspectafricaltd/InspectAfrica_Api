<?php
/**
 * Collections widget class.
 *
 * @author   ThimPress
 * @package  LearnPress/Collections/Classes
 * @version  3.0.1
 */

// Prevent loading this file directly
use LearnPressCollection\Filters\CollectionFilter;
use LearnPressCollection\Models\CollectionPostModel;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Collections_Widget' ) ) {
	/**
	 * Adds LP_Collections_Widget widget.
	 */
	class LP_Collections_Widget extends WP_Widget {

		/**
		 * Register widget with WordPress.
		 */
		public function __construct() {
			parent::__construct(
				'collection_widget',
				__( 'Courses Collections', 'learnpress-collections' ),
				array( 'description' => __( 'Display course collections', 'learnpress-collections' ) )
			);
		}

		/**
		 * Front-end display
		 *
		 * @param array $args
		 * @param array $instance
		 *
		 * @throws Exception
		 */
		public function widget( $args, $instance ) {
			try {
				echo $args['before_widget'];
				if ( ! empty( $instance['title'] ) ) {
					echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
				}

				// Query collections
				$lp_post_db          = LP_Post_DB::getInstance();
				$filter              = new CollectionFilter();
				$filter->only_fields = [ 'ID' ];
				$filter->post_status = [ 'publish' ];
				$filter->query_count = false;
				$filter->limit       = $instance['number'] ?? LP_Settings::instance()->get( 'collections.per_page', 10 );

				$total_rows  = 0;
				$collections = $lp_post_db->get_posts( $filter, $total_rows );

				// The Loop
				if ( $collections ) {
					echo '<ul class="learn-press-collection-widget">';
					foreach ( $collections as $collection ) {
						$collectionPostModel = CollectionPostModel::find( $collection->ID, true );
						if ( ! $collectionPostModel ) {
							continue;
						}

						echo '<li>';
						echo sprintf(
							'<a href="%s">%s</a>',
							esc_url( $collectionPostModel->get_permalink() ),
							$collectionPostModel->get_the_title()
						);
						echo '</li>';
					}
					echo '</ul>';
				}

				echo $args['after_widget'];
			} catch ( Throwable $e ) {
				LP_Debug::error_log( $e );
			}
		}

		/**
		 * Form.
		 *
		 * @param array $instance
		 *
		 * @return string|void
		 */
		public function form( $instance ) {
			$title  = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Collections', 'learnpress-collections' );
			$number = ! empty( $instance['number'] ) ? $instance['number'] : '5';
			?>
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'learnpress-collections' ); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
						name="<?php echo $this->get_field_name( 'title' ); ?>" type="text"
						value="<?php echo esc_attr( $title ); ?>">
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of collections to show:', 'learnpress-collections' ); ?></label>
				<input type="text" size="3" value="<?php echo esc_attr( $number ); ?>"
						id="<?php echo $this->get_field_id( 'number' ); ?>"
						name="<?php echo $this->get_field_name( 'number' ); ?>">
			</p>
			<?php
		}

		/**
		 * Sanitize widget form values as they are saved.
		 *
		 * @param array $new_instance
		 * @param array $old_instance
		 *
		 * @return array
		 */
		public function update( $new_instance, $old_instance ) {
			$instance           = array();
			$instance['title']  = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['number'] = ( ! empty( $new_instance['number'] ) ) ? strip_tags( $new_instance['number'] ) : '';

			return $instance;
		}
	}
}
