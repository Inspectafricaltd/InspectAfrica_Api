<?php
/**
 * class CollectionAjax
 *
 * @since 4.0.2
 * @version 1.0.0
 */

namespace LearnPressCollection\Ajax;

use Exception;
use LearnPress\Ajax\AbstractAjax;
use LearnPress\Models\UserModel;
use LearnPressCollection\Models\CollectionPostModel;
use LP_Helper;
use LP_REST_Response;
use stdClass;

class CollectionAjax extends AbstractAjax {
		/**
	 * Check permissions and validate parameters.
	 *
	 * @throws Exception
	 *
	 * @since 4.0.2
	 * @version 1.0.0
	 */
	public static function check_valid() {
		$params = wp_unslash( $_REQUEST['data'] ?? '' );
		if ( empty( $params ) ) {
			throw new Exception( 'Error: params invalid!' );
		}

		$params              = LP_Helper::json_decode( $params, true );
		$collection_id       = $params['collection-id'] ?? 0;
		$collectionPostModel = CollectionPostModel::find( $collection_id, true );
		if ( ! $collectionPostModel ) {
			throw new Exception( __( 'Collection not found', 'learnpress-collections' ) );
		}
		$params['collectionPostModel'] = $collectionPostModel;
		return $params;
	}

	/**
	 * Enroll collection.
	 *
	 * @since 4.0.3
	 * @version 1.0.0
	 */
	public function enroll_collection() {
		$response       = new LP_REST_Response();
		$response->data = new stdClass();

		try {
			$data = self::check_valid();
			/**
			 * @var CollectionPostModel $collectionPostModel
			 */
			$collectionPostModel = $data['collectionPostModel'];
			if ( ! $collectionPostModel ) {
				throw new Exception( esc_html__( 'Invalid collection!', 'learnpress-collections' ) );
			}

			$user_id   = get_current_user_id();
			$userModel = UserModel::find( $user_id, true );

			if ( $userModel ) {
				$users = $collectionPostModel->get_users();
				if ( ! in_array( $user_id, $users ) ) {
					$users[] = $user_id;
				}

				$users_json = json_encode( $users, JSON_NUMERIC_CHECK );
				$collectionPostModel->save_meta_value_by_key( $collectionPostModel::META_KEY_USERS, $users_json );
				$response->status         = 'success';
				$redirect_url             = LP_Helper::get_link_no_cache( $collectionPostModel->get_learning_link() );
				$response->message        = esc_html__( 'Redirecting...', 'learnpress-collections' );
				$response->data->redirect = esc_url_raw( $redirect_url );
			} else {
				$response->status  = 'error';
				$response->message = sprintf(
					__( 'Please %s in to enroll in the collection!', 'learnpress-collections' ),
					sprintf(
						'<a class="lp-link-login" href="%s">%s</a>',
						learn_press_get_login_url( LP_Helper::getUrlCurrent() ),
						__( 'login', 'learnpress-collections' )
					)
				);
			}
		} catch ( Exception $e ) {
			$response->message = $e->getMessage();
		}

		wp_send_json( $response );
	}
}
