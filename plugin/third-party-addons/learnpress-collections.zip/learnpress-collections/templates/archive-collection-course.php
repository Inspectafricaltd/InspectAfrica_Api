<?php
/**
 * Template for displaying archive collection course content.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/addons/collection/archive-collection-course.php.
 *
 * @author  ThimPress
 * @package LearnPress/Collections/Templates
 * @version 3.0.1
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();

if ( ! isset( $query ) || ! $query instanceof WP_Query ) {
	return;
}
?>

<div class="learn-press-collections lp-archive-courses" id="learn-press-collection-<?php echo $id; ?>">
	<?php
	if ( $query->have_posts() ) {
		learn_press_begin_courses_loop();
		while ( $query->have_posts() ) :
			$query->the_post();

			LP_Addon_Collections::$in_loop = true;
			learn_press_collections_get_template( 'content-collection-course.php' );

		endwhile;

		learn_press_end_courses_loop();
		LP_Addon_Collections::$in_loop = false;

		learn_press_paging_nav(
			array(
				'num_pages'     => $query->max_num_pages,
				'wrapper_class' => 'learn-press-pagination',
				'paged'         => get_query_var( 'collection_page', 1 ),
			)
		);
	} else {
		learn_press_display_message( __( 'No course found!', 'learnpress-collections' ) );
	}
	?>

</div>
