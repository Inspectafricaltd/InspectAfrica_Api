<?php
/**
 * The template for displaying single collection.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/addons/collection/single-collection.php.
 *
 * @author  ThimPress
 * @package LearnPress/Collections/Templates
 * @version 3.0.1
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();

if ( ! wp_is_block_theme() ) {
	do_action( 'learn-press/template-header' );
}

do_action( 'learn-press/single-collection-learning/layout', [] );

if ( ! wp_is_block_theme() ) {
	do_action( 'learn-press/template-footer' );
}
