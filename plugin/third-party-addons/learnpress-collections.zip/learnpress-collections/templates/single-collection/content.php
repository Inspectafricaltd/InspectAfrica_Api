<?php
/**
 * Template for displaying content of single course.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/single-course/content.php.
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  3.0.0
 */

defined( 'ABSPATH' ) || exit();
?>

<div class="collection-content collection-summary-content">
	<?php do_action( 'learn_press_single_collection_summary_content' ); ?>
</div>
