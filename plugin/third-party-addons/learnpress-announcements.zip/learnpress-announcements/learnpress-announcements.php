<?php
/**
 * Plugin Name: LearnPress - Announcements
 * Plugin URI: https://thimpress.com/product/announcement-add-on-for-learnpress/
 * Description: Announcements add-on for LearnPress.
 * Author: ThimPress
 * Version: 4.1.2
 * Author URI: http://thimpress.com
 * Tags: learnpress, lms, announcements
 * Text Domain: learnpress-announcements
 * Domain Path: /languages/
 * Require_LP_Version: 4.2.9.4
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package learnpress-announcements
 */

use LearnPressAnnouncement\Ajax\SendEmailAjax;

defined( 'ABSPATH' ) || exit;

const LP_ADDON_ANNOUNCEMENTS_FILE = __FILE__;
define( 'LP_ANNOUNCEMENTS_PATH', dirname( LP_ADDON_ANNOUNCEMENTS_FILE ) );

/**
 * Class LP_Addon_Announcements_Preload
 */
class LP_Addon_Announcements_Preload {
	/**
	 * @var LP_Addon_Announcements
	 */
	public static $addon;
	/**
	 * @var string[] info addon
	 */
	public static $addon_info = array();

	/**
	 * @return LP_Addon_Announcements_Preload
	 */
	public static function instance(): LP_Addon_Announcements_Preload {
		static $instance;
		if ( is_null( $instance ) ) {
			$instance = new self();
		}

		return $instance;
	}

	/**
	 * LP_Addon_Announcements_Preload constructor.
	 */
	protected function __construct() {
		$can_load = true;
		// Set Base name plugin.
		define( 'LP_ADDON_ANNOUNCEMENTS_BASENAME', plugin_basename( LP_ADDON_ANNOUNCEMENTS_FILE ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_ANNOUNCEMENTS_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_ANNOUNCEMENTS_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_ANNOUNCEMENTS_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			$can_load = false;
		} elseif ( version_compare( LP_ADDON_ANNOUNCEMENTS_REQUIRE_VER, get_option( 'learnpress_version', '3.0.0' ), '>' ) ) {
			$can_load = false;
		}

		if ( ! $can_load ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );
			deactivate_plugins( LP_ADDON_ANNOUNCEMENTS_BASENAME );

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			return;
		}

		add_action( 'learn-press/ready', array( $this, 'load' ) );

		require_once LP_ANNOUNCEMENTS_PATH . '/inc/push-notifications/class-install.php';
	}

	/**
	 * Load addon
	 */
	public function load() {
		include_once 'vendor/autoload.php';
		include_once 'inc/load.php';
		self::$addon = LP_Addon_Announcements::instance();
		SendEmailAjax::catch_lp_ajax();
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p><?php echo( 'Please active <strong>LearnPress version ' . LP_ADDON_ANNOUNCEMENTS_REQUIRE_VER . ' or later</strong> before active <strong>' . self::$addon_info['Name'] . '</strong>' ); ?></p>
		</div>
		<?php
	}
}

LP_Addon_Announcements_Preload::instance();
