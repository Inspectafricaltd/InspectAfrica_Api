<?php
/**
 * AnnouncementTemplate
 *
 * @since 4.0.9
 * @version 1.0.0
 */

namespace LearnPressAnnouncement\TemplateHooks;

use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LearnPress\Models\UserModel;
use LearnPressAnnouncement\Models\AnnouncementPostModel;
use Throwable;

class SingleAnnouncementTemplate {
	use Singleton;

	public function init() {
		// TODO: Implement init() method.
	}

	/**
	 * Generate HTML for the title of an announcement.
	 *
	 * @param AnnouncementPostModel $announcementPostModel
	 * @param array $data
	 *
	 * @return string
	 * @since 4.0.9
	 * @version 1.0.0
	 */
	public function html_title( AnnouncementPostModel $announcementPostModel, array $data = [] ): string {
		$tag     = esc_html( $data['tag'] ?? 'h1' );
		$is_link = $data['is_link'] ?? false;
		$title   = $announcementPostModel->get_the_title();

		$html = sprintf(
			'<%1$s class="announcement-title">%2$s</%1$s>',
			$tag,
			$is_link ? sprintf(
				'<a href="%s">%s</a>',
				esc_url_raw( $announcementPostModel->get_permalink() ),
				$title
			) : $title
		);

		return apply_filters(
			'learn-press/announcement/html-title',
			$html,
			$announcementPostModel,
			$data
		);
	}

	/**
	 * Generate HTML for the description of an announcement.
	 *
	 * @param AnnouncementPostModel $announcementPostModel
	 *
	 * @return string
	 * @since 4.0.9
	 * @version 1.0.0
	 */
	public function html_description( AnnouncementPostModel $announcementPostModel ): string {
		$description = $announcementPostModel->get_the_content();
		if ( empty( $description ) ) {
			return '';
		}

		return apply_filters(
			'learn-press/announcement/html-description',
			sprintf(
				'<div class="announcement-description">%s</div>',
				wp_kses_post( $description )
			),
			$announcementPostModel
		);
	}

	/**
	 * Generate HTML for the excerpt of a collection.
	 *
	 * @param AnnouncementPostModel $announcementPostModel
	 *
	 * @return string
	 * @since 4.0.9
	 * @version 1.0.0
	 */
	public function html_excerpt( AnnouncementPostModel $announcementPostModel ): string {
		$excerpt = $announcementPostModel->get_the_excerpt();
		if ( empty( $excerpt ) ) {
			return '';
		}

		return apply_filters(
			'learn-press/announcement/html-excerpt',
			sprintf(
				'<div class="announcement-excerpt">%s</div>',
				wp_kses_post( $excerpt )
			),
			$announcementPostModel
		);
	}

	/**
	 * Render HTML comments of course.
	 *
	 * @param AnnouncementPostModel $announcementPostModel
	 * @param array $data ['course_id']
	 *
	 * @return string
	 * @since 4.0.9
	 * @version 1.0.0
	 */
	public function html_comments( AnnouncementPostModel $announcementPostModel, array $data = [] ): string {
		$html = '';

		try {
			$announcement_id = $announcementPostModel->ID;
			$userModel       = UserModel::find( get_current_user_id(), true );
			if ( empty( $announcement_id ) ) {
				return '';
			}

			global $withcomments, $post;

			$post = get_post( $announcement_id );
			if ( $post->comment_status !== 'open' ) {
				return '';
			} else {
				$withcomments = true;
			}

			$withcomments = apply_filters(
				'learn-press/course-announcement/render-html-comment/is-show',
				$withcomments,
				$post,
				$userModel
			);

			ob_start();
			add_filter( 'deprecated_file_trigger_error', '__return_false' );
			comments_template();
			remove_filter( 'deprecated_file_trigger_error', '__return_false' );
			$html = ob_get_clean();
		} catch ( Throwable $e ) {
			$html = Template::print_message( $e->getMessage(), 'error', false );
		}

		return $html;
	}
}
