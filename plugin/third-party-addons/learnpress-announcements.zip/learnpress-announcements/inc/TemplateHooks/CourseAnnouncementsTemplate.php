<?php
/**
 * Template hooks Single Course display announcements.
 *
 * @since 4.0.8
 * @version 1.0.1
 */

namespace LearnPressAnnouncement\TemplateHooks;

use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LearnPress\Models\UserModel;
use LearnPress\TemplateHooks\TemplateAJAX;
use LearnPress\Models\CourseModel;
use LearnPressAnnouncement\Filters\AnnouncementFilter;
use LearnPressAnnouncement\Models\AnnouncementPostModel;
use LP_Post_DB;
use Exception;
use stdClass;
use Throwable;

class CourseAnnouncementsTemplate {
	use Singleton;

	public function init() {
		add_action( 'learn-press/single-course/announcements/layout', [ $this, 'layout' ], 10, 2 );
		add_filter( 'lp/rest/ajax/allow_callback', [ $this, 'allow_callback' ] );
	}

	/**
	 * Allow callback for ajax
	 *
	 * @param array $callbacks
	 *
	 * @return array
	 * @uses self::render_announcements
	 *
	 */
	public function allow_callback( array $callbacks ): array {
		$callbacks[] = self::class . ':render_announcements';

		return $callbacks;
	}

	/**
	 * Render layout for announcements's course
	 *
	 * @param CourseModel $courseModel
	 * @param array $data
	 */
	public function layout( CourseModel $courseModel, array $data = [] ) {
		wp_enqueue_style( 'lp-announcements-css' );
		wp_enqueue_script( 'lp-announcements-js' );
		$course_id = $courseModel->get_id();

		$callback = [
			'class'  => self::class,
			'method' => 'render_announcements',
		];
		$args     = array_merge(
			[
				'paged'     => 1,
				'course_id' => $course_id,
			],
			$data
		);

		$content = TemplateAJAX::load_content_via_ajax( $args, $callback );

		$section = [
			'wrap'     => '<div class="lp-course-announcements">',
			'content'  => $content,
			'wrap_end' => '</div>',
		];

		echo Template::combine_components( $section );
	}

	/**
	 * Render announcements
	 *
	 * @param $data array
	 *
	 * @return stdClass
	 * @since 4.0.9
	 * @version 1.0.0
	 */
	public static function render_announcements( array $data = [] ): stdClass {
		$content = new stdClass();

		try {
			$is_show_label = $data['show_label'] ?? true;
			$paged         = absint( $data['paged'] ?? 1 );
			$course_id     = $data['course_id'] ?? 0;
			$courseModel   = CourseModel::find( $course_id, true );
			if ( ! $courseModel ) {
				throw new Exception( __( 'Course not found', 'learnpress-announcements' ) );
			}

			$total_rows      = 0;
			$post_db         = LP_Post_DB::getInstance();
			$filter          = new AnnouncementFilter();
			$filter->join[]  = "INNER JOIN $post_db->tb_postmeta AS acpm ON p.ID = acpm.post_id";
			$filter->where[] = $post_db->wpdb->prepare(
				' AND acpm.meta_key=%s AND acpm.meta_value=%d',
				'_lp_course_announcement',
				$course_id
			);
			$filter->limit   = apply_filters( 'learn-press/announcements/limit', 10 );
			$filter->page    = $paged;
			$announcements   = $post_db->get_posts( $filter, $total_rows );
			$total_pages     = LP_Post_DB::get_total_pages( $filter->limit, $total_rows );

			if ( empty( $announcements ) ) {
				$content->content = '';
			} else {
				$html_announcements = '';
				foreach ( $announcements as $announcement ) {
					$announcementPostModel = AnnouncementPostModel::find( $announcement->ID, true );
					if ( ! $announcementPostModel ) {
						continue;
					}

					$html_announcements .= self::render_announcement( $announcementPostModel, $data );
				}

				$section = [
					'wrap'          => '<ul class="lp-announcements-list">',
					'label'         => $is_show_label ? sprintf(
						'<div class="lp-announcements-label">%s</div>',
						esc_html__( 'Announcements', 'learnpress-announcements' )
					) : '',
					'announcements' => $html_announcements,
					'wrap_end'      => '</ul>',
					'btn-load-more' => $paged < $total_pages ? sprintf(
						'<button class="button lp-button announcement-btn-load-more">%s</button>',
						esc_html__( 'Load more', 'learnpress-announcements' )
					) : '',
				];

				$content->content     = Template::combine_components( $section );
				$content->total_pages = $total_pages;
				$content->paged       = $filter->page;
			}
		} catch ( Throwable $e ) {
			$content->content = Template::print_message( $e->getMessage(), 'error', false );
		}

		return $content;
	}

	/**
	 * Render HTML for single announcement.
	 *
	 * @param AnnouncementPostModel $announcementPostModel
	 * @param array $data
	 *
	 * @return string
	 * @since 4.0.9
	 * @version 1.0.0
	 */
	public static function render_announcement( AnnouncementPostModel $announcementPostModel, array $data = [] ): string {
		$singleAnnouncementTemplate = SingleAnnouncementTemplate::instance();

		$html_edit_link = '';
		if ( current_user_can( UserModel::ROLE_ADMINISTRATOR )
			|| get_current_user_id() === (int) $announcementPostModel->post_author ) {
			$html_edit_link = sprintf(
				'<div class="lp-edit-post"><a href="%s">%s</a></div>',
				get_edit_post_link( $announcementPostModel->ID ),
				__( 'Edit', 'learnpress-announcement' )
			);
		}

		$section = apply_filters(
			'learn-press/layout/list-announcements/item/section',
			[
				'wrap'         => sprintf(
					'<li class="announcement lp-collapse" data-id="%s">',
					esc_attr( $announcementPostModel->ID )
				),
				'header'       => sprintf(
					'<div class="announcement-header">%s%s</div>',
					$singleAnnouncementTemplate->html_title(
						$announcementPostModel,
						[ 'tag' => 'h3' ]
					),
					'<div class="section-toggle">
						<i class="lp-icon-angle-down"></i>
						<i class="lp-icon-angle-up"></i>
					</div>'
				),
				'content'      => '<div class="announcement-content">',
				'description'  => $singleAnnouncementTemplate->html_description( $announcementPostModel ),
				'link_edit'    => $html_edit_link,
				'comment_form' => $singleAnnouncementTemplate->html_comments(
					$announcementPostModel,
					$data
				),
				'content_end'  => '</div>',
				'wrap_end'     => '</li>',
			],
			$announcementPostModel,
			$data
		);

		return Template::combine_components( $section );
	}
}
