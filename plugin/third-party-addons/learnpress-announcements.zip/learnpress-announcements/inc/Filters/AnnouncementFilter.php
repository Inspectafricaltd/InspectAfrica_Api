<?php
/**
 * Class AnnouncementFilter
 *
 * @package LearnPressAnnouncement/Filters
 * @since 4.0.9
 * @version 1.0.0
 */

namespace LearnPressAnnouncement\Filters;

use LP_Post_Type_Filter;

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();

if ( class_exists( 'CollectionFilter' ) ) {
	return;
}

class AnnouncementFilter extends LP_Post_Type_Filter {
	/**
	 * @var string
	 */
	public $post_type = LP_ANNOUNCEMENTS_CPT;
}
