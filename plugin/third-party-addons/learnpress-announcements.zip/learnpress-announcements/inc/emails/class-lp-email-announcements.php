<?php

/**
 * Class LP_Email_Announcement
 *
 * @author   ThimPress
 * @package  LearnPress/Announcements/Classes
 * @version  4.0.3
 */

use LearnPress\Models\CourseModel;
use LearnPress\Models\UserModel;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Email_Announcements' ) ) {
	/**
	 * Class LP_Email_Announcements.
	 */
	class LP_Email_Announcements extends LP_Email {
		public $course_ids;
		/**
		 * Announcement
		 *
		 * @var WP_Post
		 */
		public $announcement;

		/**
		 * LP_Email_Announcement constructor.
		 */
		public function __construct() {
			$this->id             = 'announcements';
			$this->title          = esc_html__( 'Announcement', 'learnpress-announcements' );
			$this->description    = esc_html__( 'Announcement email.', 'learnpress-announcements' );
			$this->template_base  = LP_ANNOUNCEMENTS_TEMPLATE;
			$this->template_html  = 'emails/email-text-settings.php';
			$this->template_plain = 'emails/email-plain-settings.php';

			$this->default_subject = __( '[{{site_title}}] You have a new announcement ({{announcement_name}})', 'learnpress-announcements' );
			$this->default_heading = __( 'New Announcement', 'learnpress-announcements' );

			parent::__construct();

			$variable_on_email_support = apply_filters(
				'lp/assignment/email/submitted',
				[
					'{{announcement_id}}',
					'{{announcement_name}}',
					'{{announcement_excerpt}}',
					'{{announcement_content}}',
					'{{course_id}}',
					'{{course_name}}',
					'{{course_url}}',
					'{{user_id}}',
					'{{user_name}}',
					'{{user_email}}',
					'{{user_profile_url}}',
				]
			);

			$this->support_variables = array_merge( $this->support_variables, $variable_on_email_support );
		}

		/**
		 * Handle send email
		 *
		 * @param array $params
		 */
		public function handle( array $params ) {
			try {
				if ( ! $this->check_params( $params ) ) {
					return;
				}

				$lp_course_db = LP_Course_DB::getInstance();

				foreach ( $this->course_ids as $course_id ) {
					$courseModel = CourseModel::find( $course_id, true );
					if ( ! $courseModel instanceof CourseModel ) {
						continue;
					}

					/* Get users enrolled the course */
					$user_ids = $lp_course_db->get_user_ids_enrolled( $courseModel->get_id() );
					if ( empty( $user_ids ) ) {
						continue;
					}

					$user_ids = array_keys( $user_ids );
					foreach ( $user_ids as $user_id ) {
						$userModel = UserModel::find( $user_id, true );
						if ( ! $userModel instanceof UserModel ) {
							continue;
						}

						$this->set_data_content( $courseModel, $userModel );
						$this->set_receive( $userModel->get_email() );
						$this->send_email();
					}
				}
			} catch ( Throwable $e ) {
				LP_Debug::error_log( $e );
			}
		}

		/**
		 * Check params
		 *
		 * @param array $params
		 *
		 * @return bool
		 */
		public function check_params( array $params ): bool {
			if ( ! $this->enable ) {
				return false;
			}

			$this->course_ids = $params['course_ids'] ?? [];
			$announcement_id  = $params['announcement_id'] ?? 0;

			if ( empty( $this->course_ids ) ) {
				return false;
			}

			$this->announcement = get_post( $announcement_id );
			if ( empty( $this->announcement ) ) {
				return false;
			}

			return true;
		}

		/**
		 * Set data content
		 *
		 * @param CourseModel $courseModel
		 * @param UserModel $userModel
		 */
		public function set_data_content( CourseModel $courseModel, UserModel $userModel ) {
			$variables = apply_filters(
				'lp/email/announcements/variables-mapper',
				[
					'{{announcement_id}}'      => $this->announcement->ID,
					'{{announcement_name}}'    => $this->announcement->post_title,
					'{{announcement_excerpt}}' => $this->announcement->post_excerpt,
					'{{announcement_content}}' => $this->announcement->post_content,
					'{{course_id}}'            => $courseModel->get_id(),
					'{{course_name}}'          => $courseModel->get_title(),
					'{{course_url}}'           => $courseModel->get_permalink(),
					'{{user_id}}'              => $userModel->get_id(),
					'{{user_name}}'            => $userModel->get_display_name(),
					'{{user_email}}'           => $userModel->get_email(),
					'{{user_profile_url}}'     => learn_press_user_profile_link( $userModel->get_id() ),
				]
			);

			$variables_common = $this->get_common_variables( $this->email_format );
			$this->variables  = array_merge( $variables, $variables_common );
		}
	}
}

return new LP_Email_Announcements();
