<?php

/**
 * Class AnnouncementPostModel
 *
 * @package LearnPressAnnouncement/Models
 * @version 1.0.0
 * @since 4.0.2
 */

namespace LearnPressAnnouncement\Models;

use LearnPress\Models\PostModel;
use LearnPressAnnouncement\Filters\AnnouncementFilter;
use LP_Cache;


class AnnouncementPostModel extends PostModel {
	/**
	 * @var string Post Type
	 */
	public $post_type = LP_ANNOUNCEMENTS_CPT;


	/**
	 * Get post announcement by ID
	 *
	 * @param int $post_id
	 * @param bool $check_cache
	 *
	 * @return false|static
	 */
	public static function find( int $post_id, bool $check_cache = false ) {
		$filter_post     = new AnnouncementFilter();
		$filter_post->ID = $post_id;

		$key_cache           = "announcementPostModel/find/{$post_id}";
		$lpAnnouncementCache = new LP_Cache();

		// Check cache
		if ( $check_cache ) {
			$announcementPostModel = $lpAnnouncementCache->get_cache( $key_cache );
			if ( $announcementPostModel instanceof AnnouncementPostModel ) {
				return $announcementPostModel;
			}
		}

		$announcementPostModel = self::get_item_model_from_db( $filter_post );
		// Set cache
		if ( $announcementPostModel instanceof AnnouncementPostModel ) {
			$lpAnnouncementCache->set_cache( $key_cache, $announcementPostModel );
		}

		return $announcementPostModel;
	}
}
