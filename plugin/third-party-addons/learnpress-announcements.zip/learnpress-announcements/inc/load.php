<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Announcements/Classes
 * @version  4.0.2
 */

use LearnPress\Background\LPBackgroundAjax;
use LearnPress\Helpers\Template;
use LearnPress\Models\CourseModel;
use LearnPress\Models\UserItems\UserCourseModel;
use LearnPress\Models\UserModel;
use LearnPressAnnouncement\TemplateHooks\CourseAnnouncementsTemplate;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Announcements' ) ) {
	/**
	 * Class LP_Addon_Announcements.
	 */
	class LP_Addon_Announcements extends LP_Addon {
		public $version         = LP_ADDON_ANNOUNCEMENTS_VER;
		public $require_version = LP_ADDON_ANNOUNCEMENTS_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_ANNOUNCEMENTS_FILE;
		public $text_domain     = 'learnpress-announcements';

		/**
		 * @var null
		 */
		protected static $_instance = null;

		/**
		 * Instance.
		 *
		 * @return LP_Addon_Announcements|null
		 */
		public static function instance() {
			if ( ! self::$_instance ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * LP_Addon_Announcements constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
			CourseAnnouncementsTemplate::instance();
			// Email settings
			$this->emails_setting();
			// Email group
			add_filter( 'learn-press/email-section-classes', [ $this, 'add_email_group' ] );
		}

		/**
		 * Define Learnpress Announcement constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_ANNOUNCEMENTS_URI', plugins_url( '/', LP_ADDON_ANNOUNCEMENTS_FILE ) );
			define( 'LP_ANNOUNCEMENTS_INC', LP_ANNOUNCEMENTS_PATH . '/inc/' );
			define( 'LP_ANNOUNCEMENTS_TEMPLATE', LP_ANNOUNCEMENTS_PATH . '/templates/' );
			define( 'LP_ANNOUNCEMENTS_CPT', 'lp_announcements' );
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 *
		 * @since 3.0.0
		 */
		protected function _includes() {
			include_once LP_ANNOUNCEMENTS_INC . 'functions.php';
			include_once LP_ANNOUNCEMENTS_INC . 'class-lp-announcements-post-type.php';
			include_once LP_ANNOUNCEMENTS_INC . 'push-notifications/class-init.php';
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			add_filter(
				'learnpress/course/metabox/tabs',
				function ( $tabs, $post_id ) {
					$course = CourseModel::find( $post_id, true );
					if ( ! $course || $course->is_offline() ) {
						return $tabs;
					}

					$tabs['course_announcements'] = array(
						'label'    => esc_html__( 'Announcements', 'learnpress' ),
						'target'   => 'announcements_course_data',
						'icon'     => 'dashicons-megaphone',
						'priority' => 60,
					);

					return $tabs;
				},
				10,
				2
			);

			add_action( 'lp_course_data_setting_tab_content', array( $this, '_add_course_meta_content' ) );
			add_action( 'learnpress_save_lp_course_metabox', array( $this, '_save_meta_box' ), 10 );

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

			// Ajax
			add_action( 'wp_ajax_lp_announcements_lists_course', array( __CLASS__, 'lp_announcements_lists_course' ) );
			add_action( 'wp_ajax_lp_create_announcement', [ $this, 'lp_create_announcement' ] );
			add_action( 'wp_ajax_lp_remove_announcement', array( __CLASS__, 'ajax_remove_announcement' ) );
			add_action( 'wp_ajax_send_mail_announcements', [ $this, 'send_mail_announcements' ] );

			/* Render Frontend */
			add_filter( 'learn-press/course-tabs', array( $this, 'add_single_course_announcements_tab' ), 5 );
			// Show announcements before section instructor
			add_filter(
				'learn-press/single-course/modern/section-instructor',
				array(
					$this,
					'single_course_show_announcements',
				),
				10,
				3
			);
			add_filter( 'comment_post_redirect', array( $this, 'announcement_comment_post_redirect' ), 100, 2 );
			add_action( 'learn-press/frontend-editor/enqueue', array( $this, 'frontend_editor_enqueue' ) );
			add_action( 'get_comment_link', array( $this, 'comment_link' ), 10, 2 );
		}

		public function frontend_editor_enqueue() {
			wp_enqueue_style(
				'lp-announcements-editor-css',
				LP_ADDON_ANNOUNCEMENTS_URI . 'assets/css/admin.announcements.css',
				array(),
				LP_ADDON_ANNOUNCEMENTS_VER
			);
			wp_enqueue_script(
				'lp-announcements-editor-js',
				LP_ADDON_ANNOUNCEMENTS_URI . 'assets/js/admin.announcements.js',
				array( 'frontend-course-editor' ),
				LP_ADDON_ANNOUNCEMENTS_VER,
				true
			);
		}

		/**
		 * Enqueue scripts.
		 */
		public function enqueue_assets() {
			$min    = '.min';
			$ver    = LP_ADDON_ANNOUNCEMENTS_VER;
			$is_rtl = is_rtl() ? '-rtl' : '';
			if ( LP_Debug::is_debug() ) {
				$min = '';
				$ver = uniqid();
			}

			// Load assets for admin
			if ( is_admin() ) {
				wp_register_style(
					'lp-announcements-admin-css',
					$this->get_plugin_url( 'assets/dist/css/admin.announcements' . $is_rtl . $min . '.css' ),
					array(),
					$ver
				);

				wp_register_script(
					'lp-announcements-admin-js',
					$this->get_plugin_url( "assets/dist/js/admin.announcements{$min}.js" ),
					array( 'jquery' ),
					$ver,
					[ 'strategy' => 'defer' ]
				);

				return;
			}

			// Load assets for frontend
			wp_register_style(
				'lp-announcements-css',
				$this->get_plugin_url( "assets/dist/css/announcements{$is_rtl}{$min}.css" ),
				[],
				$ver
			);

			wp_register_script(
				'lp-announcements-js',
				$this->get_plugin_url( "assets/dist/js/announcements{$min}.js" ),
				[],
				$ver,
				[ 'strategy' => 'async' ]
			);
		}

		public function _add_course_meta_content() {
			wp_enqueue_style( 'lp-announcements-admin-css' );
			wp_enqueue_script( 'lp-announcements-admin-js' );

			include_once LP_ANNOUNCEMENTS_INC . 'admin/views/metabox-content.php';
		}

		public function _save_meta_box( $post_id ) {
			if ( isset( $_POST['_lp_learnpress_announcements_send_mail'] ) && $_POST['_lp_learnpress_announcements_send_mail'] === 'on' ) {
				update_post_meta( $post_id, '_lp_learnpress_announcements_send_mail', 'on' );
			} else {
				update_post_meta( $post_id, '_lp_learnpress_announcements_send_mail', 'off' );
			}

			/* Save Display Comment Meta */
			if ( isset( $_POST['_lp_learnpress_announcements_display_discussion'] ) && $_POST['_lp_learnpress_announcements_display_discussion'] === 'on' ) {
				update_post_meta( $post_id, '_lp_learnpress_announcements_display_discussion', 'on' );
			} else {
				update_post_meta( $post_id, '_lp_learnpress_announcements_display_discussion', 'off' );
			}
		}

		/**
		 * Lists course.
		 */
		public static function lp_announcements_lists_course() {
			$user_id = get_current_user_id();
			if ( ( isset( $_POST['action'] ) && $_POST['action'] === 'lp_announcements_lists_course' )
				&& ! empty( $_POST['post_id'] ) ) {

				$post = get_post( $_POST['post_id'] );
				$user = $post->post_author;

				if ( empty( $user ) ) {
					wp_die();
				}
				$lp_args = array(
					'post_type'      => LP_COURSE_CPT,
					'post_status '   => 'publish',
					'posts_per_page' => '-1',
					'author'         => $user_id,
				);

				if ( user_can( $user_id, 'administrator' ) ) {
					$lp_args['author'] = get_post_field( 'post_author' );
				}

				if ( ! empty( $_POST['post__not_in'] ) ) {
					$lp_args['post__not_in'] = explode( ',', $_POST['post__not_in'] );
				}

				$query = new WP_Query( $lp_args );

				ob_start();

				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
						global $post;
						setup_postdata( $post );
						require LP_ANNOUNCEMENTS_INC . 'admin/views/popup-loop-item.php';
					}
					wp_reset_postdata();
				} else {
					require LP_ANNOUNCEMENTS_INC . 'admin/views/popup-not-found.php';
				}

				$result = ob_get_contents();
				ob_clean();
				echo $result;
			}
			wp_die();
		}


		/**
		 * Ajax create announcement.
		 */
		public function lp_create_announcement() {
			$response          = new stdClass();
			$response->status  = 'error';
			$response->message = 'error';
			$response->data    = new stdClass();

			try {
				if ( empty( $_POST['nonce'] ) || ! check_ajax_referer( 'lp-create-announcement', 'nonce', false ) ) {
					throw new Exception( 'Request invalid' );
				}

				if ( empty( $_POST['post_id'] ) || empty( $_POST['posts_id'] ) ) {
					throw new Exception( 'Invalid params!' );
				}

				if ( empty( $_POST['title'] ) ) {
					throw new Exception( 'Title not empty' );
				}

				$course_id      = absint( $_POST['post_id'] );
				$course_ids_str = LP_Request::get_param( 'posts_id' );
				$title          = LP_Request::get_param( 'title', '', 'html' );
				$content        = LP_Request::get_param( 'content', '', 'html' );
				$send_mail      = isset( $_POST['send_mail'] ) && 'true' === $_POST['send_mail'];

				$args = array(
					'post_status'  => 'publish',
					'post_type'    => LP_ANNOUNCEMENTS_CPT,
					'post_title'   => $title,
					'post_content' => $content,
				);

				$course = get_post( $course_id );
				if ( ! empty( $course ) ) {
					$args['post_author'] = $course->post_author;
				}

				if ( isset( $_POST['display_comment'] ) ) {
					if ( $_POST['display_comment'] === 'true' ) {
						$args['comment_status'] = 'open';
					} else {
						$args['comment_status'] = 'close';
					}
				}

				$new_announcement_id = wp_insert_post( $args );

				// Set multiple metadata for current announcement
				$course_ids = explode( ',', $course_ids_str );
				foreach ( $course_ids as $course_id ) {
					add_post_meta( $new_announcement_id, '_lp_course_announcement', $course_id );
				}

				// Send mail to users enrolled the course
				if ( $send_mail ) {
					/**
					 * @uses SendEmailAjax::send_mail_announcement_to_user_enrolled
					 */
					LPBackgroundAjax::handle(
						[
							'lp-load-ajax'    => 'send_mail_announcement_to_user_enrolled',
							'course_ids'      => $course_ids,
							'announcement_id' => $new_announcement_id,
						]
					);
				}

				$current_time = strtotime( current_time( 'mysql', 1 ) );
				$post_time    = get_the_time( 'U', $new_announcement_id );

				if ( ( $current_time - $post_time ) < DAY_IN_SECONDS ) {
					$date = human_time_diff( $post_time, $current_time ) . __( ' ago', 'learnpress-announcement' );
				} else {
					$date = get_the_date( '', $new_announcement_id );
				}

				$response->status      = 'success';
				$response->message     = 'Create announcement success';
				$response->data->id    = $new_announcement_id;
				$response->data->title = get_the_title( $new_announcement_id );
				$response->data->date  = $date;
			} catch ( Throwable $e ) {
				$response->message = $e->getMessage();
			}

			wp_send_json( $response );
		}

		/**
		 * Ajax remove announcement.
		 */
		public static function ajax_remove_announcement() {
			if ( ! user_can( get_current_user_id(), ADMIN_ROLE ) ) {
				return;
			}

			$course_id = LP_Request::get_param( 'course_id' );
			$post_id   = LP_Request::get_param( 'post_id' );

			if ( empty( $course_id ) || empty( $post_id ) ) {
				wp_die();
			}

			delete_post_meta( $post_id, '_lp_course_announcement', $course_id );
		}

		/**
		 * Ajax send mail.
		 *
		 * @editor tungnx
		 * @modify 4.0.3
		 */
		public function send_mail_announcements() {
			$response          = new stdClass();
			$lp_course_db      = LP_Course_DB::getInstance();
			$response->status  = 'error';
			$response->message = 'error';

			try {
				if ( empty( $_POST['announcement_id'] ) || empty( $_POST['course_id'] ) ) {
					throw new Exception( __( 'Params invalid!', 'learnpress-announcements' ) );
				}

				$announcement_id = LP_Helper::sanitize_params_submitted( $_POST['announcement_id'] );
				$course_id       = absint( $_POST['course_id'] );

				/* Get users enrolled the course */
				$user_ids = $lp_course_db->get_user_ids_enrolled( $course_id );

				if ( ! empty( $user_ids ) ) {
					$user_ids = array_keys( $user_ids );
				} else {
					throw new Exception( 'No user enrolled course' );
				}

				$status_announcement = get_post_status( $announcement_id );
				$course              = CourseModel::find( $course_id, true );
				if ( ! $course || 'trash' === $course->post_status ) {
					throw new Exception( 'Course is invalid!' );
				}

				if ( empty( $status_announcement ) || $status_announcement == 'trash' ) {
					throw new Exception( 'Announcement deleted in trash!' );
				}
				$course_ids = array( $course_id );

				$params = array(
					'course_ids'      => $course_ids,
					'announcement_id' => $announcement_id,
				);

				$email = new LP_Email_Announcements();
				$email->handle( $params );

				//$emails_string_send_success = implode( ',', $email_arr_send_success );

				$response->status  = 'success';
				$response->message = 'Send mail success';
			} catch ( Throwable $e ) {
				$response->message = $e->getMessage();
			}

			wp_send_json( $response );
		}

		/**
		 * @param $tabs
		 *
		 * @return mixed
		 */
		public function add_single_course_announcements_tab( $tabs ) {
			$userModel = UserModel::find( get_current_user_id(), true );
			if ( ! $userModel ) {
				return $tabs;
			}

			$course_id   = get_the_ID();
			$courseModel = CourseModel::find( $course_id, true );
			if ( ! $courseModel ) {
				return $tabs;
			}

			$can_show = $this->can_show_announcements_on_course( $courseModel, $userModel );
			if ( is_wp_error( $can_show ) ) {
				return $tabs;
			}

			$tabs['announcements'] = array(
				'title'    => __( 'Announcements', 'learnpress-announcements' ),
				'priority' => 30,
				'callback' => function () {
					$this->single_course_announcements_tab_content( [ 'show_label' => false ] );
				},
			);

			return $tabs;
		}

		/**
		 * Check can show announcements on course.
		 *
		 * @param CourseModel $courseModel
		 * @param UserModel $userModel
		 *
		 * @return bool|WP_Error
		 * @since 4.0.8
		 */
		public function can_show_announcements_on_course( CourseModel $courseModel, UserModel $userModel ) {
			$courseAuthor    = $courseModel->get_author_model();
			$userCourseModel = UserCourseModel::find( $userModel->get_id(), $courseModel->get_id(), true );

			if ( ( $userCourseModel && $userCourseModel->has_enrolled() )
				|| ( $courseAuthor && $courseAuthor->get_id() === get_current_user_id() )
				|| user_can( get_current_user_id(), ADMIN_ROLE ) ) {
				$flag = true;
			} else {
				$flag = new WP_Error(
					'can_not_show_announcements',
					__( 'Can not show announcements', 'learnpress-announcements' )
				);
			}

			return apply_filters( 'learn-press/announcements/can-show-on-course', $flag, $courseModel, $userModel );
		}

		/**
		 * Announcements content in single course page.
		 */
		public function single_course_announcements_tab_content( array $data = [] ) {
			$courseModel = CourseModel::find( get_the_ID(), true );
			if ( ! $courseModel ) {
				return;
			}

			do_action( 'learn-press/single-course/announcements/layout', $courseModel, $data );
		}

		/**
		 * Display announcements in single course page.
		 * Hook before section instructor
		 * To show on single course modern template
		 * and build via Gutenberg. When create a block for announcements done, need check is theme Gutenberg to return, not add to section.
		 *
		 * @param array $section
		 * @param CourseModel $courseModel
		 * @param $userModel
		 *
		 * @return array
		 * @since 4.0.8
		 * @version 1.0.1
		 */
		public function single_course_show_announcements( array $section, CourseModel $courseModel, $userModel ): array {
			if ( ! $userModel instanceof UserModel ) {
				return $section;
			}

			$can_show = $this->can_show_announcements_on_course( $courseModel, $userModel );
			if ( is_wp_error( $can_show ) ) {
				return $section;
			}

			ob_start();
			$this->single_course_announcements_tab_content();
			$html = ob_get_clean();

			return apply_filters(
				'learn-press/announcements/single-course-show-announcements/position',
				Template::insert_value_to_position_array( $section, 'before', 'wrapper', 'announcements', $html ),
				$html,
				$section,
				$courseModel,
				$userModel
			);
		}

		/**
		 * @param $location
		 * @param $comment
		 *
		 * @return string
		 */
		public function announcement_comment_post_redirect( $location, $comment ) {
			if ( ! empty( $_REQUEST['lp_comment_announcement_from_course_url'] ) ) {
				return $_REQUEST['lp_comment_announcement_from_course_url'] . '?tab=announcements#comment-' . $comment->comment_ID;
			}

			return $location;
		}

		/**
		 * Add email settings
		 */
		public function emails_setting() {
			if ( ! class_exists( 'LP_Emails' ) ) {
				return;
			}

			if ( ! class_exists( 'LP_Settings_Emails_Group' ) ) {
				include_once LP_PLUGIN_PATH . 'inc/admin/settings/email-groups/class-lp-settings-emails-group.php';
			}

			$emails = LP_Emails::instance()->emails;

			$emails['LP_Email_Announcements'] = include_once 'emails/class-lp-email-announcements.php';

			LP_Emails::instance()->emails = $emails;
		}

		/**
		 * Add email group
		 *
		 * @param array $groups
		 *
		 * @return array
		 */
		public function add_email_group( array $groups ): array {
			$groups[] = include 'admin/settings/email-groups/class-lp-settings-announcements-emails.php';

			return $groups;
		}

		/**
		 * Hook to change redirect link after comment in announcement.
		 */
		public function comment_link( $comment_link, $comment ) {
			try {
				if ( ! $comment instanceof \WP_Comment ) {
					return $comment_link;
				}

				if ( get_post_type( $comment->comment_post_ID ) == LP_ANNOUNCEMENTS_CPT ) {
					$comment_link = wp_get_referer() . '#comment-' . $comment->comment_ID;
				}

				return $comment_link;
			} catch ( Throwable $e ) {
				error_log( $e->getMessage() );
			}

			return $comment_link;
		}
	}
}
