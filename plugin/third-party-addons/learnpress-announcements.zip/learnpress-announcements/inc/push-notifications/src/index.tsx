import './index.scss';

import { __ } from '@wordpress/i18n';
import { useState, createRoot } from '@wordpress/element';
import { Button } from '@wordpress/components';

import Edit from './Edit';
import Table from './Table';

function App() {
	const [ isOpen, setOpen ] = useState( false );
	const [ id, setId ] = useState( 0 );

	return (
		<div className="lp-push-notifications">
			<h1 className="lp-push-notifications__heading">
				{ __( 'Notifications' ) }

				<Button
					variant="primary"
					className="lp-push-notifications__heading__button"
					style={ { height: 30 } }
					onClick={ () => {
						setId( 0 );
						setOpen( ! isOpen );
					} }
				>
					{ __( 'Add new' ) }
				</Button>
			</h1>

			<Table setId={ setId } setOpen={ setOpen } />

			{ isOpen && (
				<Edit id={ id } isOpen={ isOpen } setOpen={ setOpen } />
			) }
		</div>
	);
}

const root = createRoot( document.getElementById( 'learnpress-push-notifications-root' ) );

root.render( <App /> );
