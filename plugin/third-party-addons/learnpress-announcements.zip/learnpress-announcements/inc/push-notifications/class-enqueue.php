<?php
namespace LP_Announcements\Push_Notifications;

use LP_Addon_Announcements_Preload;
use LP_Debug;

class Enqueue {

	protected static $instance = null;

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
	}

	public function admin_enqueue_scripts() {
		$addon = LP_Addon_Announcements_Preload::$addon;
		$min   = '.min';
		$ver   = $addon->version;
		if ( LP_Debug::is_debug() ) {
			$min = '';
			$ver = uniqid();
		}

		$screen = get_current_screen();
		if ( strpos( $screen->id, 'learnpress-push-notifications' ) !== false ) {
			wp_enqueue_media();

			$file_info = include $addon->plugin_folder_path . '/assets/dist/js/push-notifications.asset.php';
			wp_enqueue_script(
				'learnpress-push-notifications',
				$addon->get_plugin_url( "assets/dist/js/push-notifications{$min}.js" ),
				$file_info['dependencies'],
				$ver,
				true
			);
			wp_enqueue_style(
				'learnpress-push-notifications',
				$addon->get_plugin_url( "assets/dist/js/push-notifications.css" ),
				array(),
				$ver
			);

			// add localize.
			wp_localize_script(
				'learnpress-push-notifications',
				'learnpressPushNotificationsSettings',
				apply_filters(
					'learnpress_push_notifications_settings',
					array(
						'nonce'           => wp_create_nonce( 'learnpress-push-notifications' ),
						'isMutilPlatform' => false,
					)
				)
			);
		}
	}

	// instance.
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}
Enqueue::instance();
