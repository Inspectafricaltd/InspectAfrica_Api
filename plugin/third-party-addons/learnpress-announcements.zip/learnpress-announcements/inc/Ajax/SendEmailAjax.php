<?php
/**
 * class SendEmailAjax
 *
 * Handle send mails for announcement.
 *
 * @since 4.1.1
 * @version 1.0.0
 */

namespace LearnPressAnnouncement\Ajax;

use LearnPress\Ajax\AbstractAjax;
use LP_Email;
use LP_Email_Announcements;
use LP_Helper;
use LP_REST_Response;
use Throwable;

class SendEmailAjax extends AbstractAjax {
	/**
	 * Send mail announcement to user enrolled courses.
	 *
	 * @since 4.1.1
	 * @version 1.0.0
	 */
	public function send_mail_announcement_to_user_enrolled() {
		$response = new LP_REST_Response();

		try {
			$data_send = LP_Helper::sanitize_params_submitted( $_POST ?? [] );

			$email_classes = apply_filters(
				'learn-press/announcement/users-enrolled-courses/send-mail',
				[
					LP_Email_Announcements::class,
				]
			);

			foreach ( $email_classes as $email_class ) {
				if ( class_exists( $email_class ) ) {
					$email = new $email_class();
					/** @var LP_Email $email */
					$email->handle( $data_send );
				}
			}
		} catch ( Throwable $e ) {
			$response->status  = 'error';
			$response->message = $e->getMessage();
		}

		wp_send_json( $response );
	}
}
