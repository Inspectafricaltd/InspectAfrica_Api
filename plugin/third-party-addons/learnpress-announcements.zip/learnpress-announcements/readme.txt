=== LearnPress - Announcements ===
Contributors: thimpress, chinhtm, leehld
Donate link:
Tags: lms, elearning, learning management system, education, course.
Tested up to: 6.8
Stable tag: 4.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

LearnPress Announcements is an extension plugin to provide announcements for course in LearnPress.

== Description ==
LearnPress Announcements is an extension plugin to provide certificate for course in LearnPress.

== Installation ==

**From your WordPress dashboard**
1. Visit 'Plugin > Add new'.
2. Search for 'LearnPress Announcements'.
3. Activate LearnPress from your Plugins page.

**From WordPress.org**
1. Search, select and download LearnPress Announcements.
2. Activate the plugin through the 'Plugins' menu in WordPress Dashboard.

== Frequently Asked Questions ==

Check out [LearnPress](http://docs.thimpress.com/learnpress) sites

== Screenshots ==

1. Plugin frontend

== Changelog ==

= 4.1.2 (2025-11-10) =
~ Fixed: send email.

= 4.1.1 (2025-09-19) =
~ Fixed: emails hooks for compatible with LP 4.2.9.2.

= 4.1.0 (2025-07-25) =
~ Fix check show announcement on tab course.
~ Fix loading css when send mail.

= 4.0.9 (2025-07-07) =
~ Load announcements via AJAX.
~ Added: load more, default 10 items per page, hook "learn-press/announcements/limit".
~ Update: UI for list announcements.
~ Remove: library "jquery-ui-accordion".
~ Remove field meta box: '_lp_announcements_display_comments', because it to set same value to key '_lp_learnpress_announcements_display_discussion'

= 4.0.8.1 (2025-05-09) =
~ Tweak: position hook display on single course Modern, Gutenberg.

= 4.0.8 (2025-05-08) =
~ Display on single course Modern layout and Gutenberg.

= 4.0.7 (2025-03-05) =
~ Fixed: minor bugs.

= 4.0.6 (2024-08-28) =
~ Added: load js defer.
~ Use CourseModel instead of "learn_press_get_course".
~ Remove function deprecated old.
~ Use new hook 'learnpress/course/metabox/tabs' instead of 'lp_course_data_settings_tabs'.

= 4.0.5 (2023-12-25) =
~ Update push notification.
~ Update for mobile app use with flutter.

= 4.0.4 =
~ Optimize code.
~ Added feature: push notification.

= 4.0.3 =
~ Fixed: send emails.

= 4.0.2 =
~ Fixed: Not show course when search to select courses.

= 4.0.1 =
~ Fixed: Save email setting.

= 4.0.0 =
~ Fix compatible LP4

= 3.0.4 =
+ Fix jquery ready not compatible WP 5.5
+ Fix $user_data->roles empty

= 3.0.3 =
+ Fixed bug not sending mail.

= 3.0.2 =
+ Fixed bug not appear Post button in Course Edit page.

= 3.0.1 =
+ Fix bug not send emails to the enrolled students!
+ Update language file.

= 3.0.0 =
+ Updated to be compatible with LearnPress 3.0.0

= 1.1 =
+ Update override template
+ Compatible with LearnPress 2.1.7

= 1.0 =
+ Compatible with LearnPress 1.0

= 0.9.0 =
+ The first beta release.

== Upgrade Notice ==
Later :)

== Other note ==
<a href="http://docs.thimpress.com/learnpress" target="_blank">Documentation</a> is available in ThimPress site.
<a href="https://github.com/LearnPress/LearnPress/" target="_blank">LearnPress github repo.</a>
