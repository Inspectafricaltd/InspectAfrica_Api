<?php
/**
 * Tab Coming soon and fields
 */

if ( ! isset( $is_enable_coming_soon ) ) {
	return;
}

return apply_filters(
	'learn-press/coming-soon-course/edit-course-tabs',
	array(
		'label'    => esc_html__( 'Coming soon', 'learnpress-collections' ),
		'icon'     => 'dashicons-clock',
		'target'   => 'lp_coming_soon_course_data',
		'priority' => 60,
		'content'  => array(
			'_lp_coming_soon'           => new LP_Meta_Box_Checkbox_Field(
				esc_html__( 'Enable', 'learnpress-coming-soon-courses' ),
				esc_html__( 'Enable coming soon mode.', 'learnpress-coming-soon-courses' ),
				'no'
			),
			'_lp_coming_soon_msg'       => new LP_Meta_Box_Textarea_Field(
				esc_html__( 'Message', 'learnpress-coming-soon-courses' ),
				esc_html__( 'Message to display when course is in coming soon mode.', 'learnpress-coming-soon-courses' ),
				esc_html__( 'This course will be coming soon', 'learnpress-coming-soon-courses' ),
				array(
					'dependency' => [
						'name'       => '_lp_coming_soon',
						'is_disable' => ! $is_enable_coming_soon,
					],
				)
			),
			'_lp_coming_soon_end_time'  => new LP_Meta_Box_Date_Field(
				esc_html__( 'End time', 'learnpress-coming-soon-courses' ) . sprintf( ' (%s)', LP_Datetime::get_timezone_string() ),
				esc_html__( 'End time of coming soon mode.', 'learnpress-coming-soon-courses' ),
				'',
				array(
					'wrapper_class' => '',
					'placeholder'   => _x( 'Date', 'placeholder', 'learnpress-coming-soon-courses' ),
					'dependency'    => [
						'name'       => '_lp_coming_soon',
						'is_disable' => ! $is_enable_coming_soon,
					],
				)
			),
			'_lp_coming_soon_countdown' => new LP_Meta_Box_Checkbox_Field(
				esc_html__( 'Countdown', 'learnpress-coming-soon-courses' ),
				esc_html__( 'Enable countdown.', 'learnpress-coming-soon-courses' ),
				'no',
				array(
					'dependency' => [
						'name'       => '_lp_coming_soon',
						'is_disable' => ! $is_enable_coming_soon,
					],
				)
			),
			'_lp_coming_soon_showtext'  => new LP_Meta_Box_Checkbox_Field(
				esc_html__( 'Show date time text', 'learnpress-coming-soon-courses' ),
				esc_html__( 'Show date and time text (days, hours, minutes, seconds) on single course page.', 'learnpress-coming-soon-courses' ),
				'no',
				array(
					'dependency' => [
						'name'       => '_lp_coming_soon',
						'is_disable' => ! $is_enable_coming_soon,
					],
				)
			),
			'_lp_coming_soon_metadata'  => new LP_Meta_Box_Checkbox_Field(
				esc_html__( 'Show metadata', 'learnpress-coming-soon-courses' ),
				esc_html__( 'Show meta data (such as info about Instructor, price, so on) of the course.', 'learnpress-coming-soon-courses' ),
				'no',
				array(
					'dependency' => [
						'name'       => '_lp_coming_soon',
						'is_disable' => ! $is_enable_coming_soon,
					],
				)
			),
			'_lp_coming_soon_details'   => new LP_Meta_Box_Checkbox_Field(
				esc_html__( 'Show details', 'learnpress-coming-soon-courses' ),
				esc_html__( 'Show details content of the course.', 'learnpress-coming-soon-courses' ),
				'no',
				[
					'dependency' => [
						'name'       => '_lp_coming_soon',
						'is_disable' => ! $is_enable_coming_soon,
					],
				]
			),
		),
	)
);
