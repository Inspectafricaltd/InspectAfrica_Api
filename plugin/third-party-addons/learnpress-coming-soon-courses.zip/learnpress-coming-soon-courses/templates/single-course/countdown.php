<?php
/**
 * Template for displaying coming soon countdown.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/addons/coming-soon-courses/single-course/countdown.php.
 *
 * @author ThimPress
 * @package LearnPress/Coming-Soon-Courses/Templates
 * @version 3.0.1
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! isset( $timestamp_remain ) ) {
	return;
}
?>

<div class="countdown learnpress-course-coming-soon course-content_coming_soon"
	 data-showtext="<?php echo esc_attr( $showtext ?? 'no' ) ?>"
	 data-timestamp-remain="<?php echo esc_attr( $timestamp_remain ); ?>"
	 data-speed="500">
</div>
