<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Coming-Soon-Courses/Classes
 * @version  3.0.0
 */

use LearnPress\Models\CourseModel;
use LP_Addon_Coming_Soon\Elementor\ComingSoonElementorHandler;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Coming_Soon_Courses' ) ) {
	/**
	 * Class LP_Addon_Coming_Soon_Courses.
	 */
	class LP_Addon_Coming_Soon_Courses extends LP_Addon {
		public static $instance;
		public $version         = LP_ADDON_COMING_SOON_COURSES_VER;
		public $require_version = LP_ADDON_COMING_SOON_COURSES_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_COMING_SOON_COURSES_FILE;
		public $text_domain     = 'learnpress-coming-soon-courses';

		const KEY_META_MESSAGE       = '_lp_coming_soon_msg';
		const KEY_META_COUNTDOWN     = '_lp_coming_soon_countdown';
		const KEY_META_END_TIME      = '_lp_coming_soon_end_time';
		const KEY_META_ENABLE        = '_lp_coming_soon';
		const KEY_META_SHOW_TEXT     = '_lp_coming_soon_showtext';
		const KEY_META_SHOW_METADATA = '_lp_coming_soon_metadata';
		const KEY_META_SHOW_DETAILS  = '_lp_coming_soon_details';

		/**
		 * Hold the course ids is coming soon
		 *
		 * @var array
		 */
		protected $_coming_soon_courses = array();

		/**
		 * @var null
		 */
		protected $_course_coming_soon = null;

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * LP_Addon_Coming_Soon_Courses constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define constants.
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_COMING_SOON_COURSES_PATH', dirname( LP_ADDON_COMING_SOON_COURSES_FILE ) );
		}

		/**
		 * Includes files.
		 */
		protected function _includes() {
			// Elementor
			require_once LP_ADDON_COMING_SOON_COURSES_PATH . '/inc/functions.php';
			if ( is_plugin_active( 'elementor/elementor.php' ) ) {
				require_once LP_ADDON_COMING_SOON_COURSES_PATH . '/inc/Elementor/ComingSoonElementorHandler.php';
				ComingSoonElementorHandler::instance();
			}
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			add_action( 'learn-press/course-content-summary', array( $this, 'coming_soon_message' ), 10 );
			add_action( 'learn-press/course-content-summary', array( $this, 'coming_soon_countdown' ), 10 );
			add_action( 'template_redirect', array( $this, 'coming_soon_option_v4' ), 10 );
			remove_action(
				'learn-press/course-meta-secondary-left',
				LearnPress::instance()->template( 'course' )->callback( 'single-course/meta/duration' ),
				10
			);

			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
			// Check can purchase course via product of Woo (Assign courses to product feature)
			add_filter(
				'learnpress/wc-order/can-purchase-product',
				array(
					$this,
					'can_purchase_product_has_courses',
				),
				10,
				2
			);
			// Check can purchase course
			add_filter( 'learn-press/user/can-purchase-course', array( $this, 'can_purchase_course' ), 20, 3 );

			add_filter( 'learnpress/course/metabox/tabs', array( $this, 'add_course_metabox' ), 10, 2 );
		}

		public function add_course_metabox( $data, $post_id ) {
			$course = CourseModel::find( $post_id, true );
			if ( ! $course ) {
				return $data;
			}

			$is_enable_coming_soon = $this->is_enable_coming_soon( $post_id );

			$data['course_coming_soon'] = include $this->plugin_folder_path . '/config/edit-course.php';

			return $data;
		}

		/**
		 * Check can purchase product has courses - LP Woo
		 *
		 * @param bool $can_purchase
		 * @param int $course_id
		 *
		 * @return bool
		 * @since 4.0.3
		 * @editor minhpd
		 */
		public function can_purchase_product_has_courses( $can_purchase, $course_id ) {
			if ( $this->is_coming_soon( $course_id ) ) {
				$can_purchase = false;
			}

			return $can_purchase;
		}

		/**
		 * Filer user can purchase course when show button by course is comingsoon
		 *
		 * @param bool $can_purchase
		 * @param int $user_id
		 * @param int $course_id
		 *
		 * @return bool
		 * @since 4.0.0
		 * @editor minhpd
		 */
		public function can_purchase_course( $can_purchase, $user_id, $course_id ) {
			if ( $this->is_coming_soon( $course_id ) ) {
				$can_purchase = false;
			}

			return $can_purchase;
		}

		/**
		 * @return string
		 */
		public function get_plugin_file() {
			return $this->plugin_file;
		}

		/**
		 * @throws Exception
		 *
		 * return void
		 */
		public function coming_soon_option_v4() {
			// Check current page is single course
			if ( ! LP_Page_Controller::is_page_single_course() ) {
				return;
			}

			$course_id = get_the_ID();
			if ( ! $course_id ) {
				return;
			}

			$key         = 'coming_soon_course_' . $course_id;
			$cache_first = LP_Cache::cache_load_first( 'get', $key );
			if ( false !== $cache_first ) {
				$courseModel = $cache_first;
			} else {
				$courseModel = CourseModel::find( $course_id, true );
				// Set cache first
				$cache_value = $courseModel instanceof CourseModel ? $courseModel : null;
				LP_Cache::cache_load_first( 'set', $key, $cache_value );
			}

			if ( ! $courseModel ) {
				return;
			}

			$is_enable_coming_soon      = $this->is_enable_coming_soon( $course_id );
			$check_coming_soon_metadata = $courseModel->get_meta_value_by_key( '_lp_coming_soon_metadata', 'no' );
			$check_coming_soon_details  = $courseModel->get_meta_value_by_key( '_lp_coming_soon_details', 'no' );
			if ( ! $is_enable_coming_soon ) {
				return;
			}

			if ( $this->is_coming_soon( $course_id ) ) {
				remove_all_actions( 'learn-press/course-buttons' );
				if ( $check_coming_soon_metadata == 'no' ) {
					// Check conditions before execution
					remove_action(
						'learn-press/course-meta-secondary-left',
						LearnPress::instance()->template( 'course' )->func( 'count_object' ),
						20
					);
					remove_action(
						'learn-press/course-content-summary',
						LearnPress::instance()->template( 'course' )->func( 'course_extra_boxes' ),
						40
					);
					add_action( 'learn_press_course_price_html', array( $this, 'set_course_price_html_empty' ) );
					LearnPress::instance()->template( 'course' )->remove_callback(
						'learn-press/course-meta-secondary-left',
						'single-course/meta/level',
						20
					);
					LearnPress::instance()->template( 'course' )->remove_callback(
						'learn-press/course-meta-secondary-left',
						'single-course/meta/category',
						20
					);
					LearnPress::instance()->template( 'course' )->remove_callback(
						'learn-press/course-meta-secondary-left',
						'single-course/meta/instructor',
						20
					);
					LearnPress::instance()->template( 'course' )->remove_callback(
						'learn-press/course-meta-secondary-left',
						'single-course/meta/duration',
						10
					);
					LearnPress::instance()->template( 'course' )->remove_callback(
						'learn-press/course-meta-primary-left',
						'single-course/meta/category',
						20
					);

					// Remove add_filter group
					add_filter(
						'learn-press/course-tabs',
						function ( $defaults ) {
							unset( $defaults['instructor'] );

							return $defaults;
						},
						10,
						1
					);

					add_filter(
						'learn-press/course-tabs',
						function ( $defaults ) {
							unset( $defaults['faqs'] );

							return $defaults;
						},
						10,
						1
					);
				}

				if ( $check_coming_soon_details == 'no' ) {
					// Remove add_filter group
					add_filter(
						'learn-press/course-tabs',
						function ( $defaults ) {
							unset( $defaults['overview'] );
							unset( $defaults['curriculum'] );

							return $defaults;
						},
						10,
						1
					);
				}
			}
		}

		/**
		 * Assets.
		 */
		public function frontend_assets() {
			$ver = $this->version;
			$min = '.min';
			$rtl = is_rtl() ? '-rtl' : '';
			if ( LP_Debug::is_debug() ) {
				$ver = time();
				$min = '';
			}

			wp_register_style(
				'lp-coming-soon-course',
				$this->get_plugin_url( "assets/dist/css/coming-soon-course{$rtl}{$min}.css" ),
				[],
				$ver
			);
			wp_register_script(
				'lp-jquery-mb-coming-soon',
				$this->get_plugin_url( 'assets/libs/jquery.mb-coming-soon.min.js' ),
				[ 'jquery' ],
				$this->version,
				[ 'strategy' => 'defer' ]
			);
			wp_register_script(
				'lp-coming-soon-course',
				$this->get_plugin_url( "assets/dist/js/lp-coming-soon{$min}.js" ),
				[],
				$ver,
				[ 'strategy' => 'async' ]
			);

			$translation_array = apply_filters(
				'learn-press/coming-soon-course/translation-arrays', array(
					'days'    => esc_html__( 'days', 'learnpress-coming-soon-courses' ),
					'hours'   => esc_html__( 'hours', 'learnpress-coming-soon-courses' ),
					'minutes' => esc_html__( 'minutes', 'learnpress-coming-soon-courses' ),
					'seconds' => esc_html__( 'seconds', 'learnpress-coming-soon-courses' ),
				)
			);
			

			if ( LP_PAGE_SINGLE_COURSE === LP_Page_Controller::page_current() ) {
				$course_id = get_the_ID();
				if ( ! $course_id ) {
					return;
				}

				$course = CourseModel::find( $course_id, true );
				if ( ! $course ) {
					return;
				}

				if ( ! $this->is_coming_soon( $course_id ) ) {
					return;
				}

				wp_enqueue_style( 'lp-coming-soon-course' );
				wp_enqueue_script( 'lp-jquery-mb-coming-soon' );
				wp_enqueue_script( 'lp-coming-soon-course' );
				wp_localize_script( 'lp-coming-soon-course', 'lp_coming_soon_translation', $translation_array );

			} elseif ( LP_PAGE_COURSES === LP_Page_Controller::page_current() ) {
				wp_enqueue_style( 'lp-coming-soon-course' );
				wp_enqueue_script( 'lp-jquery-mb-coming-soon' );
				wp_enqueue_script( 'lp-coming-soon-course' );
				wp_localize_script(
					'lp-coming-soon-course',
					'lp_coming_soon_translation',
					$translation_array
				);
			}
		}

		public function admin_assets() {}

		/**
		 * @param $located
		 * @param $template_name
		 * @param $args
		 * @param $template_path
		 * @param $default_path
		 *
		 * @return string
		 */
		/*public function change_default_template( $located, $template_name, $args, $template_path, $default_path ) {
			remove_filter( 'learn_press_get_template', array( $this, 'change_default_template' ), 100, 5 );
			if ( $template_name == 'content-single-course.php' ) {
				$course = learn_press_get_course();
				if ( $course ) {
					$course_id = $course->get_id();
					if ( $this->is_coming_soon( $course_id ) ) {
						$located = learn_press_coming_soon_course_locate_template( $template_name );
					}
				}
			}
			add_filter( 'learn_press_get_template', array( $this, 'change_default_template' ), 100, 5 );

			return $located;
		}*/

		/**
		 * @param $template
		 * @param $slug
		 * @param $name
		 *
		 * @return string
		 */
		/*public function change_content_course_template( $template, $slug, $name ) {
			if ( $slug == 'content' && $name == 'course' ) {
				$course    = learn_press_get_course();
				$course_id = $course->get_id();
				if ( $this->is_coming_soon( $course_id ) ) {
					remove_filter(
						'learn_press_get_template_part',
						array(
							$this,
							'change_content_course_template',
						),
						100,
						3
					);
					$template = learn_press_coming_soon_course_locate_template( 'content-course.php' );
					add_filter(
						'learn_press_get_template_part',
						array(
							$this,
							'change_content_course_template',
						),
						100,
						3
					);
				}
			}

			return $template;
		}*/

		/**
		 * Display coming soon message
		 */
		public function coming_soon_message() {
			$course_id = get_the_ID();
			if ( ! $course_id ) {
				return;
			}

			$course = CourseModel::find( $course_id, true );
			if ( ! $course ) {
				return;
			}

			$message = $course->get_meta_value_by_key( '_lp_coming_soon_msg', '' );
			if ( $this->is_coming_soon( $course_id ) && '' !== $message ) {
				$message = do_shortcode( $message );
				LP_Addon_Coming_Soon_Courses_Preload::$addon->get_template(
					'single-course/message.php',
					array( 'message' => $message )
				);
			}
		}

		/**
		 * Get message of coming soon course
		 *
		 * @param CourseModel $course
		 *
		 * @return string
		 * @since 4.0.8
		 * @version 1.0.0
		 */
		public function get_message( CourseModel $course ): string {
			$message = $course->get_meta_value_by_key( self::KEY_META_MESSAGE, '' );
			if ( '' !== $message ) {
				return do_shortcode( $message );
			}

			return '';
		}

		/**
		 * Get message of coming soon course
		 *
		 * @param CourseModel $course
		 *
		 * @return string
		 * @since 4.0.8
		 * @version 1.0.0
		 */
		public function is_show_date_text( CourseModel $course ): string {
			$value = $course->get_meta_value_by_key( self::KEY_META_SHOW_TEXT, 'no' );

			return 'yes' === $value;
		}

		/**
		 * Display coming soon countdown
		 * @throws Exception
		 */
		public function coming_soon_countdown() {
			$course_id = get_the_ID();
			if ( ! $course_id ) {
				return;
			}

			$course = CourseModel::find( $course_id, true );
			if ( ! $course ) {
				return;
			}

			if ( ! $this->is_enable_coming_soon( $course_id ) ) {
				return;
			}

			if ( ! $this->is_coming_soon( $course_id ) ) {
				return;
			}

			if ( ! $this->is_show_coming_soon_countdown( $course ) ) {
				return;
			}

			$end_time         = $this->get_coming_soon_end_time( $course );
			$showtext         = $course->get_meta_value_by_key( '_lp_coming_soon_showtext', 'no' );
			$current_time     = current_time( 'timestamp' );
			$timestamp_remain = $end_time - $current_time;

			LP_Addon_Coming_Soon_Courses_Preload::$addon->get_template(
				'single-course/countdown.php',
				array(
					'showtext'         => $showtext,
					'timestamp_remain' => $timestamp_remain,
				)
			);
		}

		/**
		 * Check all options and return TRUE if a course has 'Coming Soon'
		 *
		 * @param int $course_id
		 *
		 * @return mixed
		 * @throws Exception
		 */
		public function is_coming_soon( int $course_id = 0 ) {
			$key         = 'coming_soon_course_' . $course_id;
			$cache_first = LP_Cache::cache_load_first( 'get', $key );
			if ( false !== $cache_first ) {
				$courseModel = $cache_first;
			} else {
				$courseModel = CourseModel::find( $course_id, true );

				// Set cache first
				$cache_value = $courseModel instanceof CourseModel ? $courseModel : null;
				LP_Cache::cache_load_first( 'set', $key, $cache_value );
			}

			if ( ! $courseModel ) {
				return false;
			}

			if ( empty( $this->_coming_soon_courses[ $course_id ] ) ) {
				$this->_coming_soon_courses[ $course_id ] = false;
				if ( $this->is_enable_coming_soon( $course_id ) ) {
					$time_remaining = $this->get_time_remaining( $courseModel );

					if ( $time_remaining > 0 ) {
						$this->_coming_soon_courses[ $course_id ] = true;
					}
				}
			}

			return $this->_coming_soon_courses[ $course_id ];
		}

		/**
		 * Check coming soon course is available
		 *
		 * @param CourseModel $course
		 *
		 * @return bool
		 * @throws Exception
		 */
		public function is_coming_soon_active( CourseModel $course ): bool {
			if ( $this->is_enable_coming_soon( $course->get_id() ) ) {
				$time_remaining = $this->get_time_remaining( $course );

				if ( $time_remaining > 0 ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Return TRUE if 'Coming Soon' is enabled
		 *
		 * @param int $course_id
		 *
		 * @return bool
		 */
		public function is_enable_coming_soon( int $course_id = 0 ): bool {
			$course = CourseModel::find( $course_id, true );
			if ( ! $course ) {
				return false;
			}

			$value = $course->get_meta_value_by_key( self::KEY_META_ENABLE, 'no' );

			return 'yes' === $value;
		}

		/**
		 * Get end time config
		 *
		 * @param CourseModel $course
		 *
		 * @return string
		 * @since 4.0.8
		 * @version 1.0.0
		 */
		public function get_end_time_config( CourseModel $course ): string {
			return $course->get_meta_value_by_key( self::KEY_META_END_TIME, '' );
		}

		/**
		 * Get timestamp remaining
		 *
		 * @param CourseModel $course
		 *
		 * @since 4.0.8
		 * @version 1.0.0
		 * @return int
		 * @throws Exception
		 */
		public function get_time_remaining( CourseModel $course ): int {
			$end_time_config_str = $this->get_end_time_config( $course );
			if ( empty( $end_time_config_str ) ) {
				return 0;
			}

			$end_time_local = new DateTime( $end_time_config_str, wp_timezone() );
			$date_now       = new DateTime( 'now', wp_timezone() );

			return ( $end_time_local->getTimestamp() - $date_now->getTimestamp() );
		}

		public function get_diff_date( CourseModel $course ) {
			$end_time_config_str = $this->get_end_time_config( $course );
			if ( empty( $end_time_config_str ) ) {
				return 0;
			}

			$end_time_local = new DateTime( $end_time_config_str, wp_timezone() );
			$date_now       = new DateTime( 'now', wp_timezone() );

			$diff = LP_Datetime::format_human_time_diff( $date_now, $end_time_local );

			return $diff;
		}

		/**
		 * Return format time should show
		 *
		 * @param int $seconds
		 *
		 * @return array
		 */
		public function get_format_time_should_show( int $seconds ): array {
			$days     = floor( $seconds / 86400 );
			$seconds -= $days * 86400;
			$hours    = floor( $seconds / 3600 );
			$seconds -= $hours * 3600;
			$minutes  = floor( $seconds / 60 );
			$seconds -= $minutes * 60;

			$format = [];
			if ( $days > 0 ) {
				$format['day'] = sprintf( '%02d', $days );
			}

			$format['hour']   = sprintf( '%02d', $hours );
			$format['minute'] = sprintf( '%02d', $minutes );
			$format['second'] = sprintf( '%02d', $seconds );

			return $format;
		}

		/**
		 * Return expiration time of 'Coming Soon'
		 *
		 * @param CourseModel $course
		 * @param string $format
		 *
		 * @return int|string
		 */
		public function get_coming_soon_end_time( CourseModel $course, string $format = 'timestamp' ) {
			$end_time = 0;

			if ( $this->is_enable_coming_soon( $course->get_id() ) ) {
				$end_time           = $course->get_meta_value_by_key( self::KEY_META_END_TIME, '' );
				$current_time       = time();
				$end_time_timestamp = strtotime( $end_time, $current_time );
				if ( $format == 'timestamp' ) {
					$end_time = $end_time_timestamp;
				} elseif ( $format ) {
					$end_time = gmdate( $format, $end_time_timestamp );
				}
			}

			return $end_time;
		}

		/**
		 * Return true if a course is enabled countdown
		 *
		 * @param CourseModel $courseModel
		 *
		 * @return bool
		 */
		public function is_show_coming_soon_countdown( CourseModel $courseModel ): bool {
			$value = $courseModel->get_meta_value_by_key( self::KEY_META_COUNTDOWN, 'no' );

			return 'yes' === $value;
		}

		/**
		 * Return true if a course is enabled show details
		 *
		 * @param CourseModel $course
		 *
		 * @return bool
		 */
		public function is_show_course_details( CourseModel $course ): bool {
			$value = $course->get_meta_value_by_key( self::KEY_META_SHOW_DETAILS, 'no' );

			return 'yes' === $value;
		}

		/**
		 * Return true if a course is enabled show metadata
		 *
		 * @param CourseModel $course
		 *
		 * @return bool
		 */
		public function is_show_course_metadata( CourseModel $course ): bool {
			$value = $course->get_meta_value_by_key( self::KEY_META_SHOW_METADATA, 'no' );

			return 'yes' === $value;
		}

		/**
		 * Set course price html to empty if not enable "Show Meta"
		 *
		 * @param $price
		 *
		 * @return string
		 */
		public function set_course_price_html_empty( $price ): string {
			return '';
		}

		public static function get_string_plural_time( float $time, string $duration_type = '' ): string {
			switch ( strtolower( $duration_type ) ) {
				case 'second':
					$duration_str = _n( 'Second', 'Seconds', $time, 'learnpress-coming-soon-courses' );
					break;
				case 'minute':
					$duration_str = _n( 'Minute', 'Minutes', $time, 'learnpress-coming-soon-courses' );
					break;
				case 'hour':
					$duration_str = _n( 'Hour', 'Hours', $time, 'learnpress-coming-soon-courses' );
					break;
				case 'day':
					$duration_str = _n( 'Day', 'Days', $time, 'learnpress-coming-soon-courses' );
					break;
				case 'week':
					$duration_str = _n( 'Week', 'Weeks', $time, 'learnpress-coming-soon-courses' );
					break;
				default:
					$duration_str = $duration_type;
			}

			return $duration_str;
		}
	}
}
