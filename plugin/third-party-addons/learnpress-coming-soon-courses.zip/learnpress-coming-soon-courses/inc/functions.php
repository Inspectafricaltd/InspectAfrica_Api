<?php
/**
 * LearnPress Coming Soon Courses Functions
 *
 * Define common functions for both front-end and back-end
 *
 * @author   ThimPress
 * @package  LearnPress-Coming-Soon-Course/Functions
 * @version  3.0.0
 */

// Prevent loading this file directly
use LearnPress\Models\CourseModel;

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'learn_press_is_coming_soon' ) ) {
	/**
	 * @param int $course_id
	 *
	 * @return mixed
	 */
	function learn_press_is_coming_soon( int $course_id = 0 ) {
		return LP_Addon_Coming_Soon_Courses_Preload::$addon->is_coming_soon( $course_id );
	}
}

if ( ! function_exists( 'learn_press_is_show_coming_soon_countdown' ) ) {
	/**
	 * @param $course_id
	 *
	 * @return bool
	 */
	function learn_press_is_show_coming_soon_countdown( int $course_id = 0 ): bool {
		$course = CourseModel::find( $course_id, true );
		if ( ! $course ) {
			return false;
		}

		return LP_Addon_Coming_Soon_Courses_Preload::$addon->is_show_coming_soon_countdown( $course );
	}
}

if ( ! function_exists( 'learn_press_get_coming_soon_end_time' ) ) {
	/**
	 * @param int $course_id
	 * @param string $format
	 *
	 * @return int|string
	 */
	function learn_press_get_coming_soon_end_time( int $course_id = 0, string $format = 'timestamp' ) {
		$course = CourseModel::find( $course_id, true );
		if ( ! $course ) {
			return false;
		}

		return LP_Addon_Coming_Soon_Courses_Preload::$addon->get_coming_soon_end_time( $course, $format );
	}
}
