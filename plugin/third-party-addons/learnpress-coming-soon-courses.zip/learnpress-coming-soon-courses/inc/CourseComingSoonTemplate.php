<?php
/**
 * LearnPress Coming Soon Hook Template
 *
 * @since 4.0.8
 * @version 1.0.0
 */

namespace LearnPress\ComingSoon;

use Exception;
use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LearnPress\Models\CourseModel;
use LP_Addon_Coming_Soon_Courses;
use LP_Addon_Coming_Soon_Courses_Preload;
use LP_Datetime;
use LearnPress\Models\UserModel;
use LP_Debug;
use Throwable;

class CourseComingSoonTemplate {
	use Singleton;

	/**
	 * @var LP_Addon_Coming_Soon_Courses
	 */
	public $addon;

	public function init() {
		$this->addon = LP_Addon_Coming_Soon_Courses_Preload::$addon;
		$this->hooks();
	}

	/**
	 * Hooks
	 */
	public function hooks() {
		add_action(
			'learn-press/single-course/offline/section-right/info-meta',
			[
				$this,
				'coming_soon_course_offline_message',
			],
			10,
			3
		);
		add_action(
			'learn-press/single-course/offline/section-right/info-meta/buttons',
			[
				$this,
				'hide_buttons_course_offline',
			],
			10,
			3
		);
		add_action( 'learn-press/course/html-description', [ $this, 'coming_soon_course_description' ], 10, 2 );
		add_action( 'learn-press/course/html-faqs', [ $this, 'coming_soon_course_faqs' ], 10, 2 );
		add_action( 'learn-press/single-course/offline/info-meta', [ $this, 'coming_soon_course_meta' ], 10, 3 );
		add_filter( 'learn-press/single-course/offline/section-instructor', [ $this, 'coming_soon_instructor' ], 10, 3 );
		add_filter( 'learn-press/single-course/modern/section-right/buttons', [ $this, 'display_coming_soon_course' ], 10, 3 );
		add_filter( 'learn-press/course/html-curriculum', [ $this, 'hide_curriculum' ], 10, 4 );
		add_filter( 'learn-press/single-course/modern/section-right/info-meta', [ $this, 'hide_info_meta' ], 10, 3 );
		add_filter( 'learn-press/single-course/modern/section-instructor', [ $this, 'hide_info_instructor' ], 10, 3 );
		add_filter( 'learn-press/course/html-price', [ $this, 'hide_price' ], 10, 2 );
		add_filter( 'learn-press/course-material/can-show', [ $this, 'hide_material' ], 10, 3 );
	}

	/**
	 * @param $section
	 * @param $courseModel
	 * @param $userModel
	 * @param $itemModelCurrent
	 *
	 * @return array
	 * @throws Exception
	 */
	public function hide_curriculum( $section, $courseModel, $userModel, $itemModelCurrent ) {
		if ( ! $this->addon->is_coming_soon_active( $courseModel ) ) {
			return $section;
		}

		return [];
	}

	/**
	 * @param array $section
	 * @param CourseModel $courseModel
	 * @param $userModel
	 *
	 * @return array
	 * @throws Exception
	 */
	public function hide_info_meta( array $section, CourseModel $courseModel, $userModel ) {
		if ( ! $this->addon->is_coming_soon_active( $courseModel )
			|| $this->addon->is_show_course_metadata( $courseModel ) ) {
			return $section;
		}

		return [];
	}

	/**
	 * @param array $section
	 * @param CourseModel $courseModel
	 * @param $userModel
	 *
	 * @return array
	 * @throws Exception
	 */
	public function hide_info_instructor( array $section, CourseModel $courseModel, $userModel ) {
		if ( ! $this->addon->is_coming_soon_active( $courseModel )
			|| $this->addon->is_show_course_metadata( $courseModel ) ) {
			return $section;
		}

		return [];
	}

	/**
	 * @param string $price_html
	 * @param CourseModel $courseModel
	 *
	 * @return string
	 * @throws Exception
	 */
	public function hide_price( $price_html, $courseModel ) {
		if ( $this->addon->is_coming_soon_active( $courseModel )
			&& ! $this->addon->is_show_course_metadata( $courseModel ) ) {
			return '';
		}

		return $price_html;
	}

	/**
	 * @param bool $can_show
	 * @param CourseModel $courseModel
	 * @param UserModel|false $userModel
	 *
	 * @return bool
	 * @throws Exception
	 */
	public function hide_material( $can_show, $courseModel, $userModel ) {
		if ( ! $this->addon->is_coming_soon_active( $courseModel ) ) {
			return $can_show;
		}

		return false;
	}

	/**
	 * Coming soon course message
	 *
	 * @param array $section
	 * @param CourseModel $courseModel
	 * @param UserModel|false $userModel
	 *
	 * @return array
	 */
	public function coming_soon_course_offline_message( array $section, CourseModel $courseModel, $userModel ) {
		$html = $this->html_message_countdown( $courseModel, $userModel );
		if ( ! empty( $html ) ) {
			$section['meta']   = '';
			$section['button'] = '';
			$section           = Template::insert_value_to_position_array( $section, 'before', 'wrapper_end', 'coming-soon', $html );
		}

		return $section;
	}

	/**
	 * Hook coming soon course section left
	 *
	 * @param array $section
	 * @param CourseModel $course
	 *
	 * @return array
	 * @throws \Exception
	 */
	public function coming_soon_course_description( array $section, CourseModel $course ) {
		if ( ! $this->addon->is_coming_soon_active( $course ) ) {
			return $section;
		}

		if ( ! $this->addon->is_show_course_details( $course ) ) {
			return [];
		}

		return $section;
	}

	/**
	 * Hook coming soon course section left
	 *
	 * @param array $section
	 * @param CourseModel $course
	 *
	 * @return array
	 * @throws \Exception
	 */
	public function coming_soon_course_faqs( array $section, CourseModel $course ) {
		if ( ! $this->addon->is_coming_soon_active( $course ) ) {
			return $section;
		}

		if ( ! $this->addon->is_show_course_details( $course ) ) {
			return [];
		}

		return $section;
	}

	/**
	 * Hook course meta
	 *
	 * @param array $section
	 * @param CourseModel $course
	 * @param UserModel|false $user
	 *
	 * @return array
	 * @throws \Exception
	 */
	public function coming_soon_course_meta( array $section, CourseModel $course, $user ) {
		if ( ! $this->addon->is_coming_soon_active( $course ) ) {
			return $section;
		}

		if ( ! $this->addon->is_show_course_metadata( $course ) ) {
			return [];
		}

		return $section;
	}

	/**
	 * Hook instructor section
	 *
	 * @param array $section
	 * @param CourseModel $course
	 * @param UserModel|false $user
	 *
	 * @return array
	 * @throws \Exception
	 */
	public function coming_soon_instructor( array $section, CourseModel $course, $user ) {
		if ( ! $this->addon->is_coming_soon_active( $course ) ) {
			return $section;
		}

		if ( ! $this->addon->is_show_course_metadata( $course ) ) {
			return [];
		}

		return $section;
	}

	/**
	 * Hook instructor section
	 *
	 * @param array $section
	 * @param CourseModel $courseModel
	 * @param UserModel|false $userModel
	 *
	 * @return array
	 * @throws Exception
	 */
	public function display_coming_soon_course( array $section, CourseModel $courseModel, $userModel ) {
		$html = $this->html_message_countdown( $courseModel, $userModel );
		if ( ! empty( $html ) ) {
			$section                = [];
			$section['coming-soon'] = $html;
		}

		return $section;
	}

	/**
	 * Hide buttons
	 *
	 * @param array $section
	 * @param CourseModel $course
	 * @param $user
	 *
	 * @return array
	 */
	public function hide_buttons_course_offline( array $section, CourseModel $course, $user ) {
		if ( ! $this->addon->is_coming_soon( $course->get_id() ) ) {
			return $section;
		}

		$section = [];

		return $section;
	}

	/**
	 * @param CourseModel $courseModel
	 * @param UserModel|false $userModel
	 * @param bool $on_single If display on single course, set true. To handle js when expired.
	 *
	 * @return string
	 * @since 4.0.7
	 * @version 1.0.0
	 */
	public function html_message_countdown( CourseModel $courseModel, $userModel, bool $on_single = true ) {
		$html = '';

		try {
			if ( ! $this->addon->is_coming_soon_active( $courseModel ) ) {
				return $html;
			}

			$section = [
				'wrapper'     => sprintf( '<div class="course-coming-soon-tmpl %s">', $on_single ? 'is-single' : '' ),
				'message'     => $this->html_message( $courseModel ),
				'countdown'   => $this->addon->is_show_coming_soon_countdown( $courseModel ) ? $this->html_countdown( $courseModel ) : '',
				'wrapper_end' => '</div>',
			];

			$html = Template::combine_components( $section );
		} catch ( Throwable $e ) {
			LP_Debug::error_log( $e );
		}

		return $html;
	}

	/**
	 * HTML message of coming soon course
	 *
	 * @param CourseModel $course
	 *
	 * @return string
	 */
	public function html_message( CourseModel $course ): string {
		$message = $this->addon->get_message( $course );
		if ( empty( $message ) ) {
			return '';
		}

		$html = sprintf(
			'<span class="course-coming-soon-message">%s</span>',
			$message
		);

		return apply_filters( 'learn-press/coming-soon-course-message', $html, $course );
	}

	/**
	 * HTML message of coming soon course
	 *
	 * @param CourseModel $course
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function html_countdown( CourseModel $course ): string {
		if ( ! $this->addon->is_show_coming_soon_countdown( $course ) ) {
			return '';
		}

		if ( ! $this->addon->is_coming_soon_active( $course ) ) {
			return '';
		}

		wp_enqueue_style( 'lp-coming-soon-course' );
		wp_enqueue_script( 'lp-jquery-mb-coming-soon' );
		wp_enqueue_script( 'lp-coming-soon-course' );

		$html = '';

		$timestamp_remain = $this->addon->get_time_remaining( $course );
		$date_format      = $this->addon->get_format_time_should_show( $timestamp_remain );

		// Format date
		$html_content = '';
		if ( isset( $date_format['days'] ) && $date_format['days'] > 99 ) {
			$end_time_config_str = $this->addon->get_end_time_config( $course );
			$end_time_config     = new LP_Datetime( $end_time_config_str );
			$html_content        = $end_time_config->format( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
		} else {

			foreach ( $date_format as $key => $value ) {
				if ( $this->addon->is_show_date_text( $course ) ) {
					$label = $this->addon->get_string_plural_time( $value, $key );
				}

				$html_content .= sprintf(
					'<div><span class="item-time" data-%s>%s</span> %s</div>',
					$key,
					$value,
					! empty( $label ) ? $label : ( $key === 'second' ? '' : '<span class="separator">:</span>' )
				);
			}
		}

		$section = [
			'wrapper'     => sprintf( '<div class="course-count-down style-short" data-time-remaining="%s">', $timestamp_remain ),
			'countdown'   => $html_content,
			'wrapper_end' => '</div>',
		];

		$html .= Template::combine_components( $section );

		return $html;
	}

	/**
	 * HTML message of coming soon course
	 *
	 * @param CourseModel $course
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function html_countdown_jquery( CourseModel $course ): string {
		if ( ! $this->addon->is_show_coming_soon_countdown( $course ) ) {
			return '';
		}

		if ( ! $this->addon->is_coming_soon_active( $course ) ) {
			return '';
		}

		wp_enqueue_style( 'lp-coming-soon-course' );
		wp_enqueue_script( 'lp-jquery-mb-coming-soon' );
		wp_enqueue_script( 'lp-coming-soon-course' );

		$showtext         = $course->get_meta_value_by_key( '_lp_coming_soon_showtext', 'no' );
		$timestamp_remain = $this->addon->get_time_remaining( $course );

		$html_countdown =
			sprintf(
				'<div class="countdown learnpress-course-coming-soon course-content_coming_soon"
				data-showtext="%s"
				data-timestamp-remain="%s"
				data-speed="500"></div>',
				$showtext ?? 'no',
				$timestamp_remain
			);

		return $html_countdown;
	}
}
