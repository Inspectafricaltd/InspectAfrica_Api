<?php
return apply_filters(
	'learn-press/gateway-payment/qpay/settings',
	array(
		array( 'type' => 'title' ),
		array(
			'title'   => __( 'Enable', 'learnpress-qpay' ),
			'id'      => '[enable]',
			'default' => 'no',
			'type'    => 'yes-no',
		),
		/*array(
			'type'       => 'textarea',
			'title'      => __( 'Description', 'learnpress-qpay' ),
			'default'    => __( 'Pay with QPay', 'learnpress-qpay' ),
			'id'         => '[description]',
			'editor'     => array(
				'textarea_rows' => 5,
			),
			// 'css'        => 'height: 100px;',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),*/
		array(
			'title'      => esc_html__( 'Enable test mode', 'learnpress-qpay' ),
			'id'         => '[test_mode]',
			'default'    => 'no',
			'type'       => 'yes-no',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => __( 'User', 'learnpress-qpay' ),
			'id'         => '[user]',
			'type'       => 'text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => __( 'Password', 'learnpress-qpay' ),
			'id'         => '[password]',
			'type'       => 'password',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => __( 'Invoice code', 'learnpress-qpay' ),
			'id'         => '[invoice_code]',
			'type'       => 'text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'title'      => __( 'Purchase message', 'learnpress-qpay' ),
			'id'         => '[purchase_text]',
			'type'       => 'textarea',
			//'desc'       => __( 'Message to show after purchase, above QR code.', 'learnpress-qpay' ),
			'desc_tip'   => __( 'Message to show after purchase, above QR Code.', 'learnpress-qpay' ),
			'default'    => __( 'Please scan the QR code to pay.', 'learnpress-qpay' ),
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		/*array(
			'title'      => __( 'Process text', 'learnpress-qpay' ),
			'id'         => '[process_text]',
			'type'       => 'textarea',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),*/
		array( 'type' => 'sectionend' ),
	)
);
