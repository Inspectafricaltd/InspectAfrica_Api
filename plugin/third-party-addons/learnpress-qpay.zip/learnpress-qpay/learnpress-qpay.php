<?php
/**
 * Plugin Name: LearnPress - QPay
 * Plugin URI: https://thimpress.com/product/qpay-add-on-for-learnpress/
 * Description: QPay payment gateway for LearnPress.
 * Author: ThimPress
 * Version: 4.0.1
 * Author URI: http://thimpress.com
 * Tags: learnpress, lms, add-on, qpay
 * Text Domain: learnpress-qpay
 * Domain Path: /languages/
 * Require_LP_Version: 4.2.9.4
 *
 * @package learnpress-qpay
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

const LP_ADDON_QPAY_PAYMENT_FILE = __FILE__;

/**
 * Class LP_Addon_QPay_Payment_Preload
 */
class LP_Addon_QPay_Payment_Preload {
	public static $addon_info = [];

	/**
	 * LP_Addon_QPay_Payment_Preload constructor.
	 */
	public function __construct() {
		$can_load = true;
		define( 'LP_ADDON_QPAY_PAYMENT_BASENAME', plugin_basename( __FILE__ ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_QPAY_PAYMENT_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_QPAY_PAYMENT_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_QPAY_PAYMENT_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			$can_load = false;
		} else {
			// Check version LP
			if ( version_compare( LP_ADDON_QPAY_PAYMENT_REQUIRE_VER, get_option( 'learnpress_version', '3.0.0' ), '>' ) ) {
				$can_load = false;
			}
		}

		if ( ! $can_load ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );
			deactivate_plugins( LP_ADDON_QPAY_PAYMENT_BASENAME );

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			return;
		}

		add_filter(
			'plugin_action_links_' . LP_ADDON_QPAY_PAYMENT_BASENAME,
			array(
				$this,
				'plugin_links',
			)
		);

		add_action( 'learn-press/ready', array( $this, 'load' ) );
	}

	/**
	 * Load addon
	 */
	public function load() {
		LP_Addon::load( 'LP_Addon_QPay_Payment', 'inc/load.php', __FILE__ );
		remove_action( 'admin_notices', array( $this, 'admin_notices' ) );
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p><?php echo( 'Please active <strong>LearnPress version ' . LP_ADDON_QPAY_PAYMENT_REQUIRE_VER . ' or later</strong> before active <strong>' . self::$addon_info['Name'] . '</strong>' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Plugin links.
	 *
	 * @return array
	 */
	public static function plugin_links( $links ) {
		$links[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'admin.php?page=learn-press-settings&tab=payments&section=qpay' ) ),
			esc_html__( 'Settings', 'learnpress-qpay' )
		);

		return $links;
	}
}

new LP_Addon_QPay_Payment_Preload();
