<?php
/**
 * Template for displaying QPay payment error message.
 *
 * This template can be overrqden by copying it to yourtheme/learnpress/addons/qpay-payment/payment-error.php.
 *
 * @author   QPay
 * @package  LearnPress/QPay/Templates
 * @version  1.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>

<?php $settings = LP()->settings; ?>

<div class="learn-press-message error ">
	<div><?php echo __( 'Transaction failed', 'learnpress-qpay' ); ?></div>
</div>
