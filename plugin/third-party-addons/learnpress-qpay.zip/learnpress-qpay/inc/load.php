<?php
/**
 * Plugin load class.
 *
 * @author   QPay
 * @package  LearnPress/QPay/Classes
 * @version  1.0.0
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_QPay_Payment' ) ) {
	/**
	 * Class LP_Addon_QPay_Payment
	 */
	class LP_Addon_QPay_Payment extends LP_Addon {
		public $version         = LP_ADDON_QPAY_PAYMENT_VER;
		public $require_version = LP_ADDON_QPAY_PAYMENT_REQUIRE_VER;
		public $text_domain     = 'learnpress-qpay';

		/**
		 * LP_Addon_QPay_Payment constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define Learnpress QPay payment constants.
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_QPAY_PAYMENT_PATH', dirname( LP_ADDON_QPAY_PAYMENT_FILE ) );
			define( 'LP_ADDON_QPAY_PAYMENT_INC', LP_ADDON_QPAY_PAYMENT_PATH . '/inc/' );
			define( 'LP_ADDON_QPAY_PAYMENT_URL', plugin_dir_url( LP_ADDON_QPAY_PAYMENT_FILE ) );
			define( 'LP_ADDON_QPAY_PAYMENT_TEMPLATE', LP_ADDON_QPAY_PAYMENT_PATH . '/templates/' );
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 */
		protected function _includes() {
			include_once LP_ADDON_QPAY_PAYMENT_INC . 'class-lp-gateway-qpay.php';
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			// add payment gateway class
			add_filter( 'learn-press/payment-methods', array( $this, 'add_payment' ) );
			if ( ! is_admin() ) {
				$this->listen_callback_from_qpay();
			}
		}

		/**
		 * Add QPay to payment system.
		 *
		 * @param $methods
		 *
		 * @return mixed
		 */
		public function add_payment( $methods ) {
			$methods['qpay'] = new LP_Gateway_QPay();

			return $methods;
		}

		public function listen_callback_from_qpay() {
			try {
				if ( ! isset( $_GET['qpay'] ) ) {
					return;
				}
				if ( ! isset( $_GET['lp_order_id'] ) ) {
					return;
				}
				$order_id     = sanitize_text_field( $_GET['lp_order_id'] );
				$qpay_gateway = LP_Gateway_QPay::instance();
				$qpay_gateway->web_hook_process_qpay( (int) $order_id );
			} catch ( Throwable $e ) {
				error_log( $e->getMessage() );
			}
		}
	}
}
