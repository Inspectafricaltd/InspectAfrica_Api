<?php
/**
 * QPay payment gateway class.
 *
 * @author   QPay
 * @package  LearnPress/QPay/Classes
 * @version  1.0.0
 */

// Prevent loading this file directly
use LearnPress\Helpers\Template;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Gateway_QPay' ) ) {
	/**
	 * Class LP_Gateway_QPay
	 */
	class LP_Gateway_QPay extends LP_Gateway_Abstract {
		/**
		 * @var string
		 */
		protected $payment_endpoint;

		/**
		 * @var string
		 */
		protected $auth_endpoint;

		/**
		 * @var string
		 */
		protected $access_endpoint;

		/**
		 * @var string
		 */
		protected $verify_endpoint;

		/**
		 * @var array|bool|mixed|null
		 */
		private $user = null;

		/**
		 * @var array|bool|mixed|null
		 */
		private $password = null;

		/**
		 * @var array|bool|mixed|null
		 */
		private $invoice_code = null;

		/**
		 * @var null
		 */
		protected $posted           = [];
		protected static $_instance = null;
		/**
		 * @var string|null
		 */
		public $purchase_text = '';
		/**
		 * @var string|null
		 */
		public $process_text = '';
		/**
		 * @var bool
		 */
		public $test_mode = 'no';
		/**
		 * @var string
		 */
		public $id = 'qpay';
		/**
		 * LP_Gateway_QPay constructor.
		 */
		public function __construct() {
			parent::__construct();

			$this->method_title       = __( 'QPay', 'learnpress-qpay' );
			$this->method_description = __( 'Make a payment with QPay.', 'learnpress-qpay' );
			$this->icon               = '';
			$this->title              = $this->method_title;
			$this->description        = $this->settings->get( 'description' );

			if ( $this->is_enabled() ) {
				$this->user          = $this->settings->get( 'user' );
				$this->password      = $this->settings->get( 'password' );
				$this->invoice_code  = $this->settings->get( 'invoice_code' );
				$this->purchase_text = $this->settings->get( 'purchase_text' );
				$this->process_text  = $this->settings->get( 'process_text' );
				$this->test_mode     = $this->settings->get( 'test_mode' );
			}

			$url_qpay = 'https://merchant.qpay.mn';
			if ( $this->test_mode === 'yes' ) {
				$url_qpay = 'https://merchant-sandbox.qpay.mn';
			}
			$this->payment_endpoint = $url_qpay . '/v2/invoice';
			$this->verify_endpoint  = $url_qpay . '/v2/payment/check';
			$this->auth_endpoint    = $url_qpay . '/v2/auth/token';
			$this->access_endpoint  = $url_qpay . '/v2/auth/refresh';

			add_action( 'learn-press/before-checkout-order-review', array( $this, 'error_message' ) );
			add_action( 'learn-press/order/after-received-order-message', array( $this, 'display_qrcode_on_order_received' ), 10, 1 );
		}

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
		/**
		 * Admin payment settings.
		 *
		 * @return array
		 */
		public function get_settings() {
			return include_once LP_ADDON_QPAY_PAYMENT_PATH . '/config/settings.php';
		}

		/**
		 * Error message
		 */
		public function error_message() {
			if ( isset( $_SESSION['qpay_payment_error'] ) && intval( $_SESSION['qpay_payment_error'] ) === 1 ) {
				$_SESSION['qpay_payment_error'] = 0;
				$template                       = learn_press_locate_template( 'payment-error.php', learn_press_template_path() . '/addons/qpay-payment/', LP_ADDON_QPAY_PAYMENT_TEMPLATE );
				include $template;
			}
		}

		/**
		 * @return mixed
		 */
		public function get_icon() {
			if ( empty( $this->icon ) ) {
				$this->icon = LP_ADDON_QPAY_PAYMENT_URL . 'assets/images/qpay.png';
			}

			return parent::get_icon();
		}

		/**
		 * QPay payment process.
		 *
		 * @param int $order_id
		 *
		 * @return array
		 * @throws string
		 */
		public function process_payment( $order_id ) {
			$result      = array(
				'result'   => 'fail',
				'message'  => '',
				'redirect' => '',
			);
			$order       = learn_press_get_order( $order_id );
			$gateway_url = $this->get_return_url( $order );

			if ( learn_press_get_currency() !== 'MNT' ) {
				throw new Exception( __( 'Currency is not supported, please use MNT', 'learnpress-qpay' ) );
			}

			$this->create_invoice( $order );
			$result['redirect'] = $gateway_url;
			$result['result']   = 'success';

			return $result;
		}
		/**
		 * create access token
		 *
		 * @throws Exception
		 */
		private function get_access_token() {
			if ( empty( $this->user ) || empty( $this->password ) ) {
				throw new Exception( 'Empty User or password', 'learnpress-qpay' );
			}

			$headers  = array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Basic ' . base64_encode( $this->user . ':' . $this->password ),
			);
			$response = wp_remote_post(
				$this->auth_endpoint,
				array(
					'headers' => $headers,
					'timeout' => 60,
				)
			);

			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
				throw new Exception( $message );
			}
			$body   = wp_remote_retrieve_body( $response );
			$result = json_decode( $body, true );
			if ( $response['response']['code'] !== 200 ) {
				$message = ! empty( $result['error'] ) && ! empty( $result['message'] ) ? $result['message'] : __( 'Cannot get token', 'learnpress-qpay' );
				throw new Exception( $message );
			}
			if ( empty( $result['access_token'] ) ) {
				throw new Exception( 'Empty Access token', 'learnpress-qpay' );
			}
			return $result['access_token'];
		}
		/**
		 * get headers create and get invoice
		 *
		 * @param  string $access_token
		 * @return array
		 */
		private function get_headers( string $access_token = '' ): array {
			return array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			);
		}

		/**
		 * Create QPay invoice and qrcode
		 *
		 * @param  LP_Order $order learnPress order
		 * @throws Exception
		 */
		private function create_invoice( LP_Order $order ) {
			$order_id       = $order->get_id();
			$access_token   = $this->get_access_token();
			$headers        = $this->get_headers( $access_token );
			$items          = $order->get_items();
			$first_item_key = array_key_first( $items );
			$item           = $items[ $first_item_key ];
			$amount         = $order->get_total();

			// Set params and headers
			$data     = array(
				'invoice_code'          => $this->invoice_code,
				'amount'                => $amount,
				'sender_invoice_no'     => $order->get_order_key(),
				'invoice_receiver_code' => 'web',
				'invoice_description'   => $item['name'],
				'callback_url'          => $this->get_callback_url( $order_id ),
			);
			$response = wp_remote_post(
				$this->payment_endpoint,
				array(
					'body'    => json_encode( $data ),
					'headers' => $headers,
					'timeout' => 60,
				)
			);

			// Check error
			if ( is_wp_error( $response ) ) {
				throw new Exception( $response->get_error_message() );
			}

			$body   = wp_remote_retrieve_body( $response );
			$result = json_decode( $body, true );
			if ( $response['response']['code'] !== 200 || empty( $result ) || ! empty( $result['error'] ) ) {
				$message = __( 'An error occurred while creating the transaction. ', 'woocommerce-qpay-payment' );

				if ( ! empty( $result['message'] ) ) {
					$message .= $result['message'];
				}
				throw new Exception( $message );
			}
			update_post_meta( $order_id, 'qpay_invoice_id', $result['invoice_id'] );
			update_post_meta( $order_id, 'qpay_qrtext', $result['qr_text'] );
			update_post_meta( $order_id, 'qpay_qrimage', $result['qr_image'] );
		}

		/**
		 * get callback url
		 */
		public function get_callback_url( int $order_id = 0 ): string {
			$callback_url = add_query_arg(
				array(
					'qpay'        => 1,
					'lp_order_id' => $order_id,
				),
				get_site_url()
			);
			return $callback_url;
		}

		/**
		 * Handle a web hook
		 * CallBack method
		 */
		public function web_hook_process_qpay( int $order_id ) {
			// Check id or order_id is empty
			if ( empty( $order_id ) ) {
				return;
			}
			$order = learn_press_get_order( $order_id );
			// Check order is empty
			if ( empty( $order ) ) {
				return;
			}
			// Check order status
			if ( $order->is_completed() ) {
				return;
			}
			$this->check_and_complete( $order );
		}

		/**
		 * Verify payment and complete order
		 *
		 * @param $order
		 *
		 * @return void
		 * @throws Exception
		 */
		private function check_and_complete( $order ) {
			$order_id = $order->get_id();
			$invoice  = $this->get_qpay_invoice( $order );
			if ( ! empty( $invoice ) ) {
				if ( $invoice['paid_amount'] == $order->get_total() ) {
					$payment = $invoice['rows'][0];
					// Updates order's meta data after verifying the payment.
					update_post_meta( $order_id, 'qpay_payment_status', $payment['payment_status'] );
					update_post_meta( $order_id, 'qpay_payment_id', $payment['payment_id'] );
					update_post_meta( $order_id, 'qpay_payment_date', $payment['payment_date'] );
					update_post_meta( $order_id, 'qpay_payment_fee', $payment['payment_fee'] );
					update_post_meta( $order_id, 'qpay_paid_amount', $payment['payment_amount'] );
					update_post_meta( $order_id, 'qpay_payment_currency', $payment['payment_currency'] );
					update_post_meta( $order_id, 'qpay_payment_wallet', $payment['payment_wallet'] );
					update_post_meta( $order_id, 'qpay_payment_transaction_type', $payment['transaction_type'] );
					$order->payment_complete( $payment['payment_id'] );
				} else {
					update_post_meta( $order_id, __( 'qpay_paid_amount', 'learnpress-qpay' ), $invoice['paid_amount'] );
				}
			}
		}

		/**
		 * Get qpay invoice from API
		 *
		 * @param  LP_Order $order
		 * @return array    $invoice
		 */
		private function get_qpay_invoice( LP_Order $order ): array {
			$invoice_id = get_post_meta( $order->get_id(), 'qpay_invoice_id', true );

			// Set params and headers
			$data         = array(
				'object_type' => 'INVOICE',
				'object_id'   => $invoice_id,
				'offset'      => array(
					'page_number' => 1,
					'page_limit'  => 10,
				),
			);
			$access_token = $this->get_access_token();
			$headers      = $this->get_headers( $access_token );
			$args         = array(
				'body'    => json_encode( $data ),
				'headers' => $headers,
				'timeout' => 60,
			);
			$response     = wp_remote_post( $this->verify_endpoint, $args );
			// Check error
			if ( is_wp_error( $response ) ) {
				throw new Exception( $response->get_error_message() );
			}
			$body    = wp_remote_retrieve_body( $response );
			$invoice = json_decode( $body, true );
			// Check http error
			if ( $response['response']['code'] !== 200 || ( isset( $invoice['count'] ) && $invoice['count'] <= 0 ) ) {
				throw new Exception( __( 'Cannot get invoice', 'learnpress-qpay' ) );
			}
			return $invoice;
		}

		/**
		 * Display Qr code on order receiver page
		 *
		 * @param int $order_id LP order id
		 */
		public function display_qrcode_on_order_received( $order_id ) {
			try {
				if ( ! $order_id ) {
					return;
				}

				$order = learn_press_get_order( intval( $order_id ) );
				if ( ! $order ) {
					return;
				}

				if ( $this->id !== $order->get_data( 'payment_method' ) ) {
					return;
				}

				$qr_code = get_post_meta( $order_id, 'qpay_qrimage', true );
				if ( ! $qr_code ) {
					return;
				}

				$section = [
					'wrapper'     => '<div class="qpay-qrcode">',
					'message'     => Template::print_message( $this->purchase_text ?? '', 'success', false ),
					'qr_code'     => sprintf(
						'<img src="data:image/png;base64,%s" alt="QRCode" />',
						$qr_code
					),
					'wrapper_end' => '</div>',
				];

				echo Template::combine_components( $section );
			} catch ( Throwable $e ) {
				error_log( $e->getMessage() );
			}
		}
	}
}
