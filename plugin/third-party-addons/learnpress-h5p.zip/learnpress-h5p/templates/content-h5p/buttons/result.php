<?php
defined( 'ABSPATH' ) || exit();

$course = learn_press_get_course();
$user   = learn_press_get_current_user();
if ( empty( $course ) || empty( $user ) ) {
	return;
}

$current_h5p = LP_Global::course_item();
$h5p_data = $user->get_item_data( $current_h5p->get_id(), $course->get_id() );

if ( ! $h5p_data ) {
	return;
}

$user_item_id = $h5p_data->get_user_item_id();
$score = learn_press_get_user_item_meta( $user_item_id, 'score', true );
$max_score = learn_press_get_user_item_meta( $user_item_id, 'max_score', true );

if ( ! $max_score ) {
	$h5p_id_assigned = get_post_meta( $current_h5p->get_id(), '_lp_h5p_interact', true );
	if ( $h5p_id_assigned ) {
		$h5p_plugin = H5P_Plugin_Admin::get_instance();
		$h5p_result = $h5p_plugin->get_results( $h5p_id_assigned, $user->get_id(), 0, 1, 1 );
		if ( isset( $h5p_result[0] ) ) {
			$score = $h5p_result[0]->score;
			$max_score = $h5p_result[0]->max_score;
		}
	}
}

$graduation = $h5p_data->get_graduation();

$result_grade = array(
	'user_mark' => floatval( $score ),
	'mark'      => floatval( $max_score ),
	'grade'     => $graduation,
	'result'    => $max_score ? ( $score / $max_score ) * 100 : 0,
);
?>

<div class="h5p-result <?php echo esc_attr( $result_grade['grade'] ); ?>">

	<h5><?php esc_html_e( 'Congratulation, you already completed this!', 'learnpress-h5p' ); ?></h5>

	<div class="result-grade">
		<span class="result-achieved"><?php echo $result_grade['user_mark']; ?></span>
		<span class="result-require"><?php echo $result_grade['mark']; ?></span>
		<p class="result-message"><?php echo sprintf( __( 'Your result is <strong>%s</strong>', 'learnpress-h5p' ), $result_grade['grade'] == '' ? __( 'Ungraded', 'learnpress-h5p' ) : $result_grade['grade'] ); ?> </p>
	</div>
</div>
