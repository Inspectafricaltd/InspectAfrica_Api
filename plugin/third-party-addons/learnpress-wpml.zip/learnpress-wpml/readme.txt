=== LearnPress - WPML ===
Contributors: thimpress
Donate link:
Tags: lms, wpml, translate courses, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Tested up to: 6.7
Stable tag: 4.0.5
Tested up WPML: 4.6.10
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 4.0.5 (2025-10-28) =
~ Support: addon LP Collection.

= 4.0.4 (2025-03-06) =
~ Fix Translate single instructor url.

= 4.0.3 (2024-08-27) =
~ Fixed: case not setup wizard WPML.
~ Use new function of LearnPress.

= 4.0.2 (2024-07-25) =
~ Added: method handle wpml for list courses of instructor.
~ Fixed: get courses has translated, if not get course by default lang.

= 4.0.1 (2024-05-24) =
~ Added: async single question.
~ Fixed: minor bugs.

= 4.0.0 =
~ Sync translation course, sections, items of course.
