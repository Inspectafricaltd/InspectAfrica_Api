=== LearnPress - Paystack payment ===
Contributors: Thimpress
Donate link:
Tags: learnpress, paystack, payment
Tested up to: 6.7
Stable tag: 4.0.1

Integrate Paystack payment gateway with LearnPress.

== Description ==

== Changelog ==

= 4.0.1 =
~ Clean code.

= 4.0.0 =
~ First source
