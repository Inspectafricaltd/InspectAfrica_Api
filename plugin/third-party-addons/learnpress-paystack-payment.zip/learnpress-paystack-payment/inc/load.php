<?php
/**
 * Plugin load class.
 *
 * @author   ThimPress
 * @package  LearnPress/Paystack/Classes
 * @version  4.0.1
 */

use LearnPress\Paystack\PaystackGateway;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_PAYSTACK_Payment' ) ) {
	/**
	 * Class LP_Addon_PAYSTACK_Payment
	 */
	class LP_Addon_Paystack_Payment extends LP_Addon {
		public static $instance;
		public $version         = LP_ADDON_PAYSTACK_PAYMENT_VER;
		public $require_version = LP_ADDON_PAYSTACK_PAYMENT_REQUIRE_VER;
		public $plugin_file     = LP_ADDON_PAYSTACK_PAYMENT_FILE;
		public $text_domain     = 'learnpress-paystack-payment';

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * LP_Addon_PAYSTACK_Payment constructor.
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
		}

		/**
		 * Define Learnpress Paystack payment constants.
		 *
		 * @since 3.0.0
		 */
		protected function _define_constants() {
			define( 'LP_ADDON_PAYSTACK_PAYMENT_PATH', dirname( LP_ADDON_PAYSTACK_PAYMENT_FILE ) );
			define( 'LP_ADDON_PAYSTACK_PAYMENT_INC', LP_ADDON_PAYSTACK_PAYMENT_PATH . '/inc/' );
			define( 'LP_ADDON_PAYSTACK_PAYMENT_URL', plugin_dir_url( LP_ADDON_PAYSTACK_PAYMENT_FILE ) );
		}

		/**
		 * Init hooks.
		 */
		protected function hooks() {
			// add payment gateway class
			add_filter( 'learn-press/payment-methods', array( $this, 'add_payment' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			if ( ! is_admin() ) {
				$this->listen_transaction();
			}
		}

		/**
		 * Enqueue assets.
		 *
		 * @since 3.0.0
		 */
		public function enqueue_assets() {
			$ver = $this->version;
			$min = '.min';
			if ( LP_Debug::is_debug() ) {
				$min = '';
				$ver = uniqid();
			}

			wp_register_script(
				'learn-press-paystack',
				$this->get_plugin_url( "assets/dist/js/paystack{$min}.js" ),
				array(),
				$ver,
				array( 'strategy' => 'defer' )
			);

			if ( LP_Page_Controller::is_page_checkout() && PaystackGateway::instance()->is_enabled() ) {
				$public_key    = PaystackGateway::instance()->public_key;
				$data_localize = array(
					'public_key'         => $public_key,
					'nonce'              => wp_create_nonce( 'wp_rest' ),
					'currency'           => learn_press_get_currency(),
					'invalid_email_text' => __( 'Email is invalid', 'learnpress-paystack-payment' ),
					'cancel_order_text'  => __( 'Order is cancel', 'learnpress-paystack-payment' ),
				);
				wp_enqueue_script( 'learn-press-paystack' );
				wp_localize_script( 'learn-press-paystack', 'lpPaystackSetting', $data_localize );
			}
		}

		/**
		 * Add Paystack to payment system.
		 *
		 * @param $methods
		 *
		 * @return mixed
		 */
		public function add_payment( $methods ) {
			$methods['paystack'] = PaystackGateway::instance();

			return $methods;
		}

		/**
		 * Check paystack transaction status
		 */
		public function listen_transaction() {
			try {
				$lp_paystack_payment = LP_Request::get_param( 'lp-paystack-payment' );
				if ( empty( $lp_paystack_payment ) ) {
					return;
				}

				$transaction_ref = LP_Request::get_param( 'lp-paystack-ref' );
				if ( empty( $transaction_ref ) ) {
					return;
				}

				PaystackGateway::instance()->verify_payment( $transaction_ref );
			} catch ( Throwable $e ) {
				error_log( $e->getMessage() );
			}
		}
	}
}
