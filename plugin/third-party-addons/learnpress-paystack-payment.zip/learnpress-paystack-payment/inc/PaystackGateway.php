<?php

namespace LearnPress\Paystack;

use Exception;
use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LP_Gateway_Abstract;

defined( 'ABSPATH' ) || exit;

/**
 * PaystackGateway class.
 *
 * @author   ThimPress
 * @version  4.0.0
 * @since    4.0.0
 */
class PaystackGateway extends LP_Gateway_Abstract {
	use Singleton;

	/**
	 * @var string Payment method ID.
	 */
	public $id = 'paystack';
	/**
	 * @var object|null
	 */
	protected $settings = null;
	/**
	 * @var null
	 */
	public $public_key = null;
	/**
	 * @var null
	 */
	private $secret_key = null;
	/**
	 * LP_Gateway_Paystack constructor.
	 */
	public function __construct() {
		$this->method_title       = esc_html__( 'Paystack', 'learnpress-paystack-payment' );
		$this->method_description = esc_html__( 'Make a payment with Paystack.', 'learnpress-paystack-payment' );
		$this->icon               = LP_ADDON_PAYSTACK_PAYMENT_URL . 'assets/images/paystack.svg';

		parent::__construct();

		// Get settings.
		$this->title       = $this->settings->get( 'title' ) ?? $this->method_title;
		$this->description = $this->settings->get( 'description' );

		// Add default values for fresh installations.
		if ( $this->is_enabled() ) {
			$this->public_key = $this->settings->get( 'public_key', '' );
			$this->secret_key = $this->settings->get( 'secret_key', '' );
		}
	}

	public function init() { }

	/**
	 * Admin payment settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		return include_once LP_ADDON_PAYSTACK_PAYMENT_PATH . '/config/settings.php';
	}

	/**
	 * Payment form.
	 */
	public function get_payment_form() {
		$email_html = sprintf(
			'<label for="lp-paystack-email">%1$s</label><br/>
			<input type="email" name="lp-paystack-email" id="lp-paystack-email" placeholder="%2$s" />',
			__( 'Email', 'learnpress-paystack-payment' ),
			__( 'Enter Paystack Email', 'learnpress-paystack-payment' )
		);

		$section = array(
			'wrap_start' => '<div id="lp-paystack-payment-form">',
			'content'    => $email_html,
			'wrap_end'   => '</div>',
		);

		return Template::combine_components(
			$section
		);
	}
	/**
	 * Paystack payment process.
	 *
	 * @param int $order_id
	 *
	 * @return array
	 * @throws string
	 * @throws Exception
	 */
	public function process_payment( $order_id ) {
		$result = array(
			'result'   => 'fail',
			'message'  => '',
			'redirect' => '',
		);

		$lp_order = learn_press_get_order( $order_id );
		if ( ! $lp_order ) {
			throw new Exception( __( 'Order not found!', 'learnpress-paystack-payment' ) );
		}

		$currency = learn_press_get_currency();
		if ( ! $this->is_supported_currency( $currency ) ) {
			throw new Exception( $currency . __( ' currency is not supported!', 'learnpress-paystack-payment' ) );
		}

		// Ref code is unique
		$ref     = uniqid( 'lporder' . $order_id . '-' );
		$options = array(
			'lp_order_id'  => $order_id,
			'ref'          => $ref,
			'amount'       => $lp_order->get_total() * 100,
			'redirect_url' => add_query_arg( 'lp-paystack-payment', 1, $this->get_return_url( $lp_order ) ),
		);

		$result = array_merge(
			$result,
			array(
				'result'   => LP_ORDER_PROCESSING,
				'message'  => esc_html__( 'The payment is processing.', 'learnpress-paystack-payment' ),
				'redirect' => '',
				'options'  => $options,
			)
		);

		return $result;
	}

	/**
	 * Check supported currencies
	 *
	 * @see https://paystack.com/docs/api/#supported-currency
	 * @param  string $currency LP currency code
	 * @return boolean
	 */
	public function is_supported_currency( string $currency = 'NGN' ): bool {
		return in_array( $currency, array( 'KES', 'ZAR', 'GHS', 'USD', 'NGN' ) );
	}

	/**
	 * Verify Paystack payment
	 *
	 * @param string $ref Paystack ref code (LP Order key)
	 *
	 * @throws Exception
	 */
	public function verify_payment( string $ref = '' ) {
		if ( empty( $ref ) ) {
			return;
		}
		$headers  = array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . $this->secret_key,
			'Cache-Control' => 'no-cache',
		);
		$response = wp_remote_get(
			'https://api.paystack.co/transaction/verify/' . $ref,
			array(
				'headers' => $headers,
				'timeout' => 45,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new Exception( $response->get_error_message() );
		}

		$body   = wp_remote_retrieve_body( $response );
		$result = json_decode( $body, true );
		if ( $response['response']['code'] !== 200 ) {
			$message = __( 'An error occurred while creating the transaction. ', 'woocommerce-qpay-payment' );

			if ( ! empty( $result['message'] ) ) {
				$message .= $result['message'];
			}
			throw new Exception( $message );
		}

		$order_id = $result['data']['metadata']['lp_order_id'];
		$lp_order = learn_press_get_order( $order_id );
		if ( ! $lp_order ) {
			throw new Exception( __( 'LP Order is invalid', 'learnpress-paystack-payment' ) );
		}

		if ( $lp_order->is_completed() ) {
			return;
		}

		$transaction_status = $result['data']['status'];
		if ( $transaction_status === 'success' ) {
			$lp_order->update_status( LP_ORDER_COMPLETED );
		}
	}
}
