<?php
/**
 * Settings for Sepay payment gateway.
 */
return apply_filters(
	'learn-press/gateway-payment/sepay/settings',
	array(
		array( 'type' => 'title' ),
		array(
			'title'   => __( 'Enable', 'learnpress-paystack-payment' ),
			'id'      => '[enable]',
			'default' => 'no',
			'type'    => 'yes-no',
		),
		/*array(
			'type'       => 'text',
			'title'      => __( 'Title', 'learnpress-paystack-payment' ),
			'default'    => __( 'Paystack', 'learnpress-paystack-payment' ),
			'id'         => '[title]',
			'class'      => 'regular-text',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type'       => 'textarea',
			'title'      => __( 'Description', 'learnpress-paystack-payment' ),
			'default'    => __( 'Make a payment with Paystack', 'learnpress-paystack-payment' ),
			'id'         => '[description]',
			'editor'     => array(
				'textarea_rows' => 5,
			),
			'css'        => 'height: 100px;',
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),*/
		array(
			'type'       => 'text',
			'title'      => __( 'API Public Key', 'learnpress-paystack-payment' ),
			'default'    => '',
			'id'         => '[public_key]',
			'class'      => 'regular-text',
			'desc'       => sprintf( __( 'View <a href="%s" target="_blank">document</a> to get api keys', 'learnpress-paystack-payment' ), 'https://support.paystack.com/en/articles/2123458' ),
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array(
			'type'       => 'password',
			'title'      => __( 'API Secret Key', 'learnpress-paystack-payment' ),
			'default'    => '',
			'id'         => '[secret_key]',
			'class'      => 'regular-text',
			'desc'       => sprintf( __( 'View <a href="%s" target="_blank">document</a> to get api keys', 'learnpress-paystack-payment' ), 'https://support.paystack.com/en/articles/2123458' ),
			'visibility' => array(
				'state'       => 'show',
				'conditional' => array(
					array(
						'field'   => '[enable]',
						'compare' => '=',
						'value'   => 'yes',
					),
				),
			),
		),
		array( 'type' => 'sectionend' ),
	)
);
